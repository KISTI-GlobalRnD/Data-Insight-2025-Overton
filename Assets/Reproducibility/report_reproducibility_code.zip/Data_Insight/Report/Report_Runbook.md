# Report Runbook (Overton × OpenAlex)

## 기준 원고(단일)
- 현재 기준 원고: `Data_Insight/Report/Report_final.md`
- 현재 기준 출력물: `Data_Insight/Report/Report_final.docx`, `Data_Insight/Report/Report_final.pdf`
- 원칙: 모든 수정/검수/재빌드는 위 원고 기준으로 수행한다(그림 경로는 `../Assets/Figures/**` 고정).

## 장문 보고서 메모
- 현재 공개본은 이미 `Report_final.md` 기준의 **단일 장문 보고서**다.
- 구조 설계 문서: `Data_Insight/Report/Report_longform_architecture.md`
- 작업 초안: `Data_Insight/Report/Report_longform_draft.md`
- 현재 구조:
  - `Data Insight`(장 번호를 붙이지 않는 요약)
  - `1장 정책문헌 인용을 따로 살펴보는 이유`
  - `2장 한국의 두 인용 방향`
  - `3장 전체 자료에서 확인되는 보완 관측`
  - `4장 결과의 의미와 해석 범위`
  - `웹 보조자료 안내`(장 번호를 붙이지 않는 연결 절)
- 경계 원칙:
  - 장문 보고서의 서술 본문은 `Data_Insight/Report/` 아래에 둔다.
  - `Data_Insight/SI/`는 웹 전용 보조자료만 맡는다.
  - `SI/extended_report.qmd`는 장문 서사를 반복하지 않고, 웹 보조자료로 들어가는 연결 페이지로 유지한다.

## 목적
이 문서는 `Data_Insight/Report/Report_final.md`(기준 원고)를 **다시 생성/업데이트**하고, 동일한 절차로 **그림 포함 Word(docx)/PDF**까지 반복 생산할 수 있도록 정리한 실행 가이드다.

## 핵심 산출물
- 보고서 본문(Markdown): `Data_Insight/Report/Report_final.md`
- 보고서 출력(Word): `Data_Insight/Report/Report_final.docx`
- 보고서 출력(PDF): `Data_Insight/Report/Report_final.pdf`
- (Archive) 상세본(v1) 보고서: `Archive/Data_Insight_report_v1_detailed/Report_final_v1.md` (+ pdf/docx)
- (보고서용) 그림(로컬 복사본): `Data_Insight/Assets/Figures/`
- (관련 노트북 복사본): `Data_Insight/Assets/Notebooks/`
- 그림/집계 결과: `Output/Data_Insight/20251026_*.png`, `Output/Data_Insight/20251026_*.csv`
- (추가) 보고서 보완 그림: `Output/Data_Insight/report_figures/20251026_*.png`
- (Archive) 보고서 개선 참고(비공개 메모 성격): `Archive/Data_Insight_legacy/Feedback.md`, `Archive/Data_Insight_legacy/Reference_Study.md`

## 사전 준비
- Python 실행: `uv` 사용 권장. 예) `uv run python -c "import numpy"`  
  - `uv run ...`은 레포의 `.venv/`를 자동으로 사용한다(별도 activate 불필요).
- `pandoc` 설치 필요(이미 설치되어 있다면 생략)
- 일부 노트북은 로컬 Overton 메타데이터 parquet가 필요(레포에 포함되지 않음):
  - `OVERTON_POLICY_SOURCE_COUNTRY_PARQUET=/path/to/...policy_source_country.parquet`
  - `OVERTON_POLICY_SOURCE_TYPE_PARQUET=/path/to/...policy_source_type.parquet`
- 컨테이너 환경(호스트 경로 미마운트)에서는 레포 내부 경로를 사용할 수 있다:
  - `Data/overton_policy_meta/policy_source_country.parquet`
  - `Data/overton_policy_meta/policy_source_type.parquet`
  - (옵션) 출력 파일명 태그: `RUN_TAG=20251026`
  - `Output/Data_Insight*` 파일명에 태그가 포함되며, `python3 scripts/sync_data_insight_assets.py`로 최신 태그의 그림을 `Data_Insight/Assets/Figures/`에 복사해 갱신한다.

## 재현 절차(노트북 → 그림)
노트북은 `Data_Insight/Assets/Notebooks/` 아래에 있으며, 도메인/출처/노드 타입의 **색 의미 분리 규칙**을 유지하는 것을 전제로 작성되어 있다.

권장 실행 순서:
1) `Data_Insight/Assets/Notebooks/01_data_overview.ipynb`
2) `Data_Insight/Assets/Notebooks/02_descriptive_counts.ipynb`
   - 도메인별 인용 건수는 같은 논문에 같은 도메인의 토픽이 여러 개 있어도 인용 1건을 해당 도메인에서 한 번만 계산한다.
   - 노트북 전체를 다시 실행하지 않는 경우에는 `uv run python scripts/rebuild_domain_counts_unique_domain.py --run-tag 20251026`으로 같은 기준의 도메인 집계표를 갱신한다.
3) `Data_Insight/Assets/Notebooks/03_network_overview.ipynb`  
   - 위의 `OVERTON_POLICY_SOURCE_*` 환경변수가 필요하다.
   - 정책국→연구국 매트릭스, 자국 인용 비중(순차 부여 규칙으로 1저자 소속 국가가 부여된 인용 기준) 등을 갱신한다.
4) `Data_Insight/Assets/Notebooks/04_top_items.ipynb`
5) `Data_Insight/Assets/Notebooks/05_typology.ipynb`
6) `Data_Insight/Assets/Notebooks/06_*` (요약/보조 산출물)
7) `Data_Insight/Assets/Notebooks/07_report_figures.ipynb`
   - `Output/Data_Insight`의 CSV를 읽어 **보고서용 그림(예: Figure 9, 15)** 을 재생성한다.
8) `Data_Insight/Assets/Notebooks/07_report_figures_extended.ipynb`
   - `Output/Data_Insight`의 CSV를 읽어 `Output/Data_Insight/report_figures`로 보고서 보완 그림을 생성한다(한국 포함 자국 인용 비중 비교 등).
   - (대안) 노트북 대신 스크립트 1회 실행으로 `report_figures`를 재생성할 수도 있다:
     - `RUN_TAG=20251026 uv run python3 scripts/make_report_figures_extended.py`

## 보고서용 그림 동기화
보고서는 `Data_Insight/Assets/Figures/` 아래의 **고정 경로(로컬 복사본)** 를 참조한다.  
노트북을 다시 실행해 `Output/...` 그림이 갱신되면 아래 스크립트로 복사본을 최신 태그로 동기화한다.

- (자동 태그 추론) `uv run python3 scripts/sync_data_insight_assets.py`
- (태그 고정) `RUN_TAG=20251026 uv run python3 scripts/sync_data_insight_assets.py`

## 배포용 시각화(스크립트) 원커맨드
집계 CSV가 `Output/Data_Insight/**`에 준비된 상태라면, 배포 가능한 시각화 자산을 한 번에 재생성할 수 있다.

```bash
# (권장) pubyear 진단까지 포함하려면 Overton MAIN parquet 경로가 필요하다.
RUN_TAG=20251026 OVERTON_MAIN_PARQUET=/path/to/01__Overton_...__MAIN.parquet \
  uv run python scripts/build_visual_assets.py --render-site
```

- 포함: 고유 인용-도메인 집계표, `report_figures` PNG/CSV, SI extra PNG, pubyear 진단, subfield→domain 네트워크, 인터랙티브 HTML, 랜딩 PNG, 자산 sync, (옵션) Quarto 렌더
- 주의: `OVERTON_MAIN_PARQUET`이 없으면 pubyear 진단 단계는 자동으로 skip된다.

### 국가별 도메인 구성비 캐시

- 비교 막대에 쓰는 `Output/Data_Insight/report_figures/{RUN_TAG}_openalex_country_domain_output_share.csv`는 `scripts/country_domain_output_cache.py`가 관리한다.
- 캐시에는 연구국 순차 부여 규칙, 캐시 스키마, 도메인 집합, `matched_openalex_with_oa_country_unique.parquet`와 `openalex_topics.parquet`의 파일명·크기·수정시각을 기록한다.
- 현재 입력과 provenance가 하나라도 다르면 캐시를 재사용하지 않고 자동 재계산한다. 캐시 CSV를 수동으로 복사해 새 연구국 부여 결과와 혼용하지 않는다.

## 그림 리뷰 체크리스트
그림 점검은 본문 그림부터 수행하고, SI는 별도로 진행한다.  
리뷰는 **그림 1개씩 확인 → 노트 업데이트 → 모든 그림 완료 후 응답** 순서로 한다.  
리뷰 노트는 `Data_Insight/Report/Figure_Review_Notes.md`에 기록한다.

### 공통 체크
- 데이터 정합: 합계, 비율, 범위가 정의와 맞는지 확인. 정규화가 있으면 합계가 100%인지 점검한다.
- 정규화 방향: row/column 기준과 캡션, 라벨이 일치하는지 확인한다.
- 축/라벨/단위: 축 이름, 단위, 약어 정의, 범주명이 정확한지 확인한다.
- 정렬/순서: 정렬 기준이 설명과 일치하는지, 비교가 왜곡되지 않는지 확인한다.
- 스케일: 선형/로그 선택이 적절한지, vmin/vmax나 cap이 설명과 일치하는지 확인한다.
- 범례/컬러바: 단위와 범위 표기가 정확한지, 상단 캡 표시가 필요한지 확인한다.
- 주석: 숫자 표기가 과밀하지 않은지, 반올림 규칙이 일관적인지 확인한다.
- 레이아웃: 잘림, 겹침, 과도한 여백이 없는지 확인한다.
- 본문/캡션 정합: 그림 내용과 본문 서술이 일치하는지 확인한다.

### 플롯 유형별 체크
- Line plot
  - 시간 축 범위, 간격, 누락 구간 표시가 정확한지 확인한다.
  - 스무딩이나 이동평균을 썼다면 표기한다.
  - 로그 스케일 사용 시 해석이 본문에 반영됐는지 확인한다.
- Scatter plot
  - 축 스케일과 단위가 비교 목적에 맞는지 확인한다.
  - 점 크기, 색상, 투명도 의미가 명확한지 확인한다.
  - 극단값에 의해 축이 왜곡되는지 점검한다.
- Bar plot
  - 0 기준선을 유지하는지 확인한다.
  - 정렬 기준과 누적 or 그룹 방식이 설명과 일치하는지 확인한다.
  - 비율과 절대량을 혼동하지 않도록 라벨을 점검한다.
- Heatmap
  - 정규화 방향과 합계가 맞는지 확인한다.
  - cmap 대비가 충분한지, 극단값으로 색이 몰리지 않는지 확인한다.
  - 캡이나 vmin, vmax 조정이 필요한지 판단한다.

## 홍보 페이지(landing)용 그림(다크 테마)
홍보 페이지는 [`Data_Insight/index.html`](../index.html)에서 [`Data_Insight/Assets/Landing/`](../Assets/Landing/) 아래 PNG를 참조한다.  
보고서용 PNG(라이트 테마)와 별도로, 다크 배경에 맞춘 랜딩용 PNG를 생성한다.

- (권장) 노트북에서 생성: [`Data_Insight/Assets/Notebooks/07_report_figures_extended.ipynb`](../Assets/Notebooks/07_report_figures_extended.ipynb) 하단 셀 실행
- (스크립트로 생성) `RUN_TAG=20251026 uv run python scripts/make_landing_figures.py` (스크립트: [`scripts/make_landing_figures.py`](../../scripts/make_landing_figures.py))
- (원커맨드) 자산 동기화+랜딩 그림+SI 빌드: `RUN_TAG=20251026 uv run python scripts/build_data_insight_site.py` (스크립트: [`scripts/build_data_insight_site.py`](../../scripts/build_data_insight_site.py))
- GitHub Pages 반영(리소스 복사): `quarto render Data_Insight --no-clean` (출력: [`Data_Insight/docs/`](../docs/))

### 랜딩 스토리/그림 업데이트 원칙(축약 버전)
랜딩 페이지는 **모바일/한 화면에서 읽히는 크기**를 전제로 한다. 따라서 보고서 본문 그림을 그대로 축소하면
다중 패널/주석이 과밀해져 가독성이 급격히 떨어진다.  
그래서 랜딩에서는 일부 그림을 **축약(랜딩) 버전**으로 제공하고, 전체 맥락/세부 분석은 보고서·SI에서 본다.

기본 원칙:
- 랜딩은 “대표성”을 우선하고, 세부 분해(다중 패널)는 SI/보고서로 미룬다.
- 랜딩 PNG는 **투명 배경 + 흰색 텍스트/선(다크 테마)** 을 기본으로 한다.
- 랜딩 글은 1–2문장, 담백한 톤(약간 자조적 가능)으로 유지한다.

#### 현재 랜딩 스토리(5단계 + hero)와 그림 매핑
- 랜딩 스토리 위치: [`Data_Insight/index.html#story`](../index.html#story)
- hero (배경 네트워크): [`Data_Insight/Assets/Landing/hero_network.png`](../Assets/Landing/hero_network.png)
- 1 (규모): [`Data_Insight/Assets/Landing/pubyear_trend.png`](../Assets/Landing/pubyear_trend.png)
- 2 (구조): [`Data_Insight/Assets/Landing/flow_network.png`](../Assets/Landing/flow_network.png)
- 3 (국제 흐름): [`Data_Insight/Assets/Landing/country_flow.png`](../Assets/Landing/country_flow.png)
- 4 (기관 유형): [`Data_Insight/Assets/Landing/source_type_scatter.png`](../Assets/Landing/source_type_scatter.png)
- 5 (한국): [`Data_Insight/Assets/Landing/korea_flows.png`](../Assets/Landing/korea_flows.png)
  - 랜딩(축약): 한국 관련 두 인용 방향의 비교만 유지
  - 전체(세부 분해/추가 패널)는 [`Data_Insight/Report/Report_final.md`](Report_final.md) 및 [`Data_Insight/SI/`](../SI/)로 이동

#### 랜딩 업데이트 워크플로(권장)
1) (필요 시) 보고서 그림 업데이트 → [`Output/Data_Insight/`](../../Output/Data_Insight/) 갱신  
2) 랜딩 그림 재생성: `RUN_TAG=20251026 uv run python scripts/make_landing_figures.py`
3) 랜딩 텍스트/대체텍스트(alt) 동기화:
   - 원본: [`Data_Insight/index.qmd`](../index.qmd)
   - 렌더 결과 확인: [`Data_Insight/docs/index.html`](../docs/index.html)
4) 사이트 빌드(Quarto): `quarto render Data_Insight --no-clean` (출력: [`Data_Insight/docs/`](../docs/))
5) `Data_Insight/docs`에 변경사항 커밋/푸시(가능한 경우)

## docx 변환(그림 포함)
레포 루트에서 실행:
- (권장) `python3 scripts/sync_data_insight_assets.py`
- (권장, DOCX·PDF 동시 빌드) `uv run python scripts/build_report_outputs.py`
- 위 스크립트는 DOCX를 A4로 맞추고 페이지 번호를 추가하며, PDF에는 `Data_Insight/Report/report_print.css`의 A4 인쇄 스타일을 적용한다.
- DOCX만 원시 변환할 때: `pandoc Data_Insight/Report/Report_final.md -o Data_Insight/Report/Report_final.docx --resource-path=.:Data_Insight/Report`

그림이 docx에 포함됐는지 빠르게 확인:
- `unzip -l Data_Insight/Report/Report_final.docx | rg 'word/media/'`

## pdf 변환(그림 포함)
이 레포는 LaTeX 기반 PDF 엔진 설치를 전제로 하지 않는다. 대신 headless Chrome으로 HTML을 PDF로 인쇄한다.

레포 루트에서 실행:
  - (권장, DOCX·PDF 동시 빌드) `uv run python scripts/build_report_outputs.py`
  - `python3 scripts/sync_data_insight_assets.py`
  - `pandoc Data_Insight/Report/Report_final.md -o Data_Insight/Report/.tmp_Report_final.html --standalone --embed-resources --resource-path=.:Data_Insight/Report`
  - `google-chrome --headless --disable-gpu --no-sandbox --print-to-pdf=Data_Insight/Report/Report_final.pdf --no-pdf-header-footer file://$PWD/Data_Insight/Report/.tmp_Report_final.html`
  - `rm -f Data_Insight/Report/.tmp_Report_final.html`

페이지 수 확인(선택):
- `pdfinfo Data_Insight/Report/Report_final.pdf | rg 'Pages'`

PDF 텍스트/메타 검증(권장):
- 로컬 경로/임시 파일명이 PDF에 노출되지 않는지 확인:
  - `pdftotext Data_Insight/Report/Report_final.pdf - | rg -n 'file://|tmp_Report|/home/'`
- 위 명령이 아무것도 출력하지 않으면(=매칭 0개) 기본적인 “로컬 경로 누출”은 방지된 것으로 본다.

## Supplementary (Quarto, GitHub Pages 대비)
보고서(요약본)에서 생략한 방법/정의/추가 그림은 Quarto로 Supplementary 사이트로 관리한다.

- 빌드(정적 사이트 생성, GitHub Pages용): `quarto render Data_Insight`
  - 출력 경로: `Data_Insight/docs/` (GitHub Pages의 “/docs” 소스로 사용 가능)
  - `Data_Insight/docs/`는 **생성된 산출물**이라 필요 없으면 삭제해도 되고, 다시 렌더링하면 재생성된다.
- 로컬 미리보기(개발용): `quarto preview Data_Insight`

## Interactive Plot (Plotly)
보고서 본문에 있는 주요 Bar/Line/Scatter 그림은 웹 공개를 위해 Plotly 기반 인터랙티브 HTML로도 생성할 수 있다.

- (필요 시) 의존성 설치: `uv pip install plotly pycountry`
- 보고서 그림(Interactive): `uv run python scripts/make_report_interactive_plots.py --run-tag 20251026`
- 커버리지 지도(SI): `uv run python scripts/make_coverage_map.py --run-tag 20251026`
- Quarto는 `Assets/Interactive/**`를 `docs/Assets/Interactive/**`로 복사하므로, 렌더링 후 `SI/interactive.html`에서 링크로 확인할 수 있다.

## 트러블슈팅
- docx에 그림이 누락될 때
  - `Output/Data_Insight/20251026_*.png`, `Output/Data_Insight/report_figures/20251026_*.png`가 실제로 존재하는지 확인
  - pandoc 실행 위치가 레포 루트인지 확인
  - `--resource-path=.:Data_Insight/Report` 옵션을 포함했는지 확인
- 새 태그로 그림을 재생성한 경우
  - Markdown은 수정하지 말고, `python3 scripts/sync_data_insight_assets.py`로 `Data_Insight/Assets/Figures/` 복사본을 갱신한다.
