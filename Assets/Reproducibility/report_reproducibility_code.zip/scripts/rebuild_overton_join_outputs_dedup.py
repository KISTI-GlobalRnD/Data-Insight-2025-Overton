#!/usr/bin/env python3
"""
Rebuild Output/Data_Insight/* aggregates that are sensitive to join(row multiplicity)
by using:
- distinct doc-tag Overton meta parquets (clean)
- unique-per-work OpenAlex matched parquet

This script overwrites the affected CSVs for a given RUN_TAG.

Run:
  uv run python scripts/rebuild_overton_join_outputs_dedup.py --run-tag 20251026
"""

from __future__ import annotations

import argparse
from pathlib import Path

import duckdb
import pandas as pd


def _copy_csv(con: duckdb.DuckDBPyConnection, *, query: str, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    con.execute(f"COPY ({query}) TO '{str(out_path)}' (FORMAT CSV, HEADER, DELIMITER ',');")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-tag", default="20251026")
    ap.add_argument("--out-dir", default="Output/Data_Insight")
    args = ap.parse_args()

    run_tag = str(args.run_tag)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    citations_path = Path("Data/raw_df_citation_non_duplicated.parquet")
    topics_path = Path("Data/openalex_topics.parquet")
    country_clean = Path("Data/overton_policy_meta/policy_source_country_clean.parquet")
    type_clean = Path("Data/overton_policy_meta/policy_source_type_clean.parquet")
    works_unique = Path("Data/matched_openalex_with_oa_country_unique.parquet")

    missing = [p for p in [citations_path, topics_path, country_clean, type_clean, works_unique] if not p.exists()]
    if missing:
        raise SystemExit("Missing required inputs:\n" + "\n".join(f"- {p}" for p in missing))

    con = duckdb.connect()

    # ---- Top-level policy source / source type: policy docs + citation rows ----
    # Country metadata can contain both a parent tag and hierarchical child tags
    # (A > B). Collapse them to the top-level source before counting so each
    # citation contributes only once to the policy-source denominator.
    _copy_csv(
        con,
        query=f"""
        SELECT
          split_part(policy_source_country, ' > ', 1) AS country,
          COUNT(DISTINCT policy_document_id)::BIGINT AS policy_docs
        FROM read_parquet('{str(country_clean)}')
        WHERE policy_source_country IS NOT NULL
        GROUP BY 1
        ORDER BY policy_docs DESC
        """,
        out_path=out_dir / f"{run_tag}_country_policy_docs.csv",
    )

    _copy_csv(
        con,
        query=f"""
        WITH pc AS (
          SELECT DISTINCT
            policy_document_id,
            split_part(policy_source_country, ' > ', 1) AS country
          FROM read_parquet('{str(country_clean)}')
          WHERE policy_source_country IS NOT NULL
        )
        SELECT
          pc.country AS country,
          COUNT(*)::BIGINT AS citation_rows,
          COUNT(DISTINCT c.policy_document_id)::BIGINT AS citing_policy_docs
        FROM read_parquet('{str(citations_path)}') c
        LEFT JOIN pc USING (policy_document_id)
        WHERE pc.country IS NOT NULL
        GROUP BY 1
        ORDER BY citation_rows DESC
        """,
        out_path=out_dir / f"{run_tag}_country_citations.csv",
    )

    _copy_csv(
        con,
        query=f"""
        SELECT
          policy_source_type AS source_type,
          COUNT(DISTINCT policy_document_id)::BIGINT AS policy_docs
        FROM read_parquet('{str(type_clean)}')
        GROUP BY 1
        ORDER BY policy_docs DESC
        """,
        out_path=out_dir / f"{run_tag}_source_type_policy_docs.csv",
    )

    _copy_csv(
        con,
        query=f"""
        WITH st AS (
          SELECT DISTINCT policy_document_id, policy_source_type AS source_type
          FROM read_parquet('{str(type_clean)}')
        )
        SELECT
          st.source_type AS source_type,
          COUNT(*)::BIGINT AS citation_rows,
          COUNT(DISTINCT c.policy_document_id)::BIGINT AS citing_policy_docs
        FROM read_parquet('{str(citations_path)}') c
        LEFT JOIN st USING (policy_document_id)
        WHERE st.source_type IS NOT NULL
        GROUP BY 1
        ORDER BY citation_rows DESC
        """,
        out_path=out_dir / f"{run_tag}_source_type_citations.csv",
    )

    # ---- Country/type × domain matrices (policy demand composition) ----
    _copy_csv(
        con,
        query=f"""
        WITH pc AS (
          SELECT DISTINCT
            policy_document_id,
            split_part(policy_source_country, ' > ', 1) AS country
          FROM read_parquet('{str(country_clean)}')
          WHERE policy_source_country IS NOT NULL
        ),
        wd AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('{str(topics_path)}')
          WHERE domain IS NOT NULL AND domain <> ''
        )
        SELECT
          pc.country AS country,
          wd.domain AS domain,
          COUNT(*)::BIGINT AS citation_rows
        FROM read_parquet('{str(citations_path)}') c
        JOIN pc USING (policy_document_id)
        JOIN wd USING (oaid_w)
        GROUP BY 1, 2
        ORDER BY citation_rows DESC
        """,
        out_path=out_dir / f"{run_tag}_country_domain_matrix.csv",
    )

    _copy_csv(
        con,
        query=f"""
        WITH st AS (
          SELECT DISTINCT policy_document_id, policy_source_type AS source_type
          FROM read_parquet('{str(type_clean)}')
        ),
        wd AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('{str(topics_path)}')
          WHERE domain IS NOT NULL AND domain <> ''
        )
        SELECT
          st.source_type AS source_type,
          wd.domain AS domain,
          COUNT(*)::BIGINT AS citation_rows
        FROM read_parquet('{str(citations_path)}') c
        JOIN st USING (policy_document_id)
        JOIN wd USING (oaid_w)
        GROUP BY 1, 2
        ORDER BY citation_rows DESC
        """,
        out_path=out_dir / f"{run_tag}_source_type_domain_matrix.csv",
    )

    # ---- Policy country × research country flow matrix (first-author ISO2) ----
    _copy_csv(
        con,
        query=f"""
        WITH pc AS (
          -- Normalize subnational tags to top-level country (A > B -> A) for comparability
          SELECT DISTINCT
            policy_document_id,
            split_part(policy_source_country, ' > ', 1) AS policy_country
          FROM read_parquet('{str(country_clean)}')
          WHERE policy_source_country IS NOT NULL
        ),
        wc AS (
          SELECT oaid_w, first_author_country
          FROM read_parquet('{str(works_unique)}')
        )
        SELECT
          pc.policy_country AS policy_country,
          wc.first_author_country AS research_country,
          COUNT(*)::BIGINT AS citation_rows
        FROM read_parquet('{str(citations_path)}') c
        LEFT JOIN pc USING (policy_document_id)
        LEFT JOIN wc USING (oaid_w)
        WHERE pc.policy_country IS NOT NULL
        GROUP BY 1, 2
        ORDER BY citation_rows DESC
        """,
        out_path=out_dir / f"{run_tag}_policy_country_research_country.csv",
    )

    # ---- Self share (known research countries only) ----
    # Preserve ISO2 code ``NA`` (Namibia); pandas otherwise interprets it as
    # a missing-value token and silently removes valid country assignments.
    mat = pd.read_csv(
        out_dir / f"{run_tag}_policy_country_research_country.csv",
        keep_default_na=False,
    )
    policy_to_iso2 = {
        "USA": "US",
        "UK": "GB",
        "Germany": "DE",
        "France": "FR",
        "Canada": "CA",
        "Australia": "AU",
        "Sweden": "SE",
        "Netherlands": "NL",
        "Finland": "FI",
        "Ireland": "IE",
        "Spain": "ES",
        "Italy": "IT",
        "Japan": "JP",
        "Brazil": "BR",
        "Switzerland": "CH",
        "Norway": "NO",
        "Denmark": "DK",
        "New Zealand": "NZ",
        "Austria": "AT",
        "Belgium": "BE",
        "Korea": "KR",
        "South Korea": "KR",
        "Republic of Korea": "KR",
        "China": "CN",
        "India": "IN",
    }

    mat["policy_root"] = mat["policy_country"].astype(str).str.split(" > ", n=1).str[0].str.strip()
    mat["policy_iso2"] = mat["policy_root"].map(policy_to_iso2)
    mat["research_country"] = mat["research_country"].fillna("").astype(str).str.strip()

    known = mat[(mat["policy_iso2"].notna()) & (mat["research_country"] != "")].copy()
    agg = (
        known.groupby(["policy_root", "policy_iso2"], as_index=False)["citation_rows"]
        .sum()
        .rename(columns={"policy_root": "policy_country", "citation_rows": "known_citations"})
    )
    self_agg = (
        known[known["research_country"] == known["policy_iso2"]]
        .groupby(["policy_root", "policy_iso2"], as_index=False)["citation_rows"]
        .sum()
        .rename(columns={"policy_root": "policy_country", "citation_rows": "self_citations"})
    )
    self_share = agg.merge(self_agg, on=["policy_country", "policy_iso2"], how="left").fillna({"self_citations": 0})
    self_share["self_share"] = self_share["self_citations"] / self_share["known_citations"]
    self_share.to_csv(out_dir / f"{run_tag}_policy_country_self_share_known.csv", index=False)

    # ---- Source type OA share (uses unique works meta) ----
    _copy_csv(
        con,
        query=f"""
        WITH st AS (
          SELECT DISTINCT policy_document_id, policy_source_type AS source_type
          FROM read_parquet('{str(type_clean)}')
        ),
        w AS (
          SELECT oaid_w, is_oa
          FROM read_parquet('{str(works_unique)}')
        )
        SELECT
          st.source_type AS source_type,
          w.is_oa AS is_oa,
          COUNT(*)::BIGINT AS citation_rows
        FROM read_parquet('{str(citations_path)}') c
        LEFT JOIN st USING (policy_document_id)
        LEFT JOIN w USING (oaid_w)
        WHERE st.source_type IS NOT NULL
        GROUP BY 1, 2
        ORDER BY citation_rows DESC
        """,
        out_path=out_dir / f"{run_tag}_source_type_oa_share.csv",
    )

    # Summary CSV (for quick plots)
    stype_oa = pd.read_csv(out_dir / f"{run_tag}_source_type_oa_share.csv")
    pivot = stype_oa.pivot_table(index="source_type", columns="is_oa", values="citation_rows", aggfunc="sum", fill_value=0)
    pivot["total"] = pivot.sum(axis=1)
    pivot["oa_share"] = pivot.get("Y", 0) / pivot["total"].replace({0: pd.NA})
    pivot.reset_index().to_csv(out_dir / f"{run_tag}_source_type_oa_share_summary.csv", index=False)

    con.close()
    print(f"[ok] rebuilt join-sensitive outputs for RUN_TAG={run_tag}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
