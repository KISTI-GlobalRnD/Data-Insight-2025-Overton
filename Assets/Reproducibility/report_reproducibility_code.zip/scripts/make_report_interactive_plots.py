#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots


CORE_SEQ = ["#65CBA3", "#2CB1A6", "#F2B880", "#E07A5F", "#D6E3D8"]
CORE_PRIMARY = "#65CBA3"
GRID_COLOR = "#E4EFE8"
TEXT_COLOR = "#1F2933"
NEUTRAL_GRAY = "#D6E3D8"
REFERENCE_COLOR = "#B7CEC0"
REFERENCE_TEXT = "#6F8A7C"

DOMAIN_ORDER = ["Social Sciences", "Health Sciences", "Physical Sciences", "Life Sciences"]
DOMAIN_COLORS = {
    "Social Sciences": "#65CBA3",
    "Health Sciences": "#2CB1A6",
    "Physical Sciences": "#F2B880",
    "Life Sciences": "#E07A5F",
    "Unknown": NEUTRAL_GRAY,
}

# Auxiliary palette for non-domain semantics (keep distinct from DOMAIN_COLORS).
AUX_SEQ = ["#2F7F6D", "#7FBF9F", "#D5B06A", "#C96C50", NEUTRAL_GRAY]
AUX_PRIMARY = AUX_SEQ[0]
AUX_SECONDARY = AUX_SEQ[1]
AUX_TERTIARY = AUX_SEQ[2]
AUX_HIGHLIGHT = AUX_SEQ[3]
PLOTLY_COLORWAY = [AUX_PRIMARY, AUX_SECONDARY, AUX_TERTIARY, AUX_HIGHLIGHT, *CORE_SEQ]

HEATMAP_SCALE = [
    [0.0, "#FFFFFF"],
    [0.25, "#EEF7F3"],
    [0.5, "#CFE5D8"],
    [0.75, "#7DD4AF"],
    [1.0, "#3BB89D"],
]

KOREA_DISPLAY_LABEL = "Republic of Korea"
KOREA_POLICY_SOURCE_RAW_LABEL = "South Korea"
KOREA_LABEL_ALIASES = {KOREA_DISPLAY_LABEL, KOREA_POLICY_SOURCE_RAW_LABEL, "Korea"}
_KOREA_LABEL_ALIASES_CASEFOLD = {s.casefold() for s in KOREA_LABEL_ALIASES}


def _normalize_korea_label(label: str) -> str:
    lab = str(label).strip()
    if not lab:
        return lab
    if lab.casefold() in _KOREA_LABEL_ALIASES_CASEFOLD:
        return KOREA_DISPLAY_LABEL
    return lab


def _iso2_to_display_label(iso2: str) -> str:
    iso2 = str(iso2).strip().upper()
    if not iso2:
        return iso2
    if iso2 == "US":
        return "USA"
    if iso2 == "GB":
        return "UK"
    if iso2 == "KR":
        return KOREA_DISPLAY_LABEL

    try:
        import pycountry

        country = pycountry.countries.get(alpha_2=iso2)
        name = getattr(country, "name", None) if country is not None else None
    except Exception:
        name = None

    if not name:
        return iso2
    normalize = {
        "Korea, Republic of": KOREA_DISPLAY_LABEL,
        "Russian Federation": "Russia",
        "Iran, Islamic Republic of": "Iran",
        "Venezuela, Bolivarian Republic of": "Venezuela",
        "Bolivia, Plurinational State of": "Bolivia",
        "Tanzania, United Republic of": "Tanzania",
        "Viet Nam": "Vietnam",
    }
    return normalize.get(name, name)


FIG06_CROSS_HOVER_HIGHLIGHT_SCRIPT = r"""
(function() {
  var gd = document.getElementById('{plot_id}');
  if (!gd || !window.Plotly) return;

  function isSizeLegendTrace(tr) {
    if (!tr) return false;
    if (tr.legend && tr.legend === 'legend2') return true;
    if (tr.legendgroup && tr.legendgroup === 'Citation volume') return true;
    return false;
  }

  var groupToIdx = {};
  for (var i = 0; i < (gd.data || []).length; i++) {
    var tr = gd.data[i] || {};
    if (isSizeLegendTrace(tr)) continue;
    var group = tr.legendgroup;
    if (!group) continue;
    if (!groupToIdx[group]) groupToIdx[group] = [];
    groupToIdx[group].push(i);
  }

  var lock = false;
  var lastGroup = null;

  var DEFAULT_STYLE = {
    'marker.line.color': 'white',
    'marker.line.width': 1,
    'marker.opacity': 0.78,
  };
  var HIGHLIGHT_STYLE = {
    'marker.line.color': '#111827',
    'marker.line.width': 3,
    'marker.opacity': 1.0,
  };

  function styleGroup(groupName, style) {
    var idx = groupToIdx[groupName] || [];
    if (!idx.length) return;
    Plotly.restyle(gd, style, idx);
  }

  gd.on('plotly_hover', function(ev) {
    if (lock) return;
    if (!ev || !ev.points || !ev.points.length) return;
    var d = ev.points[0].data || {};
    if (isSizeLegendTrace(d)) return;
    var groupName = d.legendgroup;
    if (!groupName) return;
    if (groupName === lastGroup) return;

    lock = true;
    try {
      if (lastGroup) styleGroup(lastGroup, DEFAULT_STYLE);
      styleGroup(groupName, HIGHLIGHT_STYLE);
      lastGroup = groupName;
    } finally {
      lock = false;
    }
  });

  gd.on('plotly_unhover', function() {
    if (lock) return;
    if (!lastGroup) return;
    lock = true;
    try {
      styleGroup(lastGroup, DEFAULT_STYLE);
      lastGroup = null;
    } finally {
      lock = false;
    }
  });
})();
"""

FIG13_NEIGHBOR_FOCUS_SCRIPT = r"""
(function() {
  var gd = document.getElementById('{plot_id}');
  if (!gd || !window.Plotly) return;

  function traceRole(tr) {
    return (tr && tr.meta && tr.meta.role) ? tr.meta.role : null;
  }

  var baseMain = null;
  var baseKorea = null;
  var focusMain = null;
  var focusKorea = null;
  var arrowsMain = null;
  var arrowsKorea = null;
  var nodeTraceIdx = [];

  for (var i = 0; i < (gd.data || []).length; i++) {
    var tr = gd.data[i] || {};
    var role = traceRole(tr);
    if (role === 'edges_base_main') baseMain = i;
    else if (role === 'edges_base_korea') baseKorea = i;
    else if (role === 'edges_focus_main') focusMain = i;
    else if (role === 'edges_focus_korea') focusKorea = i;
    else if (role === 'arrows_focus_main') arrowsMain = i;
    else if (role === 'arrows_focus_korea') arrowsKorea = i;
    else if (role === 'nodes') nodeTraceIdx.push(i);
  }

  if (baseMain === null || baseKorea === null || focusMain === null || focusKorea === null) return;
  if (arrowsMain === null || arrowsKorea === null) return;
  if (!nodeTraceIdx.length) return;

  var meta = (gd.layout || {}).meta || {};
  var edges = meta.edges || [];
  var koreaLabel = meta.korea_label || 'Republic of Korea';

  var neighbors = {};
  var incident = {};
  var edgeSet = {};
  for (var ei = 0; ei < edges.length; ei++) {
    var e = edges[ei] || [];
    var s = e[0];
    var t = e[1];
    if (!s || !t) continue;
    if (!neighbors[s]) neighbors[s] = {};
    if (!neighbors[t]) neighbors[t] = {};
    neighbors[s][t] = true;
    neighbors[t][s] = true;
    edgeSet[s + '||' + t] = true;

    if (!incident[s]) incident[s] = [];
    if (!incident[t]) incident[t] = [];
    incident[s].push([s, t]);
    incident[t].push([s, t]);
  }

  var nodePos = {};
  var nodeSize = {};
  var nodeIndexByTrace = {};
  for (var ti = 0; ti < nodeTraceIdx.length; ti++) {
    var idx = nodeTraceIdx[ti];
    var trn = gd.data[idx] || {};
    var cd = trn.customdata || [];
    var xs = trn.x || [];
    var ys = trn.y || [];
    var ms = (trn.marker || {}).size;
    var map = {};
    for (var j = 0; j < cd.length; j++) {
      var row = cd[j] || [];
      var nodeId = row[0];
      if (!nodeId) continue;
      map[nodeId] = j;
      nodePos[nodeId] = [xs[j], ys[j]];
      var s = null;
      if (Array.isArray(ms)) s = ms[j];
      else if (ms !== undefined && ms !== null) s = ms;
      if (s !== null && isFinite(s)) {
        if (nodeSize[nodeId] === undefined || s > nodeSize[nodeId]) nodeSize[nodeId] = s;
      }
    }
    nodeIndexByTrace[idx] = map;
  }

  var BASE_MAIN_COLOR = 'rgba(47, 127, 109, 0.22)';
  var BASE_KOREA_COLOR = 'rgba(201, 108, 80, 0.55)';
  var DIM_MAIN_COLOR = 'rgba(47, 127, 109, 0.05)';
  var DIM_KOREA_COLOR = 'rgba(201, 108, 80, 0.12)';

  function curvePoints(src, dst, x0, y0, x1, y1) {
    var hasReverse = edgeSet[dst + '||' + src] && (src !== dst);
    if (!hasReverse) {
      return [[x0, x1], [y0, y1]];
    }

    var a = (src < dst) ? src : dst;
    var b = (src < dst) ? dst : src;
    var pa = nodePos[a];
    var pb = nodePos[b];
    if (!pa || !pb) {
      return [[x0, x1], [y0, y1]];
    }

    var dx = pb[0] - pa[0];
    var dy = pb[1] - pa[1];
    var dist = Math.sqrt(dx * dx + dy * dy);
    if (!dist) {
      return [[x0, x1], [y0, y1]];
    }

    var nx = -dy / dist;
    var ny = dx / dist;
    var sign = (src === a) ? 1.0 : -1.0;
    var curv = 0.22 * sign;

    var cx = (x0 + x1) / 2.0 + curv * dist * nx;
    var cy = (y0 + y1) / 2.0 + curv * dist * ny;

    var pts = 12;
    var xs = [];
    var ys = [];
    for (var i = 0; i < pts; i++) {
      var t = i / (pts - 1);
      var omt = 1 - t;
      var bx = omt * omt * x0 + 2 * omt * t * cx + t * t * x1;
      var by = omt * omt * y0 + 2 * omt * t * cy + t * t * y1;
      xs.push(bx);
      ys.push(by);
    }
    return [xs, ys];
  }

  var lockNode = null;
  var resetTimer = null;

  function buildSelectedPoints(keep) {
    var out = [];
    for (var ti = 0; ti < nodeTraceIdx.length; ti++) {
      var idx = nodeTraceIdx[ti];
      var map = nodeIndexByTrace[idx] || {};
      var pts = [];
      for (var nodeId in map) {
        if (keep[nodeId]) pts.push(map[nodeId]);
      }
      out.push(pts);
    }
    return out;
  }

	  function buildFocusEdges(nodeId) {
	    var mainX = [];
	    var mainY = [];
	    var koreaX = [];
	    var koreaY = [];
	    var mainAx = [];
	    var mainAy = [];
	    var mainAa = [];
	    var koreaAx = [];
	    var koreaAy = [];
	    var koreaAa = [];

	    function axisToPx(axis, v, isY) {
	      if (!axis) return null;
	      if (typeof axis.l2p === 'function') return axis.l2p(v);
	      if (typeof axis.d2p === 'function') return axis.d2p(v);
	      if (typeof axis.c2p === 'function') return axis.c2p(v);
	      var r = axis.range;
	      if (!r || r.length !== 2 || axis._length === undefined || axis._offset === undefined) return null;
	      var frac = (v - r[0]) / (r[1] - r[0]);
	      if (isY) frac = 1 - frac;
	      return axis._offset + frac * axis._length;
	    }

	    function pxToAxis(axis, p, isY) {
	      if (!axis) return null;
	      if (typeof axis.p2l === 'function') return axis.p2l(p);
	      if (typeof axis.p2d === 'function') return axis.p2d(p);
	      if (typeof axis.p2c === 'function') return axis.p2c(p);
	      var r = axis.range;
	      if (!r || r.length !== 2 || axis._length === undefined || axis._offset === undefined) return null;
	      var frac = (p - axis._offset) / axis._length;
	      if (isY) frac = 1 - frac;
	      return r[0] + frac * (r[1] - r[0]);
	    }

	    function arrowFor(xs, ys, dstId) {
	      if (!xs || !ys || xs.length < 2 || ys.length < 2) return [null, null, 0];
	      var xa = (gd._fullLayout || {}).xaxis;
	      var ya = (gd._fullLayout || {}).yaxis;

	      // Convert curve points to pixels so we can place the arrow a fixed distance
	      // away from the destination node along the *curve* (not just the last segment).
	      var px = [];
	      var py = [];
	      for (var i = 0; i < xs.length; i++) {
	        var xpi = axisToPx(xa, xs[i], false);
	        var ypi = axisToPx(ya, ys[i], true);
	        if (xpi === null || ypi === null) {
	          px = null;
	          py = null;
	          break;
	        }
	        px.push(xpi);
	        py.push(ypi);
	      }

	      var xEnd = xs[xs.length - 1];
	      var yEnd = ys[ys.length - 1];

	      // Fallback: no pixel conversion available; use a simple data-space arrow.
	      if (!px || !py) {
	        var xPrev = xs[xs.length - 2];
	        var yPrev = ys[ys.length - 2];
	        var dx0 = xEnd - xPrev;
	        var dy0 = yEnd - yPrev;
	        var dist0 = Math.sqrt(dx0 * dx0 + dy0 * dy0);
	        if (!dist0) return [xEnd, yEnd, 0];
	        var ux0 = dx0 / dist0;
	        var uy0 = dy0 / dist0;
	        var off0 = Math.min(0.06, dist0 * 0.25);
	        var ax0 = xEnd - ux0 * off0;
	        var ay0 = yEnd - uy0 * off0;
	        var rad0 = Math.atan2(dy0, dx0);
	        var deg0 = (90 - (rad0 * 180 / Math.PI)) % 360;
	        if (deg0 < 0) deg0 += 360;
	        return [ax0, ay0, deg0];
	      }

	      var totalLen = 0.0;
	      for (var i = 1; i < px.length; i++) {
	        var sdx = px[i] - px[i - 1];
	        var sdy = py[i] - py[i - 1];
	        totalLen += Math.sqrt(sdx * sdx + sdy * sdy);
	      }
	      if (!totalLen) return [xEnd, yEnd, 0];

	      var dstSize = nodeSize[dstId];
	      var dstRadius = (dstSize !== undefined && dstSize !== null && isFinite(dstSize)) ? (dstSize / 2.0) : 7.0;
	      var pad = 8.0;
	      var targetOff = dstRadius + pad;
	      if (targetOff >= totalLen) targetOff = totalLen * 0.5;
	      targetOff = Math.min(targetOff, totalLen * 0.9);

	      // Walk backwards from the destination to find a point `targetOff` away along the curve.
	      var acc = 0.0;
	      var axp = px[px.length - 1];
	      var ayp = py[py.length - 1];
	      var tanDx = px[px.length - 1] - px[px.length - 2];
	      var tanDy = py[py.length - 1] - py[py.length - 2];

	      for (var i = px.length - 1; i > 0; i--) {
	        var dx = px[i] - px[i - 1];
	        var dy = py[i] - py[i - 1];
	        var segLen = Math.sqrt(dx * dx + dy * dy);
	        if (!segLen) continue;
	        if (acc + segLen >= targetOff) {
	          var back = (targetOff - acc) / segLen;
	          axp = px[i] - back * dx;
	          ayp = py[i] - back * dy;
	          tanDx = dx;
	          tanDy = dy;
	          break;
	        }
	        acc += segLen;
	      }

	      var ax = pxToAxis(xa, axp, false);
	      var ay = pxToAxis(ya, ayp, true);
	      if (ax === null || ay === null) {
	        ax = xEnd;
	        ay = yEnd;
	      }

	      // Plotly marker angles are screen-based; y increases downward in pixels.
	      var rad = Math.atan2(-tanDy, tanDx);
	      var deg = (90 - (rad * 180 / Math.PI)) % 360;
	      if (deg < 0) deg += 360;
	      return [ax, ay, deg];
	    }

	    var inc = incident[nodeId] || [];
	    for (var ii = 0; ii < inc.length; ii++) {
	      var e = inc[ii] || [];
	      var s = e[0];
	      var t = e[1];
	      if (!s || !t) continue;
	      var p0 = nodePos[s];
	      var p1 = nodePos[t];
	      if (!p0 || !p1) continue;

	      var c = curvePoints(s, t, p0[0], p0[1], p1[0], p1[1]);
	      var xs = c[0];
	      var ys = c[1];
	      var isK = (s === koreaLabel) || (t === koreaLabel);
	      var arr = arrowFor(xs, ys, t);

	      if (isK) {
	        koreaX = koreaX.concat(xs, [null]);
	        koreaY = koreaY.concat(ys, [null]);
	        koreaAx.push(arr[0]);
	        koreaAy.push(arr[1]);
	        koreaAa.push(arr[2]);
      } else {
        mainX = mainX.concat(xs, [null]);
        mainY = mainY.concat(ys, [null]);
        mainAx.push(arr[0]);
        mainAy.push(arr[1]);
        mainAa.push(arr[2]);
      }
    }
    return [mainX, mainY, koreaX, koreaY, mainAx, mainAy, mainAa, koreaAx, koreaAy, koreaAa];
  }

  function applyFocus(nodeId) {
    if (!nodeId) return;

    var keep = {};
    keep[nodeId] = true;
    var neigh = neighbors[nodeId] || {};
    for (var n in neigh) keep[n] = true;

    var sp = buildSelectedPoints(keep);
    var focus = buildFocusEdges(nodeId);

    Plotly.restyle(gd, {'selectedpoints': sp}, nodeTraceIdx);
    Plotly.restyle(gd, {'x': [focus[0], focus[2]], 'y': [focus[1], focus[3]]}, [focusMain, focusKorea]);
    Plotly.restyle(gd, {'x': [focus[4], focus[7]], 'y': [focus[5], focus[8]], 'marker.angle': [focus[6], focus[9]]}, [arrowsMain, arrowsKorea]);
    Plotly.restyle(gd, {'line.color': [DIM_MAIN_COLOR, DIM_KOREA_COLOR]}, [baseMain, baseKorea]);
  }

  function resetFocus() {
    var sp = [];
    for (var i = 0; i < nodeTraceIdx.length; i++) sp.push(null);
    Plotly.restyle(gd, {'selectedpoints': sp}, nodeTraceIdx);
    Plotly.restyle(gd, {'x': [[], []], 'y': [[], []]}, [focusMain, focusKorea]);
    Plotly.restyle(gd, {'x': [[], []], 'y': [[], []], 'marker.angle': [[], []]}, [arrowsMain, arrowsKorea]);
    Plotly.restyle(gd, {'line.color': [BASE_MAIN_COLOR, BASE_KOREA_COLOR]}, [baseMain, baseKorea]);
  }

  gd.on('plotly_hover', function(ev) {
    if (lockNode) return;
    if (!ev || !ev.points || !ev.points.length) return;
    var pt = ev.points[0] || {};
    var d = pt.data || {};
    if (traceRole(d) !== 'nodes') return;
    var cd = pt.customdata || [];
    var nodeId = cd[0];
    if (!nodeId) return;
    if (resetTimer) {
      clearTimeout(resetTimer);
      resetTimer = null;
    }
    applyFocus(nodeId);
  });

  gd.on('plotly_unhover', function() {
    if (lockNode) return;
    if (resetTimer) clearTimeout(resetTimer);
    resetTimer = setTimeout(function() {
      resetFocus();
      resetTimer = null;
    }, 80);
  });

  gd.on('plotly_click', function(ev) {
    if (!ev || !ev.points || !ev.points.length) return;
    var pt = ev.points[0] || {};
    var d = pt.data || {};
    if (traceRole(d) !== 'nodes') return;
    var cd = pt.customdata || [];
    var nodeId = cd[0];
    if (!nodeId) return;

    if (resetTimer) {
      clearTimeout(resetTimer);
      resetTimer = null;
    }

    if (lockNode === nodeId) {
      lockNode = null;
      resetFocus();
      return;
    }
    lockNode = nodeId;
    applyFocus(nodeId);
  });

  gd.on('plotly_doubleclick', function() {
    lockNode = null;
    if (resetTimer) {
      clearTimeout(resetTimer);
      resetTimer = null;
    }
    resetFocus();
  });
})();
"""


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Generate interactive (Plotly) versions of report figures into "
            "Data_Insight/Assets/Interactive/ (bar/line/scatter 중심)."
        )
    )
    parser.add_argument(
        "--run-tag",
        default=os.environ.get("RUN_TAG", "20251026"),
        help="Input filename prefix (default: env RUN_TAG or 20251026).",
    )
    parser.add_argument(
        "--in-dir",
        type=Path,
        default=Path("Output/Data_Insight"),
        help="Directory containing input CSVs (default: Output/Data_Insight).",
    )
    parser.add_argument(
        "--report-figures-dir",
        type=Path,
        default=Path("Output/Data_Insight/report_figures"),
        help="Directory containing report_figures CSVs (default: Output/Data_Insight/report_figures).",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("Data_Insight/Assets/Interactive"),
        help="Directory to write HTML files (default: Data_Insight/Assets/Interactive).",
    )
    return parser.parse_args()


def _apply_layout(fig: go.Figure, *, title: str | None = None) -> None:
    fig.update_layout(
        title=title,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        colorway=PLOTLY_COLORWAY,
        font=dict(color=TEXT_COLOR),
        margin=dict(l=40, r=220, t=70 if title else 20, b=40),
        legend=dict(
            bgcolor="rgba(255,255,255,0.6)",
            bordercolor="rgba(0,0,0,0.1)",
            borderwidth=1,
            x=1.02,
            y=1.0,
            xanchor="left",
            yanchor="top",
        ),
    )
    fig.update_xaxes(showgrid=True, gridcolor=GRID_COLOR, zeroline=False, automargin=True)
    fig.update_yaxes(showgrid=True, gridcolor=GRID_COLOR, zeroline=False, automargin=True)


def _write(fig: go.Figure, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.write_html(out_path, include_plotlyjs="cdn", full_html=True)


def _write_html(
    fig: go.Figure,
    out_path: Path,
    *,
    post_script: str | None = None,
    div_id: str | None = None,
) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.write_html(
        out_path,
        include_plotlyjs="cdn",
        full_html=True,
        post_script=post_script,
        div_id=div_id,
    )


def _row_normalize(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df.copy()
    sums = df.sum(axis=1).replace(0, np.nan)
    out = df.div(sums, axis=0).fillna(0)
    return out


def _tint_hex(hex_color: str, amount: float) -> str:
    """Mix a hex color with white. amount=0 keeps original, amount=1 becomes white."""
    s = str(hex_color).strip().lstrip("#")
    if len(s) != 6:
        return str(hex_color)
    try:
        r = int(s[0:2], 16) / 255.0
        g = int(s[2:4], 16) / 255.0
        b = int(s[4:6], 16) / 255.0
    except ValueError:
        return str(hex_color)
    amount = float(np.clip(amount, 0.0, 1.0))
    r2 = r + (1.0 - r) * amount
    g2 = g + (1.0 - g) * amount
    b2 = b + (1.0 - b) * amount
    return f"#{int(r2 * 255 + 0.5):02x}{int(g2 * 255 + 0.5):02x}{int(b2 * 255 + 0.5):02x}"


def _normalize_positions(coords: np.ndarray) -> np.ndarray:
    if coords.size == 0:
        return coords
    mins = coords.min(axis=0)
    maxs = coords.max(axis=0)
    span = np.where((maxs - mins) == 0, 1.0, (maxs - mins))
    norm = (coords - mins) / span
    return norm * 2.0 - 1.0


def _normalize_positions_centered(coords: np.ndarray) -> np.ndarray:
    if coords.size == 0:
        return coords
    coords = coords.astype(float, copy=True)
    coords -= coords.mean(axis=0, keepdims=True)
    max_abs = float(np.max(np.abs(coords))) if coords.size else 1.0
    if max_abs > 0:
        coords /= max_abs
    return coords


def _drl_positions(*, edges: pd.DataFrame, nodes: list[str]) -> dict[str, tuple[float, float]]:
    """Deterministic-ish DrL layout using igraph, mirroring the static report figure logic."""
    try:
        import igraph as ig  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("python-igraph is required for the flow network; install igraph.") from exc

    if not nodes:
        return {}

    idx = {node: i for i, node in enumerate(nodes)}
    pair_weight: dict[tuple[int, int], float] = {}
    for row in edges.itertuples(index=False):
        u = idx.get(str(row.exporter))
        v = idx.get(str(row.importer))
        if u is None or v is None or u == v:
            continue
        a, b = (u, v) if u < v else (v, u)
        pair_weight[(a, b)] = pair_weight.get((a, b), 0.0) + float(row.weight)

    g = ig.Graph(n=len(nodes), directed=False)
    g.vs["name"] = nodes
    if pair_weight:
        edge_list = list(pair_weight.keys())
        weights = [float(np.log1p(pair_weight[e])) for e in edge_list]
        g.add_edges(edge_list)
        g.es["weight"] = weights

    n = len(nodes)
    angles = np.linspace(0.0, 2 * np.pi, num=n, endpoint=False)
    seed = np.column_stack([np.cos(angles), np.sin(angles)]).tolist()
    coords = np.asarray(g.layout_drl(weights="weight", seed=seed, options="default").coords, dtype=float)
    coords = _normalize_positions_centered(coords)
    return {nodes[i]: (float(coords[i, 0]), float(coords[i, 1])) for i in range(n)}


def _fa2_positions(*, edges: pd.DataFrame, nodes: list[str], seed: int = 7) -> dict[str, tuple[float, float]]:
    try:
        import forceatlas2  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("forceatlas2 is required for the flow network; install forceatlas2.") from exc

    if not nodes:
        return {}

    idx = {node: i for i, node in enumerate(nodes)}
    n = len(nodes)
    a = np.zeros((n, n), dtype=float)

    for row in edges.itertuples(index=False):
        u = idx.get(str(row.exporter))
        v = idx.get(str(row.importer))
        if u is None or v is None or u == v:
            continue
        w = float(row.weight)
        w = float(np.log1p(max(w, 0.0)))
        a[u, v] += w
        a[v, u] += w

    np.fill_diagonal(a, 0.0)

    rng = np.random.default_rng(seed)
    init = rng.normal(size=(n, 2))
    coords = forceatlas2.forceatlas2(
        a,
        pos=init,
        niter=450,
        edgeWeightInfluence=1.0,
        jitterTolerance=1.0,
        scalingRatio=2.8,
        gravity=1.0,
        strongGravityMode=True,
    )
    coords = _normalize_positions(np.asarray(coords, dtype=float))
    return {node: (float(coords[idx[node], 0]), float(coords[idx[node], 1])) for node in nodes}


def fig01_pubyear_trend(*, run_tag: str, in_dir: Path) -> go.Figure:
    df = pd.read_csv(in_dir / f"{run_tag}_pubyear_trend_metrics.csv")
    df = df.dropna(subset=["year"]).copy()

    fig = make_subplots(
        rows=2,
        cols=1,
        shared_xaxes=True,
        row_heights=[0.66, 0.34],
        vertical_spacing=0.08,
        specs=[[{"secondary_y": True}], [{}]],
    )

    fig.add_trace(
        go.Scatter(
            x=df["year"],
            y=df["citations"],
            mode="lines+markers",
            name="Policy citations (count)",
            line=dict(color=AUX_PRIMARY, width=3),
            marker=dict(size=6),
            hovertemplate="Year=%{x}<br>Citations=%{y:,.0f}<extra></extra>",
        ),
        row=1,
        col=1,
        secondary_y=False,
    )
    fig.add_trace(
        go.Scatter(
            x=df["year"],
            y=df["policy_docs"],
            mode="lines+markers",
            name="Policy documents (with DOI citations)",
            line=dict(color=AUX_SECONDARY, width=3),
            marker=dict(size=6),
            hovertemplate="Year=%{x}<br>Policy docs=%{y:,.0f}<extra></extra>",
        ),
        row=1,
        col=1,
        secondary_y=True,
    )

    fig.add_trace(
        go.Scatter(
            x=df["year"],
            y=df["citations_per_doc"],
            mode="lines+markers",
            name="Citations per policy document",
            line=dict(color=AUX_TERTIARY, width=3),
            marker=dict(size=6),
            hovertemplate="Year=%{x}<br>Citations/doc=%{y:.2f}<extra></extra>",
        ),
        row=2,
        col=1,
    )

    fig.update_yaxes(title_text="Policy citations", row=1, col=1, secondary_y=False)
    fig.update_yaxes(title_text="Policy documents", row=1, col=1, secondary_y=True)
    fig.update_yaxes(title_text="Citations per document", row=2, col=1)
    fig.update_xaxes(title_text="Publication year (policy documents)", row=2, col=1)

    _apply_layout(fig, title="Policy documents by publication year (DOI citations)")
    return fig


def fig02_domain_top10(*, run_tag: str, in_dir: Path, report_figures_dir: Path) -> go.Figure:
    df = pd.read_csv(in_dir / f"{run_tag}_domain_counts.csv")
    df["domain"] = df["domain"].fillna("Unknown").replace({"": "Unknown"})
    df = df.sort_values("citation_rows", ascending=False).head(10).copy()
    df["citation_rows"] = df["citation_rows"].astype(float)

    top_domains = [d for d in DOMAIN_ORDER if d in df["domain"].tolist()]
    if not top_domains:
        top_domains = df[df["domain"].ne("Unknown")]["domain"].head(4).tolist()

    field_cache = report_figures_dir / f"{run_tag}_domain_field_counts.csv"
    if not field_cache.exists():
        fig = px.bar(
            df,
            x="citation_rows",
            y="domain",
            orientation="h",
            color="domain",
            category_orders={"domain": DOMAIN_ORDER + ["Unknown"]},
            color_discrete_map=DOMAIN_COLORS,
            labels={"citation_rows": "Citations", "domain": "Domain"},
            hover_data={"citation_rows": ":,.0f"},
        )
        fig.update_yaxes(autorange="reversed")
        fig.update_xaxes(tickformat="~s")
        _apply_layout(fig, title="Policy citations by domain (top 10)")
        return fig

    field_df = pd.read_csv(field_cache)
    field_df = field_df.dropna(subset=["domain", "field", "citation_rows"]).copy()
    field_df["domain"] = field_df["domain"].astype(str).str.strip()
    field_df["field"] = field_df["field"].astype(str).str.strip()
    field_df = field_df[(field_df["domain"].isin(top_domains)) & (field_df["field"].ne(""))].copy()

    top_k = 3
    top_fields_by_domain: dict[str, list[str]] = {}
    for domain in top_domains:
        dom_fields = field_df[field_df["domain"] == domain].nlargest(top_k, "citation_rows")["field"].tolist()
        top_fields_by_domain[domain] = dom_fields

    highlight_fields = sorted({f for fields in top_fields_by_domain.values() for f in fields})

    domain_totals = df.set_index("domain")["citation_rows"].to_dict()
    field_totals = field_df.groupby(["domain", "field"], as_index=False)["citation_rows"].sum()
    domain_field_sum = (
        field_totals.groupby("domain", as_index=False)["citation_rows"]
        .sum()
        .rename(columns={"citation_rows": "domain_total_raw"})
    )
    field_totals = field_totals.merge(domain_field_sum, on="domain", how="left")
    field_totals["share"] = field_totals["citation_rows"] / field_totals["domain_total_raw"].replace(0, np.nan)

    plot_domains = [d for d in df["domain"].tolist() if d in top_domains]
    if "Unknown" in domain_totals:
        plot_domains.append("Unknown")

    shade_levels = [0.0, 0.32, 0.58]
    field_color: dict[str, str] = {}
    for domain in top_domains:
        base = DOMAIN_COLORS.get(domain, CORE_PRIMARY)
        segs: list[tuple[str, float]] = []
        for field in top_fields_by_domain.get(domain, []):
            share_val = float(
                field_totals[(field_totals["domain"] == domain) & (field_totals["field"] == field)]["share"]
                .fillna(0)
                .sum()
            )
            segs.append((field, float(domain_totals.get(domain, 0.0)) * share_val))
        segs = [(f, v) for f, v in segs if v > 0]
        segs.sort(key=lambda x: x[1], reverse=True)
        for rank, (field, _val) in enumerate(segs):
            field_color[field] = _tint_hex(base, shade_levels[min(rank, len(shade_levels) - 1)])

    values_by_field: dict[str, list[float]] = {}
    for field in highlight_fields:
        vals: list[float] = []
        for domain in plot_domains:
            if domain == "Unknown":
                vals.append(0.0)
                continue
            share_val = float(
                field_totals[(field_totals["domain"] == domain) & (field_totals["field"] == field)]["share"]
                .fillna(0)
                .sum()
            )
            vals.append(float(domain_totals.get(domain, 0.0)) * share_val)
        values_by_field[field] = vals

    field_order = sorted(highlight_fields, key=lambda f: float(np.sum(values_by_field.get(f, []))), reverse=True)

    used = np.zeros(len(plot_domains), dtype=float)
    for field in field_order:
        used += np.asarray(values_by_field[field], dtype=float)

    other_vals: list[float] = []
    for i, domain in enumerate(plot_domains):
        total = float(domain_totals.get(domain, 0.0))
        if domain == "Unknown":
            other_vals.append(total)
        else:
            other_vals.append(max(total - float(used[i]), 0.0))

    fig = go.Figure()
    for field in field_order:
        fig.add_trace(
            go.Bar(
                x=values_by_field[field],
                y=plot_domains,
                orientation="h",
                name=field,
                marker_color=field_color.get(field, CORE_PRIMARY),
                hovertemplate="%{y}<br>Field=%{fullData.name}<br>Citations=%{x:,.0f}<extra></extra>",
            )
        )
    fig.add_trace(
        go.Bar(
            x=other_vals,
            y=plot_domains,
            orientation="h",
            name="Other",
            marker_color=DOMAIN_COLORS["Unknown"],
            hovertemplate="%{y}<br>Field=Other<br>Citations=%{x:,.0f}<extra></extra>",
        )
    )

    fig.update_layout(barmode="stack")
    fig.update_yaxes(categoryorder="array", categoryarray=plot_domains, autorange="reversed")
    fig.update_xaxes(tickformat="~s")
    _apply_layout(fig, title="Policy citations by domain (top 4; stacked by field)")
    fig.update_layout(legend=dict(x=1.02, y=0.0, xanchor="left", yanchor="bottom"))
    return fig


def fig03_topic_scatter(*, run_tag: str, in_dir: Path) -> go.Figure:
    df = pd.read_csv(in_dir / f"{run_tag}_topic_metrics.csv")
    df = df.dropna(subset=["topic", "domain", "citation_rows", "unique_papers", "oa_share"]).copy()
    df = df[(df["citation_rows"] > 0) & (df["unique_papers"] > 0)].copy()

    x_med = float(df["unique_papers"].median())
    y_med = float(df["citation_rows"].median())

    fig = px.scatter(
        df,
        x="unique_papers",
        y="citation_rows",
        color="domain",
        size="oa_share",
        size_max=34,
        log_x=True,
        log_y=True,
        category_orders={"domain": DOMAIN_ORDER},
        color_discrete_map=DOMAIN_COLORS,
        hover_name="topic",
        hover_data={
            "domain": True,
            "unique_papers": ":,.0f",
            "citation_rows": ":,.0f",
            "oa_share": ":.0%",
        },
        labels={"unique_papers": "Unique papers (log)", "citation_rows": "Citations (log)"},
    )
    fig.add_vline(x=x_med, line_dash="dash", line_color=REFERENCE_COLOR, opacity=0.9)
    fig.layout.shapes[-1].update(layer="below")
    fig.add_hline(y=y_med, line_dash="dash", line_color=REFERENCE_COLOR, opacity=0.9)
    fig.layout.shapes[-1].update(layer="below")
    _apply_layout(fig, title="Topics: citations vs unique papers (size=OA share)")
    return fig


def fig04_topic_intensity_vs_recency(*, run_tag: str, in_dir: Path) -> go.Figure:
    df = pd.read_csv(in_dir / f"{run_tag}_topic_intensity_recency.csv")
    required = {"topic", "domain", "intensity", "recent_paper_share"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(
            "Topic metric input uses the legacy citation-row recency definition. "
            "Run scripts/make_topic_intensity_recency.py first. "
            f"Missing columns: {sorted(missing)}"
        )
    df = df.dropna(subset=list(required)).copy()
    df = df[df["intensity"] > 0].copy()

    fig = px.scatter(
        df,
        x="intensity",
        y="recent_paper_share",
        color="domain",
        category_orders={"domain": DOMAIN_ORDER},
        color_discrete_map=DOMAIN_COLORS,
        hover_name="topic",
        hover_data={
            "domain": True,
            "intensity": ":.2f",
            "recent_paper_share": ":.2%",
            "citation_rows": ":,.0f",
            "unique_papers": ":,.0f",
            "recent_papers": ":,.0f",
            "known_year_papers": ":,.0f",
        },
        labels={
            "intensity": "Policy citations per paper",
            "recent_paper_share": "Share of unique papers published in 2022-2024",
            "recent_papers": "Unique papers published in 2022-2024",
            "known_year_papers": "Unique papers with known year through 2024",
        },
    )
    intensity = df["intensity"].astype(float).replace([np.inf, -np.inf], np.nan).dropna()
    if len(intensity):
        intensity_mean = float(intensity.mean())
        fig.add_vline(x=intensity_mean, line_dash="dash", line_color=REFERENCE_COLOR, opacity=0.8)
        fig.layout.shapes[-1].update(layer="below")
    recent_mean = float(df["recent_paper_share"].astype(float).mean())
    fig.add_hline(y=recent_mean, line_dash="dash", line_color=REFERENCE_COLOR, opacity=0.8)
    fig.layout.shapes[-1].update(layer="below")
    _apply_layout(fig, title="Policy citations per paper and 2022-2024 unique-paper share by topic")
    return fig


def fig05_country_citations_top10_plus_kr(*, run_tag: str, in_dir: Path) -> go.Figure:
    df = pd.read_csv(in_dir / f"{run_tag}_country_citations.csv")
    df = df.dropna(subset=["country", "citation_rows"]).copy()
    df["country"] = df["country"].astype(str).map(_normalize_korea_label)
    df = df.groupby("country", as_index=False).agg({"citation_rows": "sum", "citing_policy_docs": "sum"})

    top10 = df.nlargest(10, "citation_rows").copy()
    korea = df[df["country"] == KOREA_DISPLAY_LABEL].copy()
    if korea.empty:
        korea = df[df["country"].astype(str).str.contains("Korea", case=False, na=False)].copy()
        korea = korea.nlargest(1, "citation_rows").copy()

    plot_df = pd.concat([top10, korea], ignore_index=True).drop_duplicates(subset=["country"], keep="first")
    plot_df = plot_df.sort_values("citation_rows", ascending=False).copy()
    countries = plot_df["country"].tolist()

    plot_df["citing_policy_docs"] = plot_df["citing_policy_docs"].replace(0, np.nan)
    plot_df["citations_per_policy_doc"] = plot_df["citation_rows"] / plot_df["citing_policy_docs"]

    dom = pd.read_csv(in_dir / f"{run_tag}_country_domain_matrix.csv")
    dom = dom.dropna(subset=["country", "domain", "citation_rows"]).copy()
    dom["country"] = dom["country"].astype(str).map(_normalize_korea_label)
    dom["domain"] = dom["domain"].fillna("Unknown").replace({"": "Unknown"})
    dom = dom[dom["country"].isin(countries)].copy()
    dom = dom[dom["domain"].isin(DOMAIN_ORDER)].copy()
    dom = dom.groupby(["country", "domain"], as_index=False)["citation_rows"].sum()

    grid = pd.MultiIndex.from_product([countries, DOMAIN_ORDER], names=["country", "domain"])
    dom = dom.set_index(["country", "domain"]).reindex(grid, fill_value=0).reset_index()
    pivot = dom.pivot_table(index="country", columns="domain", values="citation_rows", fill_value=0)
    pivot = pivot.reindex(index=countries, columns=DOMAIN_ORDER, fill_value=0)
    shares = _row_normalize(pivot)

    fig = make_subplots(
        rows=1,
        cols=3,
        shared_yaxes=True,
        column_widths=[0.3, 0.25, 0.45],
        horizontal_spacing=0.04,
        subplot_titles=(
            "A. Total citations",
            "B. Citations per citing policy doc",
            "C. Domain composition",
        ),
    )

    fig.add_trace(
        go.Bar(
            x=plot_df["citation_rows"],
            y=countries,
            orientation="h",
            marker=dict(color=AUX_PRIMARY),
            hovertemplate="%{y}<br>Citations: %{x:,.0f}<extra></extra>",
            showlegend=False,
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Bar(
            x=plot_df["citations_per_policy_doc"],
            y=countries,
            orientation="h",
            marker=dict(color=AUX_SECONDARY),
            hovertemplate="%{y}<br>Citations per citing policy doc: %{x:.2f}<extra></extra>",
            showlegend=False,
        ),
        row=1,
        col=2,
    )
    for domain in DOMAIN_ORDER:
        fig.add_trace(
            go.Bar(
                x=shares[domain],
                y=countries,
                orientation="h",
                name=domain,
                marker=dict(color=DOMAIN_COLORS.get(domain, NEUTRAL_GRAY)),
                hovertemplate="%{y}<br>%{fullData.name}: %{x:.1%}<extra></extra>",
                showlegend=True,
            ),
            row=1,
            col=3,
        )

    fig.update_layout(barmode="stack")
    _apply_layout(fig, title=f"Policy citations by policy source country (top 10 + {KOREA_DISPLAY_LABEL})")

    fig.update_layout(margin=dict(l=110, r=240, t=90, b=40))
    fig.update_yaxes(title_text="Policy source country", row=1, col=1)
    fig.update_yaxes(autorange="reversed", showgrid=False, row=1, col=1)
    fig.update_yaxes(autorange="reversed", showgrid=False, row=1, col=2, showticklabels=False, title_text="")
    fig.update_yaxes(autorange="reversed", showgrid=False, row=1, col=3, showticklabels=False, title_text="")

    fig.update_xaxes(title_text="Citations", tickformat="~s", row=1, col=1)
    fig.update_xaxes(title_text="Citations per citing policy document", tickformat=".1f", row=1, col=2)
    fig.update_xaxes(title_text="Share within policy source (normalized)", range=[0, 1], tickformat=".0%", row=1, col=3)
    return fig


def fig06_country_domain_portfolio_top10_plus_kr(*, run_tag: str, in_dir: Path) -> go.Figure:
    totals = pd.read_csv(in_dir / f"{run_tag}_country_citations.csv")
    totals = totals.dropna(subset=["country", "citation_rows"]).copy()
    totals["country"] = totals["country"].astype(str).map(_normalize_korea_label)
    totals = totals.groupby("country", as_index=False).agg({"citation_rows": "sum", "citing_policy_docs": "sum"})
    totals = totals.sort_values("citation_rows", ascending=False)

    top10 = totals.head(10)[["country", "citation_rows"]].copy()
    korea = totals[totals["country"] == KOREA_DISPLAY_LABEL][["country", "citation_rows"]].copy()
    selected = pd.concat([top10, korea], ignore_index=True).drop_duplicates(subset=["country"], keep="first")
    selected = selected.sort_values("citation_rows", ascending=False)

    dom = pd.read_csv(in_dir / f"{run_tag}_country_domain_matrix.csv")
    dom = dom.dropna(subset=["country", "domain", "citation_rows"]).copy()
    dom["country"] = dom["country"].astype(str).map(_normalize_korea_label)
    dom["domain"] = dom["domain"].fillna("Unknown").replace({"": "Unknown"})
    dom = dom[dom["country"].isin(selected["country"])].copy()
    dom = dom[dom["domain"].isin(DOMAIN_ORDER)].copy()
    dom = dom.groupby(["country", "domain"], as_index=False)["citation_rows"].sum()

    grid = pd.MultiIndex.from_product([selected["country"].tolist(), DOMAIN_ORDER], names=["country", "domain"])
    dom = dom.set_index(["country", "domain"]).reindex(grid, fill_value=0).reset_index()

    dom_tot = dom.groupby("country", as_index=False)["citation_rows"].sum().rename(columns={"citation_rows": "total"})
    dom = dom.merge(dom_tot, on="country", how="left")
    dom["share"] = dom["citation_rows"] / dom["total"].replace(0, np.nan)

    fig = px.bar(
        dom,
        x="share",
        y="country",
        color="domain",
        orientation="h",
        color_discrete_map=DOMAIN_COLORS,
        labels={
            "share": "Share within policy source (normalized)",
            "country": "Policy source country",
            "domain": "Domain",
        },
        hover_data={"citation_rows": ":,.0f", "share": ":.1%"},
    )
    fig.update_layout(barmode="stack")
    fig.update_yaxes(categoryorder="array", categoryarray=selected["country"].tolist(), autorange="reversed")
    fig.update_xaxes(range=[0, 1], tickformat=".0%")
    _apply_layout(fig, title=f"Domain composition of policy citations (top 10 + {KOREA_DISPLAY_LABEL})")
    fig.update_yaxes(showgrid=False)
    return fig


def fig06_country_domain_demand_supply_scatter_top50(*, run_tag: str, in_dir: Path) -> go.Figure:
    import duckdb
    import pycountry

    domain_order = DOMAIN_ORDER
    domain_colors = DOMAIN_COLORS
    subplot_domains = [
        ("Social Sciences", 1, 1),
        ("Health Sciences", 1, 2),
        ("Physical Sciences", 2, 1),
        ("Life Sciences", 2, 2),
    ]

    x_max = 0.9
    y_max = 0.5
    diag_max = min(x_max, y_max)

    country_citations = pd.read_csv(in_dir / f"{run_tag}_country_citations.csv")
    country_citations = country_citations.dropna(subset=["country", "citation_rows"]).copy()
    country_citations = country_citations[~country_citations["country"].astype(str).str.contains(">", regex=False)].copy()
    country_citations = country_citations[~country_citations["country"].isin(["IGO", "EU"])].copy()
    country_citations["country"] = country_citations["country"].astype(str).map(_normalize_korea_label)
    country_citations = country_citations.groupby("country", as_index=False).agg({"citation_rows": "sum", "citing_policy_docs": "sum"})
    country_citations = country_citations.sort_values("citation_rows", ascending=False).copy()

    top50 = country_citations.head(50)["country"].tolist()
    if KOREA_DISPLAY_LABEL not in top50:
        top50.append(KOREA_DISPLAY_LABEL)

    default_visible = set(country_citations.head(10)["country"].tolist())
    default_visible.add(KOREA_DISPLAY_LABEL)

    special_iso2 = {
        "USA": "US",
        "UK": "GB",
        "Russia": "RU",
        KOREA_DISPLAY_LABEL: "KR",
        KOREA_POLICY_SOURCE_RAW_LABEL: "KR",
        "Turkey": "TR",
    }

    def _label_to_iso2(label: str) -> str | None:
        label = str(label).strip()
        if not label:
            return None
        if label in special_iso2:
            return special_iso2[label]
        try:
            return str(pycountry.countries.lookup(label).alpha_2)
        except LookupError:
            return None

    country_to_iso2: dict[str, str] = {}
    for label in top50:
        iso2 = _label_to_iso2(label)
        if iso2 is None:
            continue
        country_to_iso2[label] = iso2
    iso2_to_country = {iso2: label for label, iso2 in country_to_iso2.items()}
    iso2_list = sorted(set(country_to_iso2.values()))

    demand = pd.read_csv(in_dir / f"{run_tag}_country_domain_matrix.csv")
    demand = demand.dropna(subset=["country", "domain", "citation_rows"]).copy()
    demand["country"] = demand["country"].astype(str).map(_normalize_korea_label)
    demand = demand[demand["country"].isin(list(country_to_iso2.keys()))].copy()
    demand = demand[demand["domain"].isin(domain_order)].copy()
    demand = demand.groupby(["country", "domain"], as_index=False)["citation_rows"].sum()
    grid = pd.MultiIndex.from_product([list(country_to_iso2.keys()), domain_order], names=["country", "domain"])
    demand = demand.set_index(["country", "domain"]).reindex(grid, fill_value=0).reset_index()
    demand_tot = demand.groupby("country", as_index=False)["citation_rows"].sum().rename(columns={"citation_rows": "demand_total"})
    demand = demand.merge(demand_tot, on="country", how="left")
    demand["demand_share"] = demand["citation_rows"] / demand["demand_total"].replace(0, np.nan)

    con = duckdb.connect()
    iso_list = ",".join([f"'{c}'" for c in iso2_list]) if iso2_list else "''"
    supply_rows = con.execute(
        f"""
        WITH work_domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('Data/openalex_topics.parquet')
          WHERE domain IS NOT NULL
            AND domain <> ''
        )
        SELECT o.first_author_country AS iso2,
               d.domain AS domain,
               COUNT(*) AS citation_rows
        FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
        JOIN work_domains d USING (oaid_w)
        JOIN read_parquet('Data/matched_openalex_with_oa_country_unique.parquet') o USING (oaid_w)
        WHERE o.first_author_country IN ({iso_list})
        GROUP BY 1, 2
        """
    ).df()
    con.close()

    supply_rows["country"] = supply_rows["iso2"].map(iso2_to_country)
    supply_rows = supply_rows.dropna(subset=["country", "domain", "citation_rows"]).copy()
    supply_rows = supply_rows[supply_rows["domain"].isin(domain_order)].copy()
    supply_rows = supply_rows.groupby(["country", "domain"], as_index=False)["citation_rows"].sum()
    supply_rows = supply_rows.set_index(["country", "domain"]).reindex(grid, fill_value=0).reset_index()
    supply_tot = (
        supply_rows.groupby("country", as_index=False)["citation_rows"]
        .sum()
        .rename(columns={"citation_rows": "supply_total"})
    )
    supply = supply_rows.merge(supply_tot, on="country", how="left")
    supply["supply_share"] = supply["citation_rows"] / supply["supply_total"].replace(0, np.nan)

    combined = demand[["country", "domain", "demand_share", "demand_total"]].merge(
        supply[["country", "domain", "supply_share", "supply_total"]],
        on=["country", "domain"],
        how="inner",
    )
    combined = combined.dropna(subset=["demand_share", "supply_share"]).copy()

    size_base = combined.groupby("country", as_index=False)[["demand_total", "supply_total"]].max()
    size_base["volume"] = (size_base["demand_total"] + size_base["supply_total"]).clip(lower=1).astype(float)
    v_log = np.log10(size_base["volume"])
    if v_log.nunique() > 1:
        v_norm = (v_log - float(v_log.min())) / (float(v_log.max()) - float(v_log.min()))
        size_base["marker"] = 8.0 + v_norm * 20.0
    else:
        size_base["marker"] = 14.0
    marker_map = dict(zip(size_base["country"], size_base["marker"]))

    fig = make_subplots(
        rows=2,
        cols=2,
        shared_xaxes=True,
        shared_yaxes=True,
        subplot_titles=[d for d, _, _ in subplot_domains],
        horizontal_spacing=0.08,
        vertical_spacing=0.12,
    )

    for domain, row, col in subplot_domains:
        fig.add_shape(
            type="line",
            x0=0,
            y0=0,
            x1=diag_max,
            y1=diag_max,
            line=dict(color=REFERENCE_COLOR, dash="dash", width=1),
            row=row,
            col=col,
        )

    def _fmt_short(v: float) -> str:
        v = float(v)
        if v >= 1_000_000:
            return f"{v/1_000_000:.1f}M"
        if v >= 1_000:
            return f"{v/1_000:.0f}K"
        return f"{v:.0f}"

    legend_cols = ["legend", "legend3", "legend4"]
    legend_assign: dict[str, str] = {country: legend_cols[i % 3] for i, country in enumerate(top50)}

    for country in top50:
        if country not in marker_map:
            continue
        visible = True if country in default_visible else "legendonly"
        country_legend = legend_assign.get(country, "legend")
        for domain, row, col in subplot_domains:
            sub = combined[(combined["country"] == country) & (combined["domain"] == domain)]
            if sub.empty:
                continue
            r = sub.iloc[0]
            fig.add_trace(
                go.Scatter(
                    x=[float(r["demand_share"])],
                    y=[float(r["supply_share"])],
                    mode="markers",
                    name=country,
                    legendgroup=country,
                    showlegend=(domain == subplot_domains[0][0]),
                    legend=country_legend,
                    visible=visible,
                    marker=dict(
                        size=float(marker_map[country]),
                        color=domain_colors.get(domain, CORE_PRIMARY),
                        opacity=0.78,
                        line=dict(color="white", width=1),
                    ),
                    customdata=[[domain, float(r["demand_total"]), float(r["supply_total"]), float(r["demand_total"] + r["supply_total"])]],
                    hovertemplate=(
                        "<b>%{text}</b><br>"
                        "Domain=%{customdata[0]}<br>"
                        "Research cited by policy documents=%{x:.1%}<br>"
                        "Country's research cited by policy documents=%{y:.1%}<br>"
                        "Policy citations=%{customdata[1]:,.0f}<br>"
                        "Research citations=%{customdata[2]:,.0f}<br>"
                        "Total volume=%{customdata[3]:,.0f}"
                        "<extra></extra>"
                    ),
                    text=[country],
                ),
                row=row,
                col=col,
            )

    size_values = (
        np.quantile(size_base["volume"].to_numpy(dtype=float), [0.25, 0.5, 0.75]).astype(float).tolist()
        if len(size_base)
        else []
    )
    size_values = sorted({float(v) for v in size_values if v > 0})
    if len(size_values) < 3 and len(size_base):
        size_values = np.quantile(size_base["volume"].to_numpy(dtype=float), [0.1, 0.5, 0.9]).astype(float).tolist()
        size_values = sorted({float(v) for v in size_values if v > 0})
    if len(size_values) > 3:
        size_values = [size_values[0], size_values[len(size_values) // 2], size_values[-1]]

    v_min = float(v_log.min()) if len(v_log) else 0.0
    v_max = float(v_log.max()) if len(v_log) else 1.0

    def _size_for_volume(v: float) -> float:
        v = float(max(v, 1.0))
        v_logv = float(np.log10(v))
        if v_log.nunique() <= 1 or v_max == v_min:
            return 14.0
        frac = (v_logv - v_min) / (v_max - v_min)
        return 8.0 + float(np.clip(frac, 0.0, 1.0)) * 20.0

    for i, v in enumerate(size_values):
        fig.add_trace(
            go.Scatter(
                x=[None],
                y=[None],
                mode="markers",
                marker=dict(
                    size=_size_for_volume(v),
                    color="rgba(214, 227, 216, 0.45)",
                    line=dict(color="white", width=1),
                ),
                name=_fmt_short(v),
                showlegend=True,
                legend="legend2",
                legendgroup="Citation volume",
                legendgrouptitle_text="Citation count\n(policy source + research country)" if i == 0 else None,
            )
        )

    fig.update_xaxes(range=[0, x_max], tickformat=".0%")
    fig.update_yaxes(range=[0, y_max], tickformat=".0%")
    fig.update_xaxes(title_text="Domain share of research cited by policy documents", row=2, col=1)
    fig.update_xaxes(title_text="Domain share of research cited by policy documents", row=2, col=2)
    fig.update_yaxes(title_text="Domain share of each country's research cited by policy documents", row=1, col=1)
    fig.update_yaxes(title_text="Domain share of each country's research cited by policy documents", row=2, col=1)

    fig.update_layout(
        title="Selected countries (top 50): domain composition of research cited by policy documents and domestic research cited in policy documents",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color=TEXT_COLOR),
        hovermode="closest",
        # Keep legends outside the subplot area without overlapping each other.
        # A smaller right margin increases plot width, which also increases the pixel spacing
        # between legend columns (legend x positions are in paper coordinates).
        margin=dict(l=50, r=420, t=80, b=55),
        legend=dict(
            title="Country (click to toggle)",
            bgcolor="rgba(255,255,255,0.6)",
            bordercolor="rgba(0,0,0,0.1)",
            borderwidth=1,
            x=1.02,
            y=1.0,
            xanchor="left",
            yanchor="top",
            groupclick="togglegroup",
        ),
        legend3=dict(
            bgcolor="rgba(255,255,255,0.6)",
            bordercolor="rgba(0,0,0,0.1)",
            borderwidth=1,
            x=1.22,
            y=1.0,
            xanchor="left",
            yanchor="top",
            groupclick="togglegroup",
        ),
        legend4=dict(
            bgcolor="rgba(255,255,255,0.6)",
            bordercolor="rgba(0,0,0,0.1)",
            borderwidth=1,
            x=1.42,
            y=1.0,
            xanchor="left",
            yanchor="top",
            groupclick="togglegroup",
        ),
        legend2=dict(
            bgcolor="rgba(255,255,255,0.6)",
            bordercolor="rgba(0,0,0,0.1)",
            borderwidth=1,
            x=1.02,
            y=0.0,
            xanchor="left",
            yanchor="bottom",
            itemclick=False,
            itemdoubleclick=False,
        ),
    )
    fig.update_xaxes(showgrid=True, gridcolor=GRID_COLOR, zeroline=False)
    fig.update_yaxes(showgrid=True, gridcolor=GRID_COLOR, zeroline=False)
    return fig


def fig07_source_type_citations_top10(*, run_tag: str, in_dir: Path) -> go.Figure:
    df = pd.read_csv(in_dir / f"{run_tag}_source_type_citations.csv")
    df = df.dropna(subset=["source_type", "citation_rows"]).copy()
    df = df.nlargest(10, "citation_rows").sort_values("citation_rows", ascending=False)

    fig = px.bar(
        df,
        x="citation_rows",
        y="source_type",
        orientation="h",
        color_discrete_sequence=[AUX_PRIMARY],
        labels={"citation_rows": "Citations", "source_type": "Source type"},
        hover_data={"citation_rows": ":,.0f"},
    )
    fig.update_yaxes(autorange="reversed")
    fig.update_xaxes(tickformat="~s")
    _apply_layout(fig, title="Citations by policy source type (top 10)")
    fig.update_yaxes(showgrid=False)
    return fig


def fig08_source_type_density(*, run_tag: str, report_figures_dir: Path) -> go.Figure:
    df = pd.read_csv(report_figures_dir / f"{run_tag}_source_type_citations_per_policy_doc.csv")
    df = df.dropna(subset=["source_type", "citations_per_policy_doc"]).copy()
    df = df.sort_values("citations_per_policy_doc", ascending=False)

    fig = px.bar(
        df,
        x="citations_per_policy_doc",
        y="source_type",
        orientation="h",
        color_discrete_sequence=[AUX_PRIMARY],
        labels={
            "citations_per_policy_doc": "Citations per citing policy document",
            "source_type": "Source type",
        },
        hover_data={
            "citation_rows": ":,.0f",
            "policy_docs": ":,.0f",
            "citing_policy_docs": ":,.0f",
            "citations_per_policy_doc": ":.2f",
        },
    )
    fig.update_yaxes(autorange="reversed")
    _apply_layout(
        fig,
        title="Citations per citing policy document by policy source type (selected types)",
    )
    fig.update_yaxes(showgrid=False)
    return fig


def fig09_source_type_domain_heatmap(*, run_tag: str, in_dir: Path) -> go.Figure:
    mat = pd.read_csv(in_dir / f"{run_tag}_source_type_domain_matrix.csv")
    mat = mat.dropna(subset=["source_type", "domain", "citation_rows"]).copy()
    mat["source_type"] = mat["source_type"].astype(str).str.strip()
    mat["domain"] = mat["domain"].astype(str).str.strip()
    mat = mat[mat["domain"] != ""].copy()
    mat["major_type"] = mat["source_type"].astype(str).str.split(">").str[0].str.strip()

    major_order = (
        mat.groupby("major_type")["citation_rows"]
        .sum()
        .sort_values(ascending=False)
        .index.astype(str)
        .tolist()
    )
    source_major_map = mat.drop_duplicates(subset=["source_type"]).set_index("source_type")["major_type"].to_dict()

    # Select source types that cover ~90% of citations within each major type.
    source_totals = (
        mat.groupby(["major_type", "source_type"], as_index=False)["citation_rows"]
        .sum()
        .sort_values(["major_type", "citation_rows"], ascending=[True, False])
        .copy()
    )
    selected_types: list[str] = []
    for major in major_order:
        sub = source_totals[source_totals["major_type"] == major].copy()
        if sub.empty:
            continue
        sub["share"] = sub["citation_rows"] / sub["citation_rows"].sum()
        sub["cum_share"] = sub["share"].cumsum()
        keep = sub[sub["cum_share"] <= 0.9]
        if keep.empty:
            keep = sub.head(1)
        else:
            last_idx = keep.index[-1]
            if float(sub.loc[last_idx, "cum_share"]) < 0.9 and len(keep) < len(sub):
                keep = sub.head(len(keep) + 1)
        selected_types.extend(keep["source_type"].astype(str).tolist())

    # Order within each major by total citations (descending).
    pivot_abs = mat.pivot_table(index="source_type", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0)
    ordered_types: list[str] = []
    for major in major_order:
        group = [s for s in selected_types if source_major_map.get(s) == major]
        group = sorted(group, key=lambda s: float(pivot_abs.sum(axis=1).get(s, 0.0)), reverse=True)
        ordered_types.extend(group)
    for s in selected_types:
        if s not in ordered_types:
            ordered_types.append(s)

    pivot_abs_sel = pivot_abs.reindex(index=ordered_types, fill_value=0)
    domains_raw = pivot_abs_sel.sum(axis=0).sort_values(ascending=False).head(6).index.astype(str).tolist()
    domains_extra = [d for d in domains_raw if d not in DOMAIN_ORDER and d != "Unknown"]
    domain_order = [d for d in DOMAIN_ORDER if d in domains_raw] + domains_extra
    if "Unknown" in domains_raw:
        domain_order.append("Unknown")
    pivot_abs_sel = pivot_abs_sel.reindex(columns=domain_order, fill_value=0)
    pivot_share = pivot_abs_sel.div(pivot_abs_sel.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0)

    share_grid = pivot_share.T.to_numpy(dtype=float)
    citations_grid = pivot_abs_sel.T.to_numpy(dtype=float)
    major_by_type = [str(source_major_map.get(s, "")) for s in ordered_types]
    major_grid = np.tile(np.array(major_by_type, dtype=object), (len(domain_order), 1))
    customdata = np.stack([citations_grid, major_grid], axis=-1)

    def _fmt_cell(v: float) -> str:
        v = float(v)
        if not np.isfinite(v) or v <= 0:
            return ""
        p = v * 100.0
        if p < 1:
            return "<1%"
        return f"{int(round(p))}%"

    text = np.vectorize(_fmt_cell, otypes=[object])(share_grid)
    short_types = [s.split(">")[-1].strip() for s in ordered_types]

    fig = go.Figure(
        data=[
            go.Heatmap(
                z=share_grid,
                x=ordered_types,
                y=domain_order,
                zmin=0.0,
                zmax=0.60,
                colorscale=HEATMAP_SCALE,
                customdata=customdata,
                hovertemplate=(
                    "Domain=%{y}<br>"
                    "Policy source type=%{x}<br>"
                    "Major type=%{customdata[1]}<br>"
                    "Citations=%{customdata[0]:,.0f}<br>"
                    "Share=%{z:.1%}<extra></extra>"
                ),
                text=text,
                texttemplate="%{text}",
                textfont=dict(color=TEXT_COLOR, size=12),
                colorbar=dict(
                    title="Share within source type",
                    tickvals=[0.0, 0.2, 0.4, 0.6],
                    ticktext=["0%", "20%", "40%", ">60%"],
                ),
                xgap=1,
                ygap=1,
            )
        ]
    )
    fig.update_yaxes(autorange="reversed", title_text="Domain")
    fig.update_xaxes(
        title_text="Policy source type",
        categoryorder="array",
        categoryarray=ordered_types,
        tickmode="array",
        tickvals=ordered_types,
        ticktext=short_types,
        tickangle=45,
    )
    _apply_layout(fig, title="Share heatmap: domain × policy source type (selected; source-type normalized)")
    fig.update_layout(margin=dict(l=120, r=80, t=90, b=110), showlegend=False)
    fig.update_yaxes(showgrid=False)
    fig.update_xaxes(showgrid=False)
    return fig


def fig10_policy_to_research_country_heatmap(*, run_tag: str, in_dir: Path) -> go.Figure:
    mat = pd.read_csv(
        in_dir / f"{run_tag}_policy_country_research_country.csv",
        keep_default_na=False,
    )
    mat = mat.dropna(subset=["policy_country", "research_country", "citation_rows"]).copy()
    mat["policy_country"] = mat["policy_country"].astype(str).map(_normalize_korea_label)
    mat["research_country"] = mat["research_country"].astype(str).str.strip()

    pivot_full = mat.pivot_table(
        index="policy_country",
        columns="research_country",
        values="citation_rows",
        aggfunc="sum",
        fill_value=0,
    )
    pol_top = pivot_full.sum(axis=1).sort_values(ascending=False).head(12).index.astype(str).tolist()
    res_top = pivot_full.sum(axis=0).sort_values(ascending=False).head(12).index.astype(str).tolist()
    pivot_plot = pivot_full.reindex(index=pol_top, columns=res_top, fill_value=0)

    pivot_share = pivot_full.div(pivot_full.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0)

    special_rows = [r for r in ["IGO", "EU"] if r in pol_top and r in pivot_share.index]
    main_rows = [r for r in pol_top if r not in special_rows]
    row_order = special_rows + [r for r in main_rows if r in pivot_share.index]

    policy_to_iso2 = {
        "USA": "US",
        "UK": "GB",
        "Germany": "DE",
        "France": "FR",
        "Canada": "CA",
        "Australia": "AU",
        "Sweden": "SE",
        "Netherlands": "NL",
        "Finland": "FI",
        "Ireland": "IE",
        "Spain": "ES",
        "Italy": "IT",
        "Japan": "JP",
        "Brazil": "BR",
        "Switzerland": "CH",
        "Norway": "NO",
        "Denmark": "DK",
        "New Zealand": "NZ",
        "Austria": "AT",
        "Belgium": "BE",
        KOREA_POLICY_SOURCE_RAW_LABEL: "KR",
        KOREA_DISPLAY_LABEL: "KR",
        "China": "CN",
        "India": "IN",
    }
    policy_iso2 = [policy_to_iso2.get(r) for r in row_order if policy_to_iso2.get(r)]
    policy_iso2 = [c for c in policy_iso2 if c in pivot_share.columns]

    # Panel A: reorder top research columns to align with the policy list.
    col_order_abs = [c for c in policy_iso2 if c in res_top] + [c for c in res_top if c not in set(policy_iso2)]
    abs_a = pivot_plot.reindex(index=row_order, columns=col_order_abs, fill_value=0)

    # Panel B: align columns to the policy list, then group the remaining research countries.
    share_full = pivot_share.reindex(index=row_order, fill_value=0.0)
    share_sym = share_full.reindex(columns=policy_iso2, fill_value=0.0)

    europe_other = {
        "NL",
        "IT",
        "CH",
        "DK",
        "NO",
        "FI",
        "AT",
        "IE",
        "PT",
        "PL",
        "CZ",
        "HU",
        "RO",
        "SK",
        "SI",
        "HR",
        "BG",
        "LT",
        "LV",
        "EE",
        "LU",
        "IS",
        "RU",
        "UA",
        "BY",
        "RS",
        "BA",
        "ME",
        "MK",
        "AL",
        "MD",
        "XK",
        "TR",
        "GR",
    }
    asia_pacific = {
        "CN",
        "JP",
        "KR",
        "IN",
        "SG",
        "TW",
        "HK",
        "MY",
        "TH",
        "ID",
        "PH",
        "VN",
        "PK",
        "BD",
        "LK",
        "NP",
        "MM",
        "KH",
        "LA",
        "MN",
        "KZ",
        "UZ",
        "AE",
        "SA",
        "IR",
        "IQ",
        "IL",
        "JO",
        "QA",
        "KW",
        "BH",
        "OM",
        "LB",
        "SY",
        "YE",
        "AF",
        "BT",
        "MO",
        "BN",
    }

    other_cols = [c for c in share_full.columns if c not in set(policy_iso2)]
    group_map: dict[str, str] = {}
    for iso in other_cols:
        if iso in europe_other:
            group_map[iso] = "Other (Europe)"
        elif iso in asia_pacific:
            group_map[iso] = "Other (Asia-Pacific)"
        else:
            group_map[iso] = "Other (Rest)"
    grouped_share = share_full[other_cols].T.groupby(group_map).sum().T
    group_order = [g for g in ["Other (Europe)", "Other (Asia-Pacific)", "Other (Rest)"] if g in grouped_share.columns]
    grouped_share = grouped_share.reindex(columns=group_order, fill_value=0.0)
    share_b = pd.concat([share_sym, grouped_share], axis=1)

    abs_full = pivot_full.reindex(index=row_order, fill_value=0.0)
    abs_sym = abs_full.reindex(columns=policy_iso2, fill_value=0.0)
    grouped_abs = abs_full[other_cols].T.groupby(group_map).sum().T.reindex(columns=group_order, fill_value=0.0)
    abs_b = pd.concat([abs_sym, grouped_abs], axis=1)

    abs_x = abs_a.columns.astype(str).tolist()
    abs_x_labels = [_iso2_to_display_label(c) for c in abs_x]
    abs_y = abs_a.index.astype(str).tolist()

    z_abs = abs_a.replace(0, np.nan).to_numpy(dtype=float)
    z_abs = np.log10(z_abs)
    label_grid_a = np.tile(np.array(abs_x_labels, dtype=object), (len(abs_y), 1))
    custom_a = np.stack([abs_a.to_numpy(dtype=float), label_grid_a], axis=-1)

    share_x = share_b.columns.astype(str).tolist()
    share_x_labels = [_iso2_to_display_label(c) if len(c) == 2 else c for c in share_x]
    share_y = share_b.index.astype(str).tolist()

    share_grid = share_b.to_numpy(dtype=float)
    label_grid_b = np.tile(np.array(share_x_labels, dtype=object), (len(share_y), 1))
    custom_b = np.stack([abs_b.to_numpy(dtype=float), label_grid_b], axis=-1)

    def _pct_label(v: float) -> str:
        v = float(v)
        if not np.isfinite(v) or v <= 0:
            return ""
        p = v * 100
        if p < 1:
            return "<1%"
        return f"{int(round(p))}%"

    text_b = np.vectorize(_pct_label, otypes=[object])(share_grid)

    fig = make_subplots(
        rows=1,
        cols=2,
        shared_yaxes=True,
        horizontal_spacing=0.08,
        subplot_titles=("A. Citation count (log10 scale)", "B. Share within policy source (cap at 30%)"),
    )
    fig.add_trace(
        go.Heatmap(
            z=z_abs,
            x=abs_x,
            y=abs_y,
            zmin=1.0,
            zmax=float(np.nanmax(z_abs)) if np.isfinite(z_abs).any() else 1.0,
            colorscale=HEATMAP_SCALE,
            colorbar=dict(title="Citations (log10)", x=0.46),
            customdata=custom_a,
            hovertemplate=(
                "Policy source=%{y}<br>"
                "Research=%{customdata[1]}<br>"
                "Citations=%{customdata[0]:,.0f}<extra></extra>"
            ),
            xgap=1,
            ygap=1,
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Heatmap(
            z=share_grid,
            x=share_x,
            y=share_y,
            zmin=0.0,
            zmax=0.30,
            colorscale=HEATMAP_SCALE,
            colorbar=dict(
                title="Share within policy source",
                x=1.02,
                tickvals=[0.0, 0.1, 0.2, 0.3],
                ticktext=["0%", "10%", "20%", ">30%"],
            ),
            text=text_b,
            texttemplate="%{text}",
            textfont=dict(color=TEXT_COLOR, size=10),
            customdata=custom_b,
            hovertemplate=(
                "Policy source=%{y}<br>"
                "Research=%{customdata[1]}<br>"
                "Share=%{z:.1%}<br>"
                "Citations=%{customdata[0]:,.0f}<extra></extra>"
            ),
            xgap=1,
            ygap=1,
        ),
        row=1,
        col=2,
    )

    fig.update_xaxes(
        tickmode="array",
        tickvals=abs_x,
        ticktext=abs_x_labels,
        tickangle=45,
        row=1,
        col=1,
    )
    fig.update_xaxes(
        tickmode="array",
        tickvals=share_x,
        ticktext=share_x_labels,
        tickangle=45,
        row=1,
        col=2,
    )
    fig.update_yaxes(title_text="Policy source entity", row=1, col=1)
    fig.update_yaxes(showticklabels=False, row=1, col=2)
    fig.update_layout(
        title="Policy source → Research country citations",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color=TEXT_COLOR),
        margin=dict(l=130, r=110, t=90, b=130),
        hovermode="closest",
        showlegend=False,
    )
    fig.update_xaxes(showgrid=False)
    fig.update_yaxes(showgrid=False)
    return fig


def fig11_self_citation_share_selected(*, run_tag: str, in_dir: Path, report_figures_dir: Path) -> go.Figure:
    df = pd.read_csv(report_figures_dir / f"{run_tag}_policy_country_self_share_selected.csv")
    df = df.dropna(subset=["policy_country", "self_share"]).copy()
    df = df.sort_values("self_share", ascending=False)
    order = df["policy_country"].astype(str).tolist()

    known_path = in_dir / f"{run_tag}_policy_country_self_share_known.csv"
    overall = 0.0
    if known_path.exists():
        known = pd.read_csv(known_path)
        denom = float(known["known_citations"].sum())
        overall = float(known["self_citations"].sum() / denom) if denom else 0.0

    dom = pd.read_csv(in_dir / f"{run_tag}_country_domain_matrix.csv")
    dom = dom.dropna(subset=["country", "domain", "citation_rows"]).copy()
    dom["country"] = dom["country"].astype(str).map(_normalize_korea_label)
    dom = dom[dom["country"].isin(order)].copy()
    dom = dom[dom["domain"].isin(DOMAIN_ORDER)].copy()
    dom_pivot = dom.pivot_table(index="country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0)
    dom_pivot = dom_pivot.reindex(index=order, columns=DOMAIN_ORDER, fill_value=0)
    dom_share = _row_normalize(dom_pivot)

    fig = make_subplots(
        rows=1,
        cols=3,
        shared_yaxes=True,
        horizontal_spacing=0.08,
        column_widths=[0.34, 0.30, 0.36],
        subplot_titles=(
            "A. Domestic-citation share",
            "B. Domestic-citation vs domain-adjusted reference",
            "C. Domain composition of cited research",
        ),
    )

    fig.add_trace(
        go.Bar(
            x=df["self_share"],
            y=df["policy_country"],
            orientation="h",
            marker_color=AUX_SECONDARY,
            hovertemplate=(
                "%{y}<br>"
                "Domestic-citation share=%{x:.2%}<br>"
                "Known citations=%{customdata[0]:,.0f}<br>"
                "Domestic citations=%{customdata[1]:,.0f}"
                "<extra></extra>"
            ),
            customdata=np.stack([df["known_citations"].to_numpy(), df["self_citations"].to_numpy()], axis=1),
            showlegend=False,
        ),
        row=1,
        col=1,
    )
    fig.add_vline(
        x=overall,
        row=1,
        col=1,
        line_dash="dash",
        line_color=REFERENCE_COLOR,
        opacity=0.9,
    )
    fig.add_annotation(
        x=overall,
        y=0.06,
        xref="x",
        yref="y domain",
        text=f"Overall: {overall:.1%}",
        showarrow=False,
        xanchor="left",
        font=dict(color=REFERENCE_TEXT),
    )

    delta_pp = df.get("delta_pp")
    if delta_pp is not None:
        delta_pp = delta_pp.astype(float).fillna(0.0)
    else:
        delta_pp = pd.Series([0.0] * len(df), index=df.index)
    max_abs = float(np.nanmax(np.abs(delta_pp.to_numpy(dtype=float)))) if len(delta_pp) else 1.0
    max_abs = max(max_abs, 1.0)
    max_abs = float(np.ceil(max_abs / 2.0) * 2.0)

    fig.add_trace(
        go.Bar(
            x=delta_pp,
            y=df["policy_country"],
            orientation="h",
            marker_color=AUX_PRIMARY,
            hovertemplate="%{y}<br>Observed − reference=%{x:+.1f} pp<extra></extra>",
            showlegend=False,
        ),
        row=1,
        col=2,
    )
    fig.add_vline(x=0, row=1, col=2, line_dash="dash", line_color=REFERENCE_COLOR, opacity=0.9)

    for domain in DOMAIN_ORDER:
        fig.add_trace(
            go.Bar(
                x=dom_share[domain],
                y=dom_share.index,
                orientation="h",
                name=domain,
                legendgroup="domain",
                marker_color=DOMAIN_COLORS.get(domain, CORE_PRIMARY),
                hovertemplate="%{y}<br>Domain=%{fullData.name}<br>Share=%{x:.1%}<extra></extra>",
                showlegend=True,
            ),
            row=1,
            col=3,
        )

    fig.update_layout(barmode="stack")
    fig.update_yaxes(categoryorder="array", categoryarray=order, autorange="reversed", row=1, col=1)
    fig.update_yaxes(categoryorder="array", categoryarray=order, autorange="reversed", row=1, col=2)
    fig.update_yaxes(categoryorder="array", categoryarray=order, autorange="reversed", row=1, col=3)
    fig.update_yaxes(showticklabels=False, row=1, col=2)
    fig.update_yaxes(showticklabels=False, row=1, col=3)

    fig.update_xaxes(
        range=[0, 1],
        tickformat=".0%",
        title_text="Share (%)<br>(first-author country available only)",
        row=1,
        col=1,
    )
    fig.update_xaxes(
        range=[-max_abs, max_abs],
        tickformat="+.0f",
        title_text="Observed − reference (pp)<br>(domain-adjusted linked-sample reference)",
        row=1,
        col=2,
    )
    fig.update_xaxes(
        range=[0, 1],
        tickformat=".0%",
        title_text="Share within policy source (normalized)",
        row=1,
        col=3,
    )

    _apply_layout(
        fig,
        title=(
            "Domestic-citation share vs domain-adjusted reference and domain composition "
            f"(top 7 policy countries + {KOREA_DISPLAY_LABEL})"
        ),
    )
    x0 = 0.67
    try:
        x0 = float(fig.layout.xaxis3.domain[0])
    except Exception:
        pass
    fig.update_layout(legend=dict(x=x0 - 0.03, y=0.02, xanchor="left", yanchor="bottom", bgcolor="rgba(255,255,255,0.6)"))
    fig.update_yaxes(showgrid=False, row=1, col=1)
    fig.update_yaxes(showgrid=False, row=1, col=2)
    fig.update_yaxes(showgrid=False, row=1, col=3)
    return fig


def fig12_korea_flows(*, run_tag: str, report_figures_dir: Path) -> go.Figure:
    import duckdb
    import pycountry

    df = pd.read_csv(report_figures_dir / f"{run_tag}_korea_policy_research_flows_top10.csv")
    df = df.dropna(subset=["direction", "entity", "citation_rows"]).copy()

    inbound = df[df["direction"].str.startswith("Inbound")].sort_values("citation_rows", ascending=False)
    outbound = df[df["direction"].str.startswith("Outbound")].sort_values("citation_rows", ascending=False)

    inbound_entities = inbound["entity"].astype(str).tolist()
    outbound_entities = outbound["entity"].astype(str).tolist()

    special_label_to_iso2 = {
        "USA": "US",
        "UK": "GB",
        KOREA_DISPLAY_LABEL: "KR",
        KOREA_POLICY_SOURCE_RAW_LABEL: "KR",
    }

    def label_to_iso2(label: str) -> str | None:
        label = str(label).strip()
        if not label:
            return None
        if label in special_label_to_iso2:
            return special_label_to_iso2[label]
        try:
            return str(pycountry.countries.lookup(label).alpha_2)
        except LookupError:
            return None

    outbound_iso2: list[str] = []
    outbound_labels: list[str] = []
    for lab in outbound_entities:
        iso2 = label_to_iso2(lab)
        if not iso2:
            continue
        outbound_iso2.append(iso2)
        outbound_labels.append(_normalize_korea_label(lab))

    def _sql_quote(s: str) -> str:
        return "'" + str(s).replace("'", "''") + "'"

    inbound_entities_sql = [
        (KOREA_POLICY_SOURCE_RAW_LABEL if _normalize_korea_label(c) == KOREA_DISPLAY_LABEL else c) for c in inbound_entities
    ]
    inbound_list = ",".join([_sql_quote(c) for c in inbound_entities_sql]) if inbound_entities_sql else "''"
    outbound_list = ",".join([_sql_quote(c) for c in outbound_iso2]) if outbound_iso2 else "''"
    domain_list = ",".join([_sql_quote(d) for d in DOMAIN_ORDER])

    con = duckdb.connect()
    inbound_domains = con.execute(
        f"""
        WITH policy_country AS (
          SELECT DISTINCT
            policy_document_id,
            split_part(policy_source_country, ' > ', 1) AS policy_country
          FROM read_parquet('Data/overton_policy_meta/policy_source_country.parquet')
          WHERE policy_source_country IS NOT NULL
        ),
        kr_works AS (
          SELECT DISTINCT oaid_w
          FROM read_parquet('Data/matched_openalex_with_oa_country_unique.parquet')
          WHERE first_author_country = 'KR'
        ),
        work_domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('Data/openalex_topics.parquet')
          WHERE domain IS NOT NULL
        )
        SELECT
          pc.policy_country,
          wd.domain,
          COUNT(*) AS citation_rows
        FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
        JOIN policy_country pc USING (policy_document_id)
        JOIN kr_works k USING (oaid_w)
        JOIN work_domains wd USING (oaid_w)
        WHERE pc.policy_country IN ({inbound_list})
          AND wd.domain IN ({domain_list})
        GROUP BY 1, 2
        """
    ).df()

    outbound_domains = con.execute(
        f"""
        WITH policy_country AS (
          SELECT DISTINCT
            policy_document_id,
            split_part(policy_source_country, ' > ', 1) AS policy_country
          FROM read_parquet('Data/overton_policy_meta/policy_source_country.parquet')
          WHERE policy_source_country IS NOT NULL
        ),
        work_country AS (
          SELECT oaid_w, first_author_country
          FROM read_parquet('Data/matched_openalex_with_oa_country_unique.parquet')
          WHERE first_author_country IS NOT NULL
        ),
        work_domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('Data/openalex_topics.parquet')
          WHERE domain IS NOT NULL
        )
        SELECT
          wc.first_author_country AS research_country,
          wd.domain,
          COUNT(*) AS citation_rows
        FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
        JOIN policy_country pc USING (policy_document_id)
        JOIN work_country wc USING (oaid_w)
        JOIN work_domains wd USING (oaid_w)
        WHERE pc.policy_country = '{KOREA_POLICY_SOURCE_RAW_LABEL}'
          AND wc.first_author_country IN ({outbound_list})
          AND wd.domain IN ({domain_list})
        GROUP BY 1, 2
        """
    ).df()

    inbound_non_kr_domains = con.execute(
        f"""
        WITH policy_country AS (
          SELECT DISTINCT
            policy_document_id,
            split_part(policy_source_country, ' > ', 1) AS policy_country
          FROM read_parquet('Data/overton_policy_meta/policy_source_country.parquet')
          WHERE policy_source_country IS NOT NULL
        ),
        work_country AS (
          SELECT oaid_w, first_author_country
          FROM read_parquet('Data/matched_openalex_with_oa_country_unique.parquet')
          WHERE first_author_country IS NOT NULL
        ),
        work_domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('Data/openalex_topics.parquet')
          WHERE domain IS NOT NULL
        )
        SELECT
          pc.policy_country,
          wd.domain,
          COUNT(*) AS citation_rows
        FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
        JOIN policy_country pc USING (policy_document_id)
        JOIN work_country wc USING (oaid_w)
        JOIN work_domains wd USING (oaid_w)
        WHERE pc.policy_country IN ({inbound_list})
          AND wc.first_author_country <> ''
          AND wc.first_author_country <> 'KR'
          AND wd.domain IN ({domain_list})
        GROUP BY 1, 2
        """
    ).df()

    outbound_non_kr_policy_domains = con.execute(
        f"""
        WITH policy_country AS (
          SELECT DISTINCT
            policy_document_id,
            split_part(policy_source_country, ' > ', 1) AS policy_country
          FROM read_parquet('Data/overton_policy_meta/policy_source_country.parquet')
          WHERE policy_source_country IS NOT NULL
        ),
        work_country AS (
          SELECT oaid_w, first_author_country
          FROM read_parquet('Data/matched_openalex_with_oa_country_unique.parquet')
          WHERE first_author_country IS NOT NULL
        ),
        work_domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('Data/openalex_topics.parquet')
          WHERE domain IS NOT NULL
        )
        SELECT
          wc.first_author_country AS research_country,
          wd.domain,
          COUNT(*) AS citation_rows
        FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
        JOIN policy_country pc USING (policy_document_id)
        JOIN work_country wc USING (oaid_w)
        JOIN work_domains wd USING (oaid_w)
        WHERE pc.policy_country NOT IN ('{KOREA_POLICY_SOURCE_RAW_LABEL}', 'Korea', '{KOREA_DISPLAY_LABEL}')
          AND wc.first_author_country IN ({outbound_list})
          AND wd.domain IN ({domain_list})
        GROUP BY 1, 2
        """
    ).df()
    con.close()

    inbound_domains["policy_country"] = inbound_domains["policy_country"].astype(str).map(_normalize_korea_label)
    inbound_domains = inbound_domains.dropna(subset=["policy_country", "domain", "citation_rows"]).copy()
    in_pivot = inbound_domains.pivot_table(
        index="policy_country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0
    )
    in_pivot = in_pivot.reindex(index=inbound_entities, columns=DOMAIN_ORDER, fill_value=0)
    in_share = _row_normalize(in_pivot)

    inbound_non_kr_domains["policy_country"] = inbound_non_kr_domains["policy_country"].astype(str).map(_normalize_korea_label)
    inbound_non_kr_domains = inbound_non_kr_domains.dropna(subset=["policy_country", "domain", "citation_rows"]).copy()
    in_non_pivot = inbound_non_kr_domains.pivot_table(
        index="policy_country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0
    )
    in_non_pivot = in_non_pivot.reindex(index=inbound_entities, columns=DOMAIN_ORDER, fill_value=0)
    in_non_share = _row_normalize(in_non_pivot)

    outbound_domains = outbound_domains.dropna(subset=["research_country", "domain", "citation_rows"]).copy()
    out_pivot = outbound_domains.pivot_table(
        index="research_country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0
    )
    out_pivot = out_pivot.reindex(index=outbound_iso2, columns=DOMAIN_ORDER, fill_value=0)
    out_share = _row_normalize(out_pivot)
    out_share.index = outbound_labels

    outbound_non_kr_policy_domains = outbound_non_kr_policy_domains.dropna(subset=["research_country", "domain", "citation_rows"]).copy()
    out_non_pivot = outbound_non_kr_policy_domains.pivot_table(
        index="research_country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0
    )
    out_non_pivot = out_non_pivot.reindex(index=outbound_iso2, columns=DOMAIN_ORDER, fill_value=0)
    out_non_share = _row_normalize(out_non_pivot)
    out_non_share.index = outbound_labels

    has_expected = "expected_share" in df.columns
    has_delta = "delta_pp" in df.columns

    def _bar_text(share: float, expected_share: float | None) -> str:
        if expected_share is None or not np.isfinite(float(expected_share)):
            return f"{float(share):.1%}"
        return f"{float(share):.1%} (ref. {float(expected_share):.1%})"

    fig = make_subplots(
        rows=2,
        cols=2,
        row_heights=[0.55, 0.45],
        vertical_spacing=0.16,
        horizontal_spacing=0.10,
        subplot_titles=(
            "A. Policy sources citing KR first-author research",
            f"B. Research countries cited by {KOREA_DISPLAY_LABEL} policy",
            "C. Domain mix of cited research (KR vs non-KR)",
            "D. Domain mix of cited research (KR vs non-KR policy)",
        ),
    )

    fig.add_trace(
        go.Bar(
            x=inbound["citation_rows"],
            y=inbound["entity"],
            orientation="h",
            marker_color=AUX_SECONDARY,
            customdata=(
                np.stack(
                    [
                        inbound["share"].astype(float).to_numpy(),
                        (inbound["expected_share"].astype(float) if has_expected else pd.Series([np.nan] * len(inbound))).to_numpy(),
                        (inbound["delta_pp"].astype(float) if has_delta else pd.Series([np.nan] * len(inbound))).to_numpy(),
                    ],
                    axis=1,
                )
                if (has_expected or has_delta)
                else inbound["share"]
            ),
            text=[
                _bar_text(s, e)
                for s, e in zip(
                    inbound["share"].astype(float).tolist(),
                    (inbound["expected_share"].astype(float).tolist() if has_expected else [None] * len(inbound)),
                )
            ],
            textposition="outside",
            cliponaxis=False,
            hovertemplate=(
                "%{y}<br>Citations=%{x:,.0f}<br>Share=%{customdata[0]:.1%}<br>"
                "Reference=%{customdata[1]:.1%}<br>Δ=%{customdata[2]:+.1f}pp<extra></extra>"
                if (has_expected or has_delta)
                else "%{y}<br>Citations=%{x:,.0f}<br>Share=%{customdata:.1%}<extra></extra>"
            ),
            showlegend=False,
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Bar(
            x=outbound["citation_rows"],
            y=outbound["entity"],
            orientation="h",
            marker_color=AUX_SECONDARY,
            customdata=(
                np.stack(
                    [
                        outbound["share"].astype(float).to_numpy(),
                        (outbound["expected_share"].astype(float) if has_expected else pd.Series([np.nan] * len(outbound))).to_numpy(),
                        (outbound["delta_pp"].astype(float) if has_delta else pd.Series([np.nan] * len(outbound))).to_numpy(),
                    ],
                    axis=1,
                )
                if (has_expected or has_delta)
                else outbound["share"]
            ),
            text=[
                _bar_text(s, e)
                for s, e in zip(
                    outbound["share"].astype(float).tolist(),
                    (outbound["expected_share"].astype(float).tolist() if has_expected else [None] * len(outbound)),
                )
            ],
            textposition="outside",
            cliponaxis=False,
            hovertemplate=(
                "%{y}<br>Citations=%{x:,.0f}<br>Share=%{customdata[0]:.1%}<br>"
                "Reference=%{customdata[1]:.1%}<br>Δ=%{customdata[2]:+.1f}pp<extra></extra>"
                if (has_expected or has_delta)
                else "%{y}<br>Citations=%{x:,.0f}<br>Share=%{customdata:.1%}<extra></extra>"
            ),
            showlegend=False,
        ),
        row=1,
        col=2,
    )

    for domain in DOMAIN_ORDER:
        fig.add_trace(
            go.Bar(
                x=in_share[domain],
                y=in_share.index,
                orientation="h",
                name=domain,
                legendgroup=domain,
                offsetgroup="kr_research",
                marker_color=DOMAIN_COLORS.get(domain, CORE_PRIMARY),
                hovertemplate="%{y}<br>Group=KR research<br>Domain=%{fullData.name}<br>Share=%{x:.1%}<extra></extra>",
                showlegend=False,
            ),
            row=2,
            col=1,
        )
        fig.add_trace(
            go.Bar(
                x=in_non_share[domain],
                y=in_non_share.index,
                orientation="h",
                name=domain,
                legendgroup=domain,
                offsetgroup="non_kr_research",
                marker_color=DOMAIN_COLORS.get(domain, CORE_PRIMARY),
                hovertemplate="%{y}<br>Group=Non-KR research<br>Domain=%{fullData.name}<br>Share=%{x:.1%}<extra></extra>",
                showlegend=False,
            ),
            row=2,
            col=1,
        )
        fig.add_trace(
            go.Bar(
                x=out_share[domain],
                y=out_share.index,
                orientation="h",
                name=domain,
                legendgroup=domain,
                offsetgroup="kr_policy",
                marker_color=DOMAIN_COLORS.get(domain, CORE_PRIMARY),
                hovertemplate="%{y}<br>Group=KR policy<br>Domain=%{fullData.name}<br>Share=%{x:.1%}<extra></extra>",
                showlegend=True,
            ),
            row=2,
            col=2,
        )
        fig.add_trace(
            go.Bar(
                x=out_non_share[domain],
                y=out_non_share.index,
                orientation="h",
                name=domain,
                legendgroup=domain,
                offsetgroup="non_kr_policy",
                marker_color=DOMAIN_COLORS.get(domain, CORE_PRIMARY),
                hovertemplate="%{y}<br>Group=Non-KR policy<br>Domain=%{fullData.name}<br>Share=%{x:.1%}<extra></extra>",
                showlegend=False,
            ),
            row=2,
            col=2,
        )

    fig.update_layout(barmode="stack", height=760)
    fig.update_xaxes(tickformat="~s", title_text="Citations to KR research", row=1, col=1)
    fig.update_xaxes(
        tickformat="~s",
        title_text="Citations from KR policy<br>(first-author country available only)",
        row=1,
        col=2,
    )
    fig.update_xaxes(
        range=[0, 1],
        tickformat=".0%",
        title_text="Domain share in citations to KR research (normalized)",
        row=2,
        col=1,
    )
    fig.update_xaxes(
        range=[0, 1],
        tickformat=".0%",
        title_text="Domain share in citations by KR policy documents (normalized)",
        row=2,
        col=2,
    )

    fig.update_yaxes(categoryorder="array", categoryarray=inbound_entities, autorange="reversed", row=1, col=1)
    fig.update_yaxes(categoryorder="array", categoryarray=inbound_entities, autorange="reversed", row=2, col=1)
    fig.update_yaxes(categoryorder="array", categoryarray=outbound_entities, autorange="reversed", row=1, col=2)
    fig.update_yaxes(categoryorder="array", categoryarray=outbound_entities, autorange="reversed", row=2, col=2)
    fig.update_yaxes(showgrid=False, row=1, col=1)
    fig.update_yaxes(showgrid=False, row=1, col=2)
    fig.update_yaxes(showgrid=False, row=2, col=1)
    fig.update_yaxes(showgrid=False, row=2, col=2)

    _apply_layout(
        fig,
        title=(
            f"Policy sources citing {KOREA_DISPLAY_LABEL}-authored research and research countries cited by "
            f"{KOREA_DISPLAY_LABEL} policy documents (top 10; DOI-matched, first-author country)"
        ),
    )
    fig.update_yaxes(showgrid=False)
    return fig


def fig13_policy_research_flow_network_drl(*, run_tag: str, report_figures_dir: Path) -> go.Figure:
    edges = pd.read_csv(report_figures_dir / f"{run_tag}_policy_research_flow_network_edges.csv")
    edges = edges.dropna(subset=["exporter", "importer", "weight"]).copy()
    edges["exporter"] = edges["exporter"].astype(str)
    edges["importer"] = edges["importer"].astype(str)
    edge_pairs = set(zip(edges["exporter"], edges["importer"]))

    exporter_set = set(edges["exporter"].tolist())
    importer_set = set(edges["importer"].tolist())
    korea_label = KOREA_DISPLAY_LABEL
    korea_kind = f"{korea_label} (highlight)"
    label_overrides = {
        korea_label: "Republic of<br>Korea",
    }

    out_sum = edges.groupby("exporter", as_index=True)["weight"].sum()
    in_sum = edges.groupby("importer", as_index=True)["weight"].sum()
    nodes_raw = sorted(set(exporter_set).union(importer_set))
    total_raw = out_sum.add(in_sum, fill_value=0).reindex(nodes_raw).fillna(0)
    nodes = total_raw.sort_values(ascending=False).index.tolist()
    total = total_raw.reindex(nodes).fillna(0)
    max_total = float(total.max()) if not total.empty else 1.0
    sizes = 10 + 26 * np.sqrt(total.to_numpy(dtype=float) / max_total)

    pos = _drl_positions(edges=edges, nodes=nodes)
    if not pos:
        raise ValueError("No nodes found for the flow network.")

    def _curve_points(
        x0: float,
        y0: float,
        x1: float,
        y1: float,
        *,
        curvature: float,
        steps: int = 12,
    ) -> tuple[list[float], list[float]]:
        if curvature == 0.0:
            return [x0, x1], [y0, y1]
        dx = x1 - x0
        dy = y1 - y0
        dist = float(np.hypot(dx, dy))
        if dist == 0.0:
            return [x0, x1], [y0, y1]
        nx = -dy / dist
        ny = dx / dist
        cx = (x0 + x1) / 2.0 + curvature * dist * nx
        cy = (y0 + y1) / 2.0 + curvature * dist * ny
        ts = np.linspace(0.0, 1.0, steps, dtype=float)
        xs = ((1 - ts) ** 2) * x0 + (2 * (1 - ts) * ts) * cx + (ts**2) * x1
        ys = ((1 - ts) ** 2) * y0 + (2 * (1 - ts) * ts) * cy + (ts**2) * y1
        return xs.tolist(), ys.tolist()

    edge_main_x: list[float | None] = []
    edge_main_y: list[float | None] = []
    edge_korea_x: list[float | None] = []
    edge_korea_y: list[float | None] = []
    for row in edges.itertuples(index=False):
        src = str(row.exporter)
        dst = str(row.importer)
        x0, y0 = pos[src]
        x1, y1 = pos[dst]
        bidirectional = (dst, src) in edge_pairs and src != dst
        curvature = 0.22 if bidirectional else 0.0
        seg_x, seg_y = _curve_points(x0, y0, x1, y1, curvature=curvature)
        if src == korea_label or dst == korea_label:
            edge_korea_x += [*seg_x, None]
            edge_korea_y += [*seg_y, None]
        else:
            edge_main_x += [*seg_x, None]
            edge_main_y += [*seg_y, None]

    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=edge_main_x,
            y=edge_main_y,
            mode="lines",
            line=dict(color="rgba(47, 127, 109, 0.22)", width=1.2),
            hoverinfo="skip",
            showlegend=False,
            meta=dict(role="edges_base_main"),
        )
    )
    fig.add_trace(
        go.Scatter(
            x=edge_korea_x,
            y=edge_korea_y,
            mode="lines",
            line=dict(color="rgba(201, 108, 80, 0.55)", width=2.2),
            hoverinfo="skip",
            showlegend=False,
            meta=dict(role="edges_base_korea"),
        )
    )
    fig.add_trace(
        go.Scatter(
            x=[],
            y=[],
            mode="lines",
            line=dict(color="rgba(47, 127, 109, 0.60)", width=2.6),
            hoverinfo="skip",
            showlegend=False,
            meta=dict(role="edges_focus_main"),
        )
    )
    fig.add_trace(
        go.Scatter(
            x=[],
            y=[],
            mode="lines",
            line=dict(color="rgba(201, 108, 80, 0.60)", width=3.0),
            hoverinfo="skip",
            showlegend=False,
            meta=dict(role="edges_focus_korea"),
        )
    )
    fig.add_trace(
        go.Scatter(
            x=[],
            y=[],
            mode="markers",
            marker=dict(
                symbol="triangle-up",
                size=10,
                color="rgba(47, 127, 109, 0.92)",
                line=dict(color="white", width=1),
            ),
            hoverinfo="skip",
            showlegend=False,
            meta=dict(role="arrows_focus_main"),
        )
    )
    fig.add_trace(
        go.Scatter(
            x=[],
            y=[],
            mode="markers",
            marker=dict(
                symbol="triangle-up",
                size=10,
                color="rgba(201, 108, 80, 0.95)",
                line=dict(color="white", width=1),
            ),
            hoverinfo="skip",
            showlegend=False,
            meta=dict(role="arrows_focus_korea"),
        )
    )

    def _node_kind(node: str) -> str:
        if node == korea_label:
            return korea_kind
        in_policy = node in importer_set
        in_research = node in exporter_set
        if in_policy and in_research:
            return "Policy source & research country"
        if in_policy:
            return "Policy source"
        if in_research:
            return "Research country"
        return "Policy source & research country"

    palette = {
        "Policy source & research country": AUX_PRIMARY,
        "Policy source": AUX_SECONDARY,
        "Research country": AUX_TERTIARY,
        korea_kind: AUX_HIGHLIGHT,
    }

    node_kind = [_node_kind(n) for n in nodes]
    for kind in ["Policy source & research country", "Policy source", "Research country", korea_kind]:
        subset = [i for i, k in enumerate(node_kind) if k == kind]
        if not subset:
            continue
        fig.add_trace(
            go.Scatter(
                x=[pos[nodes[i]][0] for i in subset],
                y=[pos[nodes[i]][1] for i in subset],
                mode="markers+text",
                text=[label_overrides.get(nodes[i], nodes[i]) for i in subset],
                textposition="top center",
                marker=dict(
                    size=[float(sizes[i]) for i in subset],
                    color=palette[kind],
                    line=dict(color="white", width=1),
                    opacity=0.95,
                ),
                name=kind,
                hovertemplate="<b>%{customdata[0]}</b><br>Total citation count=%{customdata[1]:,.0f}<extra></extra>",
                customdata=[[nodes[i], float(total.iloc[i])] for i in subset],
                legendgroup="Node type",
                legendgrouptitle_text="Node type",
                meta=dict(role="nodes", kind=kind),
                selected=dict(
                    marker=dict(opacity=0.95),
                    textfont=dict(color=TEXT_COLOR),
                ),
                unselected=dict(
                    marker=dict(opacity=0.06),
                    textfont=dict(color="rgba(0,0,0,0)"),
                ),
            )
        )

    def _fmt_short(v: float) -> str:
        v = float(v)
        if v >= 1_000_000:
            return f"{v/1_000_000:.1f}M"
        if v >= 1_000:
            return f"{v/1_000:.0f}K"
        return f"{v:.0f}"

    def _marker_size_for_total(v: float) -> float:
        v = float(max(v, 0.0))
        return float(10 + 26 * np.sqrt(v / max_total)) if max_total > 0 else 10.0

    size_values = np.quantile(total.to_numpy(dtype=float), [0.25, 0.5, 0.75]).astype(float).tolist() if len(total) else []
    size_values = sorted({float(v) for v in size_values if v > 0})
    if len(size_values) < 3 and len(total):
        size_values = np.quantile(total.to_numpy(dtype=float), [0.1, 0.5, 0.9]).astype(float).tolist()
        size_values = sorted({float(v) for v in size_values if v > 0})
    if len(size_values) > 3:
        size_values = [size_values[0], size_values[len(size_values) // 2], size_values[-1]]
    for i, v in enumerate(size_values):
        fig.add_trace(
            go.Scatter(
                x=[None],
                y=[None],
                mode="markers",
                marker=dict(
                    size=_marker_size_for_total(v),
                    color="rgba(214, 227, 216, 0.45)",
                    line=dict(color="white", width=1),
                ),
                name=_fmt_short(v),
                legendgroup="Total citation count",
                legendgrouptitle_text="Total citation count" if i == 0 else None,
                showlegend=True,
            )
        )

    fig.update_layout(
        title=(
            "Policy source and research country citation network "
            "(top 3 research countries per policy source; top 3 policy sources per research country)"
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color=TEXT_COLOR),
        hovermode="closest",
        meta=dict(
            edges=edges[["exporter", "importer"]].values.tolist(),
            korea_label=korea_label,
        ),
        margin=dict(l=20, r=20, t=70, b=20),
        legend=dict(
            bgcolor="rgba(255,255,255,0.6)",
            bordercolor="rgba(0,0,0,0.1)",
            borderwidth=1,
            x=1.02,
            y=1.0,
            xanchor="left",
            yanchor="top",
        ),
    )
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False, scaleanchor="x", scaleratio=1)
    return fig


def main() -> int:
    args = _parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    figures: list[tuple[str, go.Figure]] = [
        ("pubyear_trend.html", fig01_pubyear_trend(run_tag=args.run_tag, in_dir=args.in_dir)),
        ("domain_top10.html", fig02_domain_top10(run_tag=args.run_tag, in_dir=args.in_dir, report_figures_dir=args.report_figures_dir)),
        ("topic_scatter_citations_vs_papers.html", fig03_topic_scatter(run_tag=args.run_tag, in_dir=args.in_dir)),
        ("topic_intensity_vs_recency.html", fig04_topic_intensity_vs_recency(run_tag=args.run_tag, in_dir=args.in_dir)),
        ("country_citations_top10.html", fig05_country_citations_top10_plus_kr(run_tag=args.run_tag, in_dir=args.in_dir)),
        ("country_domain_heatmap.html", fig06_country_domain_portfolio_top10_plus_kr(run_tag=args.run_tag, in_dir=args.in_dir)),
        (
            "country_domain_demand_supply_scatter_top50.html",
            fig06_country_domain_demand_supply_scatter_top50(run_tag=args.run_tag, in_dir=args.in_dir),
        ),
        ("source_type_citations_top10.html", fig07_source_type_citations_top10(run_tag=args.run_tag, in_dir=args.in_dir)),
        ("source_type_citations_per_policy_doc.html", fig08_source_type_density(run_tag=args.run_tag, report_figures_dir=args.report_figures_dir)),
        ("source_type_domain_heatmap.html", fig09_source_type_domain_heatmap(run_tag=args.run_tag, in_dir=args.in_dir)),
        ("policy_to_research_country_heatmap.html", fig10_policy_to_research_country_heatmap(run_tag=args.run_tag, in_dir=args.in_dir)),
        (
            "policy_country_self_share_selected.html",
            fig11_self_citation_share_selected(run_tag=args.run_tag, in_dir=args.in_dir, report_figures_dir=args.report_figures_dir),
        ),
        ("korea_policy_research_flows_top10.html", fig12_korea_flows(run_tag=args.run_tag, report_figures_dir=args.report_figures_dir)),
        ("policy_research_flow_network_drl.html", fig13_policy_research_flow_network_drl(run_tag=args.run_tag, report_figures_dir=args.report_figures_dir)),
    ]

    for filename, fig in figures:
        if filename == "country_domain_demand_supply_scatter_top50.html":
            _write_html(
                fig,
                args.out_dir / filename,
                post_script=FIG06_CROSS_HOVER_HIGHLIGHT_SCRIPT,
                div_id="country_domain_demand_supply_scatter_top50",
            )
        elif filename == "policy_research_flow_network_drl.html":
            _write_html(
                fig,
                args.out_dir / filename,
                post_script=FIG13_NEIGHBOR_FOCUS_SCRIPT,
                div_id="policy_research_flow_network_drl",
            )
        else:
            _write(fig, args.out_dir / filename)

    print(f"Wrote interactive figures to: {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
