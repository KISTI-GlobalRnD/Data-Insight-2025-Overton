#!/usr/bin/env python3
"""
Build S2 tables for Korea author-country rule sensitivity using one fixed,
deduplicated citation universe.

The main first-author result must use the same sequential country assignment as
the report. Alternative any-author and corresponding-author results change only
the authorship rule; they do not change the policy→research citation rows.

Outputs (CSV) under Output/Data_Insight/report_figures/ by default:
- {RUN_TAG}_s2_outbound_research_country_first_author.csv
  - report baseline: sequential first-author country assignment
- {RUN_TAG}_s2_outbound_research_country_any_author_fractional.csv
- {RUN_TAG}_s2_outbound_research_country_corresponding_fractional.csv
- {RUN_TAG}_s2_inbound_policy_source_country_shares.csv
- {RUN_TAG}_s2_inbound_policy_source_type_shares.csv
- {RUN_TAG}_s2_author_country_sensitivity_summary.csv

Run:
  uv run python scripts/make_s2_author_country_sensitivity_tables.py --run-tag 20251026
"""

from __future__ import annotations

import argparse
from pathlib import Path

import duckdb
import pandas as pd


def _safe_mkdir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-tag", default="20251026")
    ap.add_argument("--out-dir", default="Output/Data_Insight/report_figures")
    args = ap.parse_args()

    run_tag = str(args.run_tag)
    out_dir = Path(args.out_dir)
    _safe_mkdir(out_dir)

    citation_path = "Data/raw_df_citation_non_duplicated.parquet"
    policy_country_path = "Data/overton_policy_meta/policy_source_country_clean.parquet"
    policy_type_path = "Data/overton_policy_meta/policy_source_type_clean.parquet"
    works_unique_path = "Data/matched_openalex_with_oa_country_unique.parquet"

    auth_out_path = f"Output/Data_Insight/report_figures/{run_tag}_openalex_authorship_mysql_kr_outbound.parquet"
    auth_in_path = f"Output/Data_Insight/report_figures/{run_tag}_openalex_authorship_mysql_kr_inbound_first_author.parquet"

    con = duckdb.connect()
    con.execute("PRAGMA threads=8")

    # ----------------------------
    # Outbound: KR policy -> cited research (country composition by rule)
    # ----------------------------
    con.execute(
        f"""
        CREATE OR REPLACE TEMP VIEW kr_docs AS
        SELECT DISTINCT policy_document_id
        FROM read_parquet('{policy_country_path}')
        WHERE split_part(policy_source_country, ' > ', 1)='South Korea'
        """
    )
    con.execute(
        f"""
        CREATE OR REPLACE TEMP TABLE kr_outbound_citations AS
        SELECT c.policy_document_id, c.oaid_w
        FROM read_parquet('{citation_path}') c
        JOIN kr_docs d USING(policy_document_id)
        WHERE c.oaid_w IS NOT NULL AND c.oaid_w != ''
        """
    )
    out_total = int(con.execute("SELECT COUNT(*) FROM kr_outbound_citations").fetchone()[0])
    out_uniq_works = int(con.execute("SELECT COUNT(DISTINCT oaid_w) FROM kr_outbound_citations").fetchone()[0])

    con.execute(
        f"""
        CREATE OR REPLACE TEMP VIEW works_main AS
        SELECT oaid_w, first_author_country
        FROM read_parquet('{works_unique_path}')
        """
    )
    con.execute(
        f"""
        CREATE OR REPLACE TEMP VIEW auth_out AS
        SELECT oaid_w,
               first_author_countries_json,
               any_author_country_weights_json,
               corresponding_country_weights_json
        FROM read_parquet('{auth_out_path}')
        """
    )

    cov = con.execute(
        """
        SELECT
          COUNT(*)::BIGINT AS citation_total,
          SUM(CASE WHEN w.first_author_country IS NOT NULL AND w.first_author_country <> '' THEN 1 ELSE 0 END)::BIGINT AS first_author_known_cit,
          SUM(CASE WHEN a.any_author_country_weights_json <> '{}' THEN 1 ELSE 0 END) AS any_author_known_cit,
          SUM(CASE WHEN a.corresponding_country_weights_json <> '{}' THEN 1 ELSE 0 END) AS corresponding_known_cit
        FROM kr_outbound_citations c
        LEFT JOIN works_main w USING(oaid_w)
        LEFT JOIN auth_out a USING(oaid_w)
        """
    ).fetchdf()

    # Report baseline: sequential first-author assignment from the canonical
    # unique-per-work table. This row must reproduce the report exactly.
    fa = con.execute(
        """
        SELECT
          w.first_author_country AS country,
          COUNT(*)::DOUBLE AS citations
        FROM kr_outbound_citations c
        JOIN works_main w USING(oaid_w)
        WHERE w.first_author_country IS NOT NULL AND w.first_author_country <> ''
        GROUP BY country
        ORDER BY citations DESC
        """
    ).fetchdf()
    fa_denom = float(fa["citations"].sum()) if len(fa) else 0.0
    if fa_denom > 0:
        fa["share"] = fa["citations"] / fa_denom
    else:
        fa["share"] = 0.0

    # Any-author fractional
    any_df = con.execute(
        """
        SELECT j.key AS country, SUM(CAST(j.value AS DOUBLE)) AS citations
        FROM kr_outbound_citations c
        JOIN auth_out a USING(oaid_w)
        CROSS JOIN json_each(a.any_author_country_weights_json) j
        GROUP BY country
        ORDER BY citations DESC
        """
    ).fetchdf()
    any_denom = float(any_df["citations"].sum()) if len(any_df) else 0.0
    if any_denom > 0:
        any_df["share"] = any_df["citations"] / any_denom
    else:
        any_df["share"] = 0.0

    # Corresponding fractional
    corr_df = con.execute(
        """
        SELECT j.key AS country, SUM(CAST(j.value AS DOUBLE)) AS citations
        FROM kr_outbound_citations c
        JOIN auth_out a USING(oaid_w)
        CROSS JOIN json_each(a.corresponding_country_weights_json) j
        GROUP BY country
        ORDER BY citations DESC
        """
    ).fetchdf()
    corr_denom = float(corr_df["citations"].sum()) if len(corr_df) else 0.0
    if corr_denom > 0:
        corr_df["share"] = corr_df["citations"] / corr_denom
    else:
        corr_df["share"] = 0.0

    fa_out_path = out_dir / f"{run_tag}_s2_outbound_research_country_first_author.csv"
    any_out_path = out_dir / f"{run_tag}_s2_outbound_research_country_any_author_fractional.csv"
    corr_out_path = out_dir / f"{run_tag}_s2_outbound_research_country_corresponding_fractional.csv"
    fa.to_csv(fa_out_path, index=False)
    any_df.to_csv(any_out_path, index=False)
    corr_df.to_csv(corr_out_path, index=False)

    # ----------------------------
    # Inbound: global policy -> the report's canonical KR first-author works.
    # Keep this selected work set fixed. Alternative author rules are weights
    # within that set, not an expansion to non-KR-first-author works.
    # ----------------------------
    con.execute(
        f"""
        CREATE OR REPLACE TEMP VIEW kr_works AS
        SELECT DISTINCT oaid_w
        FROM read_parquet('{works_unique_path}')
        WHERE first_author_country='KR'
          AND oaid_w IS NOT NULL AND oaid_w <> ''
        """
    )
    con.execute(
        f"""
        CREATE OR REPLACE TEMP TABLE kr_inbound_citations AS
        SELECT c.policy_document_id, c.oaid_w
        FROM read_parquet('{citation_path}') c
        JOIN kr_works k USING(oaid_w)
        """
    )
    in_total = int(con.execute("SELECT COUNT(*) FROM kr_inbound_citations").fetchone()[0])
    in_uniq_works = int(con.execute("SELECT COUNT(DISTINCT oaid_w) FROM kr_inbound_citations").fetchone()[0])
    in_uniq_docs = int(con.execute("SELECT COUNT(DISTINCT policy_document_id) FROM kr_inbound_citations").fetchone()[0])

    con.execute(
        f"""
        CREATE OR REPLACE TEMP VIEW auth_in AS
        SELECT oaid_w,
               any_author_country_weights_json,
               corresponding_country_weights_json
        FROM read_parquet('{auth_in_path}')
        """
    )

    # Deduplicate policy meta (some docs contain repeated identical tags).
    # For country, collapse hierarchical tags (e.g., `USA > California`) to top-level to match main SI logic.
    con.execute(
        f"""
        CREATE OR REPLACE TEMP VIEW policy_country_top AS
        SELECT DISTINCT
          policy_document_id,
          split_part(policy_source_country, ' > ', 1) AS channel
        FROM read_parquet('{policy_country_path}')
        WHERE policy_source_country IS NOT NULL AND policy_source_country != ''
        """
    )
    con.execute(
        f"""
        CREATE OR REPLACE TEMP VIEW policy_type_pairs AS
        SELECT DISTINCT
          policy_document_id,
          policy_source_type AS channel
        FROM read_parquet('{policy_type_path}')
        WHERE policy_source_type IS NOT NULL AND policy_source_type != ''
        """
    )

    psc = con.execute(
        f"""
        SELECT
          p.channel AS channel,
          COUNT(*)::BIGINT AS citations,
          SUM(COALESCE(CAST(json_extract(a.any_author_country_weights_json, '$.KR') AS DOUBLE), 0.0)) AS citations_kr_weighted,
          SUM(COALESCE(CAST(json_extract(a.corresponding_country_weights_json, '$.KR') AS DOUBLE), 0.0)) AS citations_kr_corresponding_weighted
        FROM kr_inbound_citations c
        JOIN policy_country_top p USING(policy_document_id)
        LEFT JOIN auth_in a USING(oaid_w)
        GROUP BY channel
        ORDER BY citations DESC
        """
    ).fetchdf()
    psc_denom = float(psc["citations"].sum()) if len(psc) else 0.0
    psc_w_denom = float(psc["citations_kr_weighted"].sum()) if len(psc) else 0.0
    psc_corr_denom = float(psc["citations_kr_corresponding_weighted"].sum()) if len(psc) else 0.0
    if psc_denom > 0:
        psc["share"] = psc["citations"] / psc_denom
    else:
        psc["share"] = 0.0
    if psc_w_denom > 0:
        psc["share_kr_weighted"] = psc["citations_kr_weighted"] / psc_w_denom
    else:
        psc["share_kr_weighted"] = 0.0
    if psc_corr_denom > 0:
        psc["share_kr_corresponding_weighted"] = psc["citations_kr_corresponding_weighted"] / psc_corr_denom
    else:
        psc["share_kr_corresponding_weighted"] = 0.0

    pst = con.execute(
        f"""
        SELECT
          p.channel AS channel,
          COUNT(*)::BIGINT AS citations,
          SUM(COALESCE(CAST(json_extract(a.any_author_country_weights_json, '$.KR') AS DOUBLE), 0.0)) AS citations_kr_weighted,
          SUM(COALESCE(CAST(json_extract(a.corresponding_country_weights_json, '$.KR') AS DOUBLE), 0.0)) AS citations_kr_corresponding_weighted
        FROM kr_inbound_citations c
        JOIN policy_type_pairs p USING(policy_document_id)
        LEFT JOIN auth_in a USING(oaid_w)
        GROUP BY channel
        ORDER BY citations DESC
        """
    ).fetchdf()
    pst_denom = float(pst["citations"].sum()) if len(pst) else 0.0
    pst_w_denom = float(pst["citations_kr_weighted"].sum()) if len(pst) else 0.0
    pst_corr_denom = float(pst["citations_kr_corresponding_weighted"].sum()) if len(pst) else 0.0
    if pst_denom > 0:
        pst["share"] = pst["citations"] / pst_denom
    else:
        pst["share"] = 0.0
    if pst_w_denom > 0:
        pst["share_kr_weighted"] = pst["citations_kr_weighted"] / pst_w_denom
    else:
        pst["share_kr_weighted"] = 0.0
    if pst_corr_denom > 0:
        pst["share_kr_corresponding_weighted"] = pst["citations_kr_corresponding_weighted"] / pst_corr_denom
    else:
        pst["share_kr_corresponding_weighted"] = 0.0

    psc_path = out_dir / f"{run_tag}_s2_inbound_policy_source_country_shares.csv"
    pst_path = out_dir / f"{run_tag}_s2_inbound_policy_source_type_shares.csv"
    psc.to_csv(psc_path, index=False)
    pst.to_csv(pst_path, index=False)

    inbound_auth_rows = int(
        con.execute(
            """
            SELECT COUNT(*)
            FROM kr_inbound_citations c
            JOIN auth_in a USING(oaid_w)
            """
        ).fetchone()[0]
    )
    summary = pd.DataFrame(
        [
            ("outbound_citation_total", float(out_total)),
            ("outbound_first_author_assigned", float(cov.iloc[0]["first_author_known_cit"])),
            ("outbound_any_author_available", float(cov.iloc[0]["any_author_known_cit"])),
            ("outbound_corresponding_available", float(cov.iloc[0]["corresponding_known_cit"])),
            ("inbound_first_author_kr_citations", float(in_total)),
            ("inbound_first_author_kr_unique_works", float(in_uniq_works)),
            ("inbound_authorship_rows_available", float(inbound_auth_rows)),
            ("inbound_any_author_kr_weighted_sum", float(psc_w_denom)),
            ("inbound_corresponding_kr_weighted_sum", float(psc_corr_denom)),
        ],
        columns=["metric", "value"],
    )
    summary_path = out_dir / f"{run_tag}_s2_author_country_sensitivity_summary.csv"
    summary.to_csv(summary_path, index=False)

    # Summary print (compact)
    print("[S2] outbound: citations_total", out_total, "uniq_works", out_uniq_works)
    print("[S2] outbound coverage (citations):", cov.to_dict(orient="records")[0])
    print("[S2] inbound: citations_total", in_total, "uniq_works", in_uniq_works, "uniq_docs", in_uniq_docs)
    print("[S2] wrote:", fa_out_path)
    print("[S2] wrote:", any_out_path)
    print("[S2] wrote:", corr_out_path)
    print("[S2] wrote:", psc_path)
    print("[S2] wrote:", pst_path)
    print("[S2] wrote:", summary_path)

    con.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
