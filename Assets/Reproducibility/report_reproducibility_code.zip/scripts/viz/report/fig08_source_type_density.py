from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from .common import (
    AUX_HIGHLIGHT,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    NEUTRAL_GRAY,
    REFERENCE_LINE,
    REFERENCE_TEXT,
    SOURCE_TYPE_MAJOR_LABELS,
    SOURCE_TYPE_MAJOR_COLORS,
    _fmt_short,
    _set_theme,
    _transparent,
    save_report_figure,
)


def figure_8_source_type_density(*, run_tag: str, in_dir: Path, out_dir: Path) -> tuple[Path, Path]:
    _doc_color, core_primary, _text_color, _cmap = _set_theme()

    source_type_cit = pd.read_csv(in_dir / f"{run_tag}_source_type_citations.csv")
    source_type_docs = pd.read_csv(in_dir / f"{run_tag}_source_type_policy_docs.csv")

    df = source_type_cit.merge(source_type_docs, on="source_type", how="left")
    df["citations_per_policy_doc"] = df["citation_rows"] / df["citing_policy_docs"].replace(0, np.nan)

    plot_df = df.dropna(
        subset=["citation_rows", "policy_docs", "citing_policy_docs", "citations_per_policy_doc"]
    ).copy()
    plot_df = plot_df[plot_df["citation_rows"] > 0].copy()
    plot_df["major_type"] = plot_df["source_type"].astype(str).str.split(">").str[0].str.strip()
    plot_df = plot_df[plot_df["major_type"].ne("")].copy()

    out_csv = out_dir / f"{run_tag}_source_type_citations_per_policy_doc.csv"
    plot_df[
        [
            "source_type",
            "major_type",
            "citation_rows",
            "policy_docs",
            "citing_policy_docs",
            "citations_per_policy_doc",
        ]
    ].to_csv(out_csv, index=False)

    fig, ax = plt.subplots(figsize=(10.8, 5.6))

    majors = sorted(plot_df["major_type"].dropna().astype(str).unique().tolist())
    major_palette: dict[str, str] = {}
    for m in majors:
        key = m.strip()
        if key in SOURCE_TYPE_MAJOR_COLORS:
            major_palette[m] = SOURCE_TYPE_MAJOR_COLORS[key]
    missing = [m for m in majors if m not in major_palette]
    if missing:
        fallback = [AUX_PRIMARY, AUX_SECONDARY, AUX_TERTIARY, AUX_HIGHLIGHT, NEUTRAL_GRAY]
        used = set(major_palette.values())
        fallback = [c for c in fallback if c not in used] + fallback
        for i, m in enumerate(missing):
            major_palette[m] = fallback[i % len(fallback)]

    docs = plot_df["citing_policy_docs"].astype(float).clip(lower=1)
    docs_sqrt = np.sqrt(docs)
    if docs_sqrt.nunique() > 1:
        docs_norm = (docs_sqrt - docs_sqrt.min()) / (docs_sqrt.max() - docs_sqrt.min())
        marker_sizes = 45 + docs_norm * 420
    else:
        marker_sizes = pd.Series([160.0] * len(plot_df), index=plot_df.index)

    plot_df["marker_size"] = marker_sizes.astype(float)
    color_values = plot_df["major_type"].map(major_palette).fillna(AUX_PRIMARY)
    citations = plot_df["citation_rows"].astype(float).replace([np.inf, -np.inf], np.nan).dropna()
    citations_median = float(citations.median()) if len(citations) else None
    if citations_median is not None:
        ax.axvline(citations_median, color=REFERENCE_LINE, linestyle="--", linewidth=1.2, alpha=0.7, zorder=1)
    density = plot_df["citations_per_policy_doc"].astype(float).replace([np.inf, -np.inf], np.nan).dropna()
    density_median = float(density.median()) if len(density) else None
    if density_median is not None:
        ax.axhline(density_median, color=REFERENCE_LINE, linestyle="--", linewidth=1.2, alpha=0.7, zorder=1)
    median_label_color = REFERENCE_TEXT
    if citations_median is not None:
        ax.annotate(
            "Median total citations",
            xy=(citations_median, 0.02),
            xycoords=ax.get_xaxis_transform(),
            xytext=(0, -10),
            textcoords="offset points",
            ha="center",
            va="top",
            fontsize=8,
            color=median_label_color,
        )
    if density_median is not None:
        ax.annotate(
            "Median citations per citing document",
            xy=(0.02, density_median),
            xycoords=ax.get_yaxis_transform(),
            xytext=(0, -8),
            textcoords="offset points",
            ha="left",
            va="top",
            fontsize=8,
            color=median_label_color,
        )
    ax.text(
        0.02,
        0.86,
        "Bold outline = major source type",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=8,
        color=median_label_color,
    )
    ax.scatter(
        plot_df.loc[plot_df["source_type"].astype(str).str.contains(">"), "citation_rows"],
        plot_df.loc[plot_df["source_type"].astype(str).str.contains(">"), "citations_per_policy_doc"],
        s=plot_df.loc[plot_df["source_type"].astype(str).str.contains(">"), "marker_size"],
        c=color_values.loc[plot_df["source_type"].astype(str).str.contains(">")],
        alpha=0.62,
        linewidth=0,
        zorder=2,
    )
    major_mask = ~plot_df["source_type"].astype(str).str.contains(">")
    ax.scatter(
        plot_df.loc[major_mask, "citation_rows"],
        plot_df.loc[major_mask, "citations_per_policy_doc"],
        s=plot_df.loc[major_mask, "marker_size"] * 1.08,
        c=color_values.loc[major_mask],
        alpha=0.9,
        linewidth=1.2,
        edgecolor="#111827",
        zorder=3,
    )
    ax.set_xscale("log")
    ax.set_title("Source types: citation volume and average per citing policy document")
    ax.set_xlabel("Total citations (log)")
    ax.set_ylabel("Citations per citing policy document")

    label_specs = {
        "other > aggregator": ("Aggregator", (18, 14), "left"),
        "other": ("Other", (18, -16), "left"),
        "government > healthcare agency": ("Gov. healthcare agency", (-10, -18), "right"),
        "igo > development bank": ("IGO development bank", (-8, 18), "right"),
        "igo": ("IGO", (8, 16), "left"),
        "government": ("Government", (10, -16), "left"),
        "think tank": ("Think tank", (-8, -18), "right"),
    }
    label_df = plot_df[plot_df["source_type"].isin(label_specs)].copy()
    for _, row in label_df.iterrows():
        x = float(row["citation_rows"])
        y = float(row["citations_per_policy_doc"])
        source_type = str(row["source_type"])
        display_label, offset, horizontal_alignment = label_specs[source_type]
        ax.annotate(
            display_label,
            xy=(x, y),
            xytext=offset,
            textcoords="offset points",
            ha=horizontal_alignment,
            va="center",
            fontsize=8,
            color=_text_color,
            alpha=0.9,
            arrowprops={"arrowstyle": "-", "color": REFERENCE_LINE, "lw": 0.8},
            clip_on=False,
        )

    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch

    color_legend_handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            linestyle="",
            markerfacecolor=major_palette[m],
            markeredgecolor="none",
            markersize=8,
            alpha=0.75,
            label=SOURCE_TYPE_MAJOR_LABELS.get(m, m),
        )
        for m in majors
        if m in major_palette
    ]
    legend1 = ax.legend(
        handles=color_legend_handles,
        title="Major source type",
        loc="upper left",
        bbox_to_anchor=(1.02, 1.0),
        borderaxespad=0.0,
        frameon=True,
        fancybox=True,
        framealpha=0.95,
    )
    ax.add_artist(legend1)

    docs_min = int(docs.min()) if len(docs) else 1
    docs_max = int(docs.max()) if len(docs) else docs_min
    docs_mid = int(np.median(docs)) if len(docs) else docs_min
    size_values = sorted({v for v in [docs_min, docs_mid, docs_max] if v > 0})
    if len(size_values) < 3 and docs_min != docs_max:
        docs_geo = int(np.exp(np.mean(np.log([max(docs_min, 1), max(docs_max, 1)]))))
        size_values = sorted({v for v in [docs_min, docs_geo, docs_max] if v > 0})

    def _size_for_docs(v: float) -> float:
        v = float(max(v, 1.0))
        v_sqrt = np.sqrt(v)
        if docs_sqrt.nunique() <= 1:
            return 160.0
        v_norm = (v_sqrt - docs_sqrt.min()) / (docs_sqrt.max() - docs_sqrt.min())
        return 45 + v_norm * 420

    size_legend_handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            color="w",
            markerfacecolor=NEUTRAL_GRAY,
            markersize=np.sqrt(_size_for_docs(v)),
            alpha=0.7,
            label=_fmt_short(float(v)),
        )
        for v in size_values
    ]
    ax.legend(
        handles=size_legend_handles,
        title="DOI-citing policy documents",
        loc="upper left",
        bbox_to_anchor=(1.02, 0.55),
        borderaxespad=0.0,
        frameon=True,
        fancybox=True,
        framealpha=0.95,
    )

    _transparent(fig, [ax])
    fig.tight_layout(rect=(0.0, 0.0, 0.78, 1.0))
    out_png = out_dir / f"{run_tag}_source_type_citations_per_policy_doc.png"
    save_report_figure(fig, out_png, dpi=200, transparent=True)
    plt.close(fig)
    return out_png, out_csv
