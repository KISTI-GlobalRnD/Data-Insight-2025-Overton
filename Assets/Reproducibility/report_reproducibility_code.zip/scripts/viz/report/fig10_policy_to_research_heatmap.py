from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.ticker import PercentFormatter

from .common import (
    REFERENCE_LINE,
    _display_country_label,
    _fmt_short,
    _iso2_to_label,
    _policy_to_iso2,
    _set_theme,
    _transparent,
    save_report_figure,
)


def figure_10_policy_to_research_heatmap(*, run_tag: str, in_dir: Path, out_dir: Path) -> Path:
    _doc_color, _core_primary, _text_color, cmap = _set_theme()

    def _annot_percent_rows(df: pd.DataFrame) -> pd.DataFrame:
        labels = pd.DataFrame(index=df.index, columns=df.columns, dtype=object)
        for idx, row in df.iterrows():
            if row.sum() <= 0:
                labels.loc[idx] = ["" for _ in row]
                continue
            perc = row.values * 100
            row_labels = []
            for p_raw in perc:
                if p_raw <= 0:
                    row_labels.append("")
                elif p_raw < 0.1:
                    row_labels.append("<0.1%")
                else:
                    row_labels.append(f"{p_raw:.1f}%")
            labels.loc[idx] = row_labels
        return labels

    mat = pd.read_csv(
        in_dir / f"{run_tag}_policy_country_research_country.csv",
        keep_default_na=False,
    )
    pivot_full = mat.pivot_table(
        index="policy_country", columns="research_country", values="citation_rows", fill_value=0
    )
    pol_top = pivot_full.sum(axis=1).sort_values(ascending=False).head(12).index
    res_top = pivot_full.sum(axis=0).sort_values(ascending=False).head(12).index
    pivot_plot = pivot_full.loc[pol_top, res_top]

    iso2_to_label = _iso2_to_label()
    pivot_plot = pivot_plot.rename(columns=lambda c: iso2_to_label.get(c, c))
    pivot_full = pivot_full.rename(columns=lambda c: iso2_to_label.get(c, c))
    pivot_share = pivot_full.div(pivot_full.sum(axis=1).replace(0, np.nan), axis=0).fillna(0)

    # Symmetric ordering to highlight diagonal structure; keep EU/IGO as special rows at the top.
    special_rows = [r for r in ["IGO", "EU"] if r in pol_top and r in pivot_share.index]
    main_rows = [r for r in pol_top if r not in special_rows]
    row_order = special_rows + [r for r in main_rows if r in pivot_share.index]

    policy_to_iso2 = _policy_to_iso2()
    iso_order_codes = [policy_to_iso2.get(r) for r in row_order if policy_to_iso2.get(r)]
    iso_order_labels = [iso2_to_label.get(c, c) for c in iso_order_codes]
    col_order = [c for c in iso_order_labels if c in pivot_share.columns]
    col_order.extend([c for c in pivot_share.columns if c not in col_order])

    col_order_abs = [c for c in col_order if c in pivot_plot.columns]
    pivot_abs = pivot_plot.reindex(index=row_order, columns=col_order_abs)
    pivot_share_full = pivot_share.loc[row_order, col_order]

    # For panel B, align X/Y using the policy-country list and group the remainder.
    col_order_sym = [c for c in iso_order_labels]
    pivot_share_sym = pivot_share_full.reindex(columns=col_order_sym, fill_value=0.0)

    label_to_iso2 = {v: k for k, v in iso2_to_label.items()}
    label_to_iso2.update({"UK": "GB", "USA": "US"})

    europe_other = {
        "NL",
        "IT",
        "CH",
        "DK",
        "NO",
        "FI",
        "AT",
        "IE",
        "PT",
        "PL",
        "CZ",
        "HU",
        "RO",
        "SK",
        "SI",
        "HR",
        "BG",
        "LT",
        "LV",
        "EE",
        "LU",
        "IS",
        "RU",
        "UA",
        "BY",
        "RS",
        "BA",
        "ME",
        "MK",
        "AL",
        "MD",
        "XK",
        "TR",
        "GR",
    }
    asia_pacific = {
        "CN",
        "JP",
        "KR",
        "IN",
        "SG",
        "TW",
        "HK",
        "MY",
        "TH",
        "ID",
        "PH",
        "VN",
        "PK",
        "BD",
        "LK",
        "NP",
        "MM",
        "KH",
        "LA",
        "MN",
        "KZ",
        "UZ",
        "AE",
        "SA",
        "IR",
        "IQ",
        "IL",
        "JO",
        "QA",
        "KW",
        "BH",
        "OM",
        "LB",
        "SY",
        "YE",
        "AF",
        "BT",
        "MO",
        "BN",
    }

    policy_iso2 = {label_to_iso2.get(c, c) for c in col_order_sym}

    other_cols = [c for c in pivot_share_full.columns if c not in col_order_sym]
    group_map: dict[str, str] = {}
    for col in other_cols:
        iso = label_to_iso2.get(col, col if isinstance(col, str) and len(col) == 2 else None)
        if iso in policy_iso2:
            continue
        if iso in europe_other:
            group_map[col] = "Other (Europe)"
        elif iso in asia_pacific:
            group_map[col] = "Other (Asia-Pacific)"
        else:
            group_map[col] = "Other (Rest)"

    grouped = pivot_share_full[other_cols].groupby(group_map, axis=1).sum()
    group_order = [label for label in ["Other (Europe)", "Other (Asia-Pacific)", "Other (Rest)"] if label in grouped.columns]
    grouped = grouped.reindex(columns=group_order, fill_value=0.0)
    pivot_share = pd.concat([pivot_share_sym, grouped], axis=1)

    # Display-only label normalization (avoid splitting KR across multiple labels).
    pivot_abs = pivot_abs.rename(index=_display_country_label)
    pivot_share = pivot_share.rename(index=_display_country_label)

    n_rows, n_cols = pivot_abs.shape
    panel_w = max(7.2, n_cols * 0.65)
    fig_w = panel_w * 2 + 0.2
    fig_h = max(7.2, n_rows * 0.6)
    fig, axes = plt.subplots(1, 2, figsize=(fig_w, fig_h), sharey=True)
    from mpl_toolkits.axes_grid1 import make_axes_locatable

    def _draw_heatmap(
        ax: plt.Axes,
        data: pd.DataFrame,
        *,
        label: str,
        title: str,
        log_scale: bool = False,
        log_vmin: float | None = None,
        vmax: float | None = None,
        annotate_threshold: float | None = None,
        annot_df: pd.DataFrame | None = None,
        percent: bool = False,
        xlabel: str | None = None,
        annot_kws: dict | None = None,
        percent_cap: float | None = None,
    ) -> plt.Axes:
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size="3.5%", pad=0.12)
        plot_data = data.copy()
        heatmap_kwargs = {}
        if log_scale:
            mask = plot_data <= 0
            plot_data = plot_data.mask(mask)
            vmax = float(np.nanmax(plot_data.values)) if plot_data.values.size else 1.0
            vmin = log_vmin if log_vmin is not None else 1.0
            heatmap_kwargs["norm"] = LogNorm(vmin=max(vmin, 1.0), vmax=max(vmax, 1.0))
            heatmap_kwargs["mask"] = mask
        annot = None
        if annot_df is not None:
            heatmap_kwargs["annot"] = annot_df
            heatmap_kwargs["fmt"] = ""
            heatmap_kwargs["annot_kws"] = annot_kws or {"fontsize": 7, "color": "#1F2933"}
        elif annotate_threshold is not None:
            def _fmt_cell(v: float) -> str:
                return f"{v:.0%}" if v >= annotate_threshold else ""
            annot = plot_data.applymap(lambda v: _fmt_cell(v) if pd.notna(v) else "")
            heatmap_kwargs["annot"] = annot
            heatmap_kwargs["fmt"] = ""
            heatmap_kwargs["annot_kws"] = annot_kws or {"fontsize": 7, "color": "#1F2933"}
        cbar_kws = {"label": label}
        if percent and percent_cap is not None:
            cbar_kws["ticks"] = [0.0, percent_cap / 3, percent_cap * 2 / 3, percent_cap]
        if percent:
            cbar_kws["format"] = PercentFormatter(xmax=1.0, decimals=1)
        sns.heatmap(
            plot_data,
            cmap=cmap,
            ax=ax,
            cbar_ax=cax,
            vmin=0.0,
            vmax=vmax if vmax is not None else float(data.values.max()) if data.values.size else 1.0,
            square=True,
            cbar_kws=cbar_kws,
            **heatmap_kwargs,
        )
        ax.set_title(title, pad=8)
        ax.set_xlabel(xlabel or "Research country (first author)")
        ax.tick_params(axis="x", rotation=45, pad=8)
        for tick in ax.get_xticklabels():
            tick.set_horizontalalignment("right")
            tick.set_rotation_mode("anchor")
        ax.tick_params(axis="y", rotation=0)
        if special_rows:
            ax.axhline(len(special_rows), color=REFERENCE_LINE, lw=0.8, alpha=0.45)
        if percent:
            cax.yaxis.set_major_formatter(PercentFormatter(xmax=1.0, decimals=1))
            if percent_cap is not None:
                ticks = cax.get_yticks()
                if len(ticks):
                    labels = []
                    for t in ticks:
                        if abs(t - percent_cap) < 1e-6:
                            labels.append(f">{int(percent_cap * 100)}%")
                        else:
                            labels.append(f"{int(round(t * 100))}%")
                    cax.set_yticklabels(labels)
        return cax

    annot_abs = pivot_abs.applymap(lambda v: _fmt_short(float(v)) if pd.notna(v) and float(v) > 0 else "")

    cax_abs = _draw_heatmap(
        axes[0],
        pivot_abs,
        label="Citations (log)",
        title="A. Citation count",
        log_scale=True,
        log_vmin=10,
        annot_df=annot_abs,
        xlabel="Research country (first author)",
    )
    annot_share = _annot_percent_rows(pivot_share)
    cax_share = _draw_heatmap(
        axes[1],
        pivot_share,
        label="Share within policy source",
        title="B. Share within policy source (normalized)",
        annot_df=annot_share,
        annot_kws={"fontsize": 6, "color": "#1F2933"},
        percent=True,
        vmax=0.30,
        percent_cap=0.30,
        xlabel="Research country or region (first author)",
    )
    axes[0].set_ylabel("Policy source", labelpad=8)
    axes[1].set_ylabel("Policy source", labelpad=6)
    axes[1].yaxis.set_label_position("left")
    axes[1].tick_params(axis="y", labelleft=True, labelright=False, pad=2)

    fig.suptitle(
        "Policy source to research-country citation structure\n"
        "Policy sources are the top 12 by total citations (IGO and EU listed first); research-country columns follow the policy-source order",
        y=0.98,
    )

    _transparent(fig, [axes[0], axes[1], cax_abs, cax_share])
    fig.subplots_adjust(top=0.82, bottom=0.33, wspace=0.03)
    out_path = out_dir / f"{run_tag}_policy_to_research_country_heatmap.png"
    save_report_figure(fig, out_path, dpi=300, transparent=True)
    plt.close(fig)
    return out_path
