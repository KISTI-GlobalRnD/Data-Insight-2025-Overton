from __future__ import annotations

from pathlib import Path

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

from .common import (
    AUX_TERTIARY,
    REFERENCE_TEXT,
    SOFT_GRID,
    SOFT_SHADE,
    _fmt_short,
    _set_theme,
    _transparent,
    save_report_figure,
)


def figure_1_pubyear_trend(*, run_tag: str, in_dir: Path, out_dir: Path) -> tuple[Path, Path]:
    doc_color, citation_color, text_color, _cmap = _set_theme()

    df = pd.read_csv(in_dir / f"{run_tag}_pubyear_trend_metrics.csv")
    df = df.dropna(subset=["year"]).copy()

    fig, (ax1, ax2) = plt.subplots(
        2,
        1,
        figsize=(9.5, 6.2),
        sharex=True,
        gridspec_kw={"height_ratios": [2.1, 1]},
    )

    ax1b = ax1.twinx()
    sns.lineplot(
        data=df,
        x="year",
        y="citations",
        ax=ax1,
        color=citation_color,
        marker="o",
        label="Policy-to-DOI citations",
    )
    sns.lineplot(
        data=df,
        x="year",
        y="policy_docs",
        ax=ax1b,
        color=doc_color,
        marker="o",
        label="Policy documents with DOI citations",
    )
    ax1.set_title("Policy documents and DOI citations by publication year")
    ax1.set_xlabel("")
    ax1.set_ylabel("Policy-to-DOI citations")
    ax1b.set_ylabel("Policy documents")
    ax1b.grid(False)
    ax1.yaxis.set_major_formatter(FuncFormatter(_fmt_short))
    ax1b.yaxis.set_major_formatter(FuncFormatter(_fmt_short))

    # Seaborn adds legends to both axes when `label=` is provided. Remove the auto
    # legends and add one combined legend to avoid duplicated entries.
    if ax1.get_legend() is not None:
        ax1.get_legend().remove()
    if ax1b.get_legend() is not None:
        ax1b.get_legend().remove()

    ax1.legend(
        [ax1.lines[0], ax1b.lines[0]],
        ["Policy-to-DOI citations", "Policy documents with DOI citations"],
        loc="upper left",
        frameon=True,
        fancybox=True,
        framealpha=0.95,
    )

    sns.lineplot(
        data=df,
        x="year",
        y="citations_per_doc",
        ax=ax2,
        color=AUX_TERTIARY,
        marker="o",
        label="DOI citations per policy document",
    )
    ax2.set_xlabel("Publication year (policy document)")
    ax2.set_ylabel("Citations per document")
    ax2.legend(loc="upper left", frameon=True, fancybox=True, framealpha=0.95)

    years = df["year"].astype(int)
    max_year = int(years.max()) if len(years) else None
    cutoff_year = 2022 if max_year and max_year >= 2022 else max_year
    if cutoff_year:
        for ax in (ax1, ax2):
            ax.axvspan(cutoff_year - 0.5, max_year + 0.5, color=SOFT_SHADE, alpha=0.78, zorder=0)
        ax1.text(
            0.99,
            0.02,
            "Recent years (still accumulating)",
            transform=ax1.transAxes,
            ha="right",
            va="bottom",
            fontsize=8,
            color=REFERENCE_TEXT,
        )

    for ax in (ax1, ax2):
        ax.tick_params(axis="x", rotation=0)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_color(SOFT_GRID)
        ax.spines["bottom"].set_color(SOFT_GRID)
        ax.grid(True, color=SOFT_GRID)
        ax.set_axisbelow(True)

    ax1b.tick_params(axis="y", colors=text_color)
    ax1b.spines["top"].set_visible(False)
    ax1b.spines["right"].set_color(SOFT_GRID)

    _transparent(fig, [ax1, ax2, ax1b])
    fig.tight_layout()

    out_png = out_dir / f"{run_tag}_pubyear_trend.png"
    out_csv = out_dir / f"{run_tag}_pubyear_trend_metrics.csv"
    df.to_csv(out_csv, index=False)
    save_report_figure(fig, out_png, dpi=200, transparent=True)
    plt.close(fig)
    return out_png, out_csv
