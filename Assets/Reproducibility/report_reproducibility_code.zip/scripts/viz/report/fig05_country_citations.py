from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

from .common import (
    AUX_PRIMARY,
    AUX_SECONDARY,
    DOMAIN_LEGEND_LABELS,
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    KOREA_DISPLAY_LABEL,
    _annotate_stacked_barh_percent,
    _display_country_label,
    _fmt_short,
    _row_normalize,
    _set_theme,
    _stacked_barh_percent,
    _transparent,
    save_report_figure,
)


def figure_5_country_citations(*, run_tag: str, in_dir: Path, out_dir: Path) -> Path:
    _doc_color, _core_primary, text_color, _cmap = _set_theme()

    country_cit = pd.read_csv(in_dir / f"{run_tag}_country_citations.csv")
    country_cit = country_cit.dropna(subset=["country", "citation_rows"]).copy()
    country_cit["country"] = country_cit["country"].map(_display_country_label)
    country_cit["citation_rows"] = pd.to_numeric(country_cit["citation_rows"], errors="coerce").fillna(0.0)
    country_cit["citing_policy_docs"] = pd.to_numeric(country_cit["citing_policy_docs"], errors="coerce").fillna(0.0)
    country_cit = (
        country_cit.groupby("country", as_index=False)[["citation_rows", "citing_policy_docs"]]
        .sum()
        .sort_values("citation_rows", ascending=False)
        .copy()
    )
    country_cit = country_cit[country_cit["citation_rows"] > 0].copy()

    top10 = country_cit.nlargest(10, "citation_rows").copy()
    korea = country_cit[country_cit["country"] == KOREA_DISPLAY_LABEL].copy()
    if korea.empty:
        raise ValueError("Korea row not found in country citations CSV.")
    korea = korea.nlargest(1, "citation_rows").copy()

    plot_df = pd.concat([top10, korea], ignore_index=True).drop_duplicates(subset=["country"], keep="first")
    plot_df = plot_df.sort_values("citation_rows", ascending=False).copy()
    order = plot_df["country"].tolist()

    plot_df["citing_policy_docs"] = plot_df["citing_policy_docs"].replace(0, np.nan)
    plot_df["citations_per_policy_doc"] = plot_df["citation_rows"] / plot_df["citing_policy_docs"]

    # Domain composition (normalized within each policy source).
    mat = pd.read_csv(in_dir / f"{run_tag}_country_domain_matrix.csv")
    mat = mat.dropna(subset=["country", "domain", "citation_rows"]).copy()
    mat["country"] = mat["country"].map(_display_country_label)
    mat["citation_rows"] = pd.to_numeric(mat["citation_rows"], errors="coerce").fillna(0.0)
    mat = mat.groupby(["country", "domain"], as_index=False)["citation_rows"].sum()
    mat = mat[mat["country"].isin(order)].copy()
    mat = mat[mat["domain"].isin(DOMAIN_ORDER)].copy()
    pivot = mat.pivot_table(index="country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0)
    pivot = pivot.reindex(index=order, columns=DOMAIN_ORDER, fill_value=0)
    shares = _row_normalize(pivot)

    fig, (ax_a, ax_b, ax_c) = plt.subplots(
        nrows=1,
        ncols=3,
        figsize=(13.0, 5.7),
        sharey=True,
        gridspec_kw={"width_ratios": [1.25, 1.15, 1.8], "wspace": 0.10},
    )

    # A. Total scholarly-paper citations made by policy documents (absolute).
    ax_a.barh(order, plot_df.set_index("country").loc[order, "citation_rows"], color=AUX_PRIMARY)
    ax_a.set_title("A. Scholarly-paper citations made\n(total)", fontsize=10.5, fontweight="bold")
    ax_a.set_xlabel("DOI-linked scholarly-paper\ncitations made")
    ax_a.set_ylabel("Policy-document source")
    ax_a.xaxis.set_major_formatter(FuncFormatter(_fmt_short))
    ax_a.yaxis.grid(False)
    ax_a.xaxis.grid(True)

    x_max = float(plot_df["citation_rows"].max())
    ax_a.set_xlim(0, 10_000_000)
    inside_a = set(plot_df.nlargest(2, "citation_rows")["country"].tolist())
    for country in order:
        val = float(plot_df.set_index("country").loc[country, "citation_rows"])
        if country in inside_a:
            label_x = max(val - x_max * 0.02, val * 0.6)
            ax_a.text(
                label_x,
                country,
                _fmt_short(val),
                va="center",
                ha="right",
                fontsize=9,
                color="white",
                fontweight="bold",
            )
        else:
            ax_a.text(val, country, f"  {_fmt_short(val)}", va="center", ha="left", fontsize=9, color=text_color)

    # Drop the last 10.0M tick label to avoid overlap with the right edge.
    ticks_a = [t for t in ax_a.get_xticks() if _fmt_short(float(t)) != "10.0M"]
    if ticks_a:
        ax_a.set_xticks(ticks_a)

    # B. Citations per policy document with at least one DOI-linked citation.
    vals_b = plot_df.set_index("country").loc[order, "citations_per_policy_doc"].astype(float).fillna(0.0)
    ax_b.barh(order, vals_b, color=AUX_SECONDARY)
    ax_b.set_title(
        "B. Scholarly-paper citations made\nper citing policy document (mean)",
        fontsize=10.5,
        fontweight="bold",
    )
    ax_b.set_xlabel("Mean citations per citing\npolicy document")
    ax_b.set_ylabel("")
    ax_b.yaxis.grid(False)
    ax_b.xaxis.grid(True)
    ax_b.tick_params(axis="y", labelleft=False)
    ax_b.xaxis.set_major_formatter(FuncFormatter(lambda x, _pos=None: f"{x:.1f}"))

    x_max_b = float(vals_b.max()) if len(vals_b) else 1.0
    ax_b.set_xlim(0, x_max_b * 1.18 if x_max_b > 0 else 1.0)
    inside_b = {country for country in order if float(vals_b.loc[country]) > 17.0}
    for country in order:
        val = float(vals_b.loc[country])
        if country in inside_b:
            label_x = max(val - x_max_b * 0.05, val * 0.6)
            ax_b.text(
                label_x,
                country,
                f"{val:.1f}",
                va="center",
                ha="right",
                fontsize=9,
                color="white",
                fontweight="bold",
            )
        else:
            ax_b.text(val, country, f"  {val:.1f}", va="center", ha="left", fontsize=9, color=text_color)

    # C. Domain composition (normalized within each policy source).
    _stacked_barh_percent(
        ax_c,
        shares,
        order=order,
        palette=DOMAIN_PALETTE,
        xlabel="Share of cited scholarly-paper fields",
        show_legend=False,
    )
    _annotate_stacked_barh_percent(ax_c, shares, order=order, palette=DOMAIN_PALETTE, inside_threshold=0.05)
    ax_c.set_xlim(0, 1.07)
    ax_c.set_title("C. Fields of scholarly papers cited\n(share within source)", fontsize=10.5, fontweight="bold")
    ax_c.set_ylabel("")
    ax_c.tick_params(axis="y", labelleft=False)

    from matplotlib.patches import Patch

    legend_handles = [
        Patch(facecolor=DOMAIN_PALETTE[d], label=DOMAIN_LEGEND_LABELS.get(d, d))
        for d in DOMAIN_ORDER
        if d in shares.columns
    ]
    ax_c.legend(
        handles=legend_handles,
        loc="lower left",
        bbox_to_anchor=(-0.21, 0.02),
        frameon=True,
        fancybox=True,
        framealpha=0.95,
        ncol=1,
        handlelength=1.0,
        fontsize=9,
    )
    ax_c.yaxis.tick_right()
    ax_c.set_yticks(np.arange(len(order)))
    ax_c.set_yticklabels(order)
    ax_c.tick_params(axis="y", labelright=True, labelleft=False, length=0, pad=6)

    for ax in (ax_a, ax_b, ax_c):
        ax.invert_yaxis()

    fig.suptitle(
        "Citation direction: policy documents issued by each source → scholarly papers",
        fontsize=13,
        fontweight="bold",
        y=1.02,
    )
    _transparent(fig, [ax_a, ax_b, ax_c])
    fig.tight_layout(rect=(0, 0, 1, 0.95), pad=0.8)
    out_path = out_dir / f"{run_tag}_country_citations_top10.png"
    save_report_figure(fig, out_path, dpi=200, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)
    return out_path
