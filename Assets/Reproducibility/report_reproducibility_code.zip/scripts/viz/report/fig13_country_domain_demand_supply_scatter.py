from __future__ import annotations

from pathlib import Path

import random

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.ticker import FuncFormatter, PercentFormatter

from .common import (
    AUX_CATEG,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    AUX_HIGHLIGHT,
    CORE_CATEG,
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    DOMAIN_LEGEND_LABELS,
    KOREA_DISPLAY_LABEL,
    KOREA_LABEL_ALIASES,
    NEUTRAL_GRAY,
    REFERENCE_LINE,
    SOFT_SHADE,
    SOURCE_TYPE_MAJOR_COLORS,
    _add_edge_connectors,
    _adjust_text_with_keepout,
    _annotate_stacked_barh_percent,
    _ccdf_from_counts,
    _contrast_text_color,
    _display_country_label,
    _ellipsize,
    _fmt_short,
    _iso2_to_label,
    _make_domain_palette,
    _openalex_output_shares_by_country_domain,
    _policy_country_label,
    _policy_to_iso2,
    _row_normalize,
    _set_theme,
    _sql_quote,
    _stacked_barh_percent,
    _stacked_barh_percent_grouped,
    _tint,
    _transparent,
    save_report_figure,
)

def figure_13_country_domain_demand_supply_scatter(*, run_tag: str, in_dir: Path, out_dir: Path) -> tuple[Path, Path]:
    _doc_color, core_primary, _text_color, _cmap = _set_theme()

    country_citations = pd.read_csv(in_dir / f"{run_tag}_country_citations.csv")
    country_citations = country_citations.dropna(subset=["country", "citation_rows"]).copy()
    country_citations = country_citations[~country_citations["country"].astype(str).str.contains(">", regex=False)].copy()
    country_citations = country_citations[~country_citations["country"].isin(["IGO", "EU"])].copy()
    top_policy_countries = country_citations.sort_values("citation_rows", ascending=False).head(10)["country"].tolist()
    korea_candidate = next(
        (c for c in ["South Korea", "Republic of Korea", "Korea"] if c in set(country_citations["country"].astype(str))),
        "South Korea",
    )
    if korea_candidate not in top_policy_countries:
        top_policy_countries.append(korea_candidate)

    iso2_to_label = _iso2_to_label()
    label_to_iso2 = {v: k for k, v in iso2_to_label.items()}
    # Aliases for robust selection (display labels may differ from raw country strings).
    label_to_iso2.update({"South Korea": "KR", "Korea": "KR", "Republic of Korea": "KR"})
    selected_iso2 = [label_to_iso2[c] for c in top_policy_countries if c in label_to_iso2]
    top_policy_countries_display = [_display_country_label(c) for c in top_policy_countries]

    demand = pd.read_csv(in_dir / f"{run_tag}_country_domain_matrix.csv")
    demand = demand.dropna(subset=["country", "domain", "citation_rows"]).copy()
    demand["country"] = demand["country"].map(_display_country_label)
    demand = demand[demand["country"].isin(top_policy_countries_display)].copy()
    demand_tot = demand.groupby("country", as_index=False)["citation_rows"].sum().rename(columns={"citation_rows": "demand_total"})
    demand = demand.merge(demand_tot, on="country", how="left")
    demand["demand_share"] = demand["citation_rows"] / demand["demand_total"].replace(0, np.nan)

    import duckdb

    con = duckdb.connect()
    iso_list = ",".join([f"'{c}'" for c in selected_iso2]) if selected_iso2 else "''"
    supply_rows = con.execute(
        f"""
        WITH work_domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('Data/openalex_topics.parquet')
          WHERE domain IS NOT NULL
            AND domain <> ''
        )
        SELECT o.first_author_country AS iso2,
               d.domain AS domain,
               COUNT(*) AS citation_rows
        FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
        JOIN work_domains d USING (oaid_w)
        JOIN read_parquet('Data/matched_openalex_with_oa_country_unique.parquet') o USING (oaid_w)
        WHERE o.first_author_country IN ({iso_list})
        GROUP BY 1, 2
        """
    ).df()

    supply_rows["country"] = supply_rows["iso2"].map(iso2_to_label).fillna(supply_rows["iso2"])
    supply_tot = (
        supply_rows.groupby("country", as_index=False)["citation_rows"]
        .sum()
        .rename(columns={"citation_rows": "supply_total"})
    )
    supply = supply_rows.merge(supply_tot, on="country", how="left")
    supply["supply_share"] = supply["citation_rows"] / supply["supply_total"].replace(0, np.nan)

    combined = demand[["country", "domain", "demand_share", "demand_total"]].merge(
        supply[["country", "domain", "supply_share", "supply_total"]],
        on=["country", "domain"],
        how="inner",
    )

    if combined.empty:
        raise ValueError("No overlapping countries found for demand/supply domain comparison.")

    size_base = combined.groupby("country", as_index=False)[["demand_total", "supply_total"]].max()
    size_base["volume"] = (size_base["demand_total"] + size_base["supply_total"]).clip(lower=1)
    size_base["size"] = np.log10(size_base["volume"])
    if size_base["size"].nunique() > 1:
        size_base["marker"] = 60 + (size_base["size"] - size_base["size"].min()) / (size_base["size"].max() - size_base["size"].min()) * 220
    else:
        size_base["marker"] = 140
    marker_map = dict(zip(size_base["country"], size_base["marker"]))

    domain_order = DOMAIN_ORDER
    domain_colors = DOMAIN_PALETTE

    fig, axes = plt.subplots(2, 2, figsize=(10.5, 8.0), sharex=True, sharey=True)
    axes_list = axes.flatten()

    percent_fmt = FuncFormatter(lambda x, _pos=None: f"{x:.0%}")
    y_max = 0.5
    x_max = 0.9
    label_positions: dict[int, tuple[float, float, str, str]] = {
        0: (0.98, 0.06, "right", "bottom"),  # top-left subplot → inner corner
        1: (0.02, 0.94, "left", "top"),  # top-right subplot → clear of size legend
        2: (0.98, 0.94, "right", "top"),  # bottom-left subplot → inner corner
        3: (0.02, 0.94, "left", "top"),  # bottom-right subplot → inner corner
    }

    for idx, (ax, domain) in enumerate(zip(axes_list, domain_order)):
        sub = combined[combined["domain"] == domain].copy()
        if sub.empty:
            ax.axis("off")
            continue

        from matplotlib.patches import Rectangle

        diag_max = min(x_max, y_max)
        shade_below = SOFT_SHADE
        shade_above = "#F9FAFB"
        ax.fill_between([0, diag_max], 0, [0, diag_max], color=shade_below, alpha=1.0, zorder=0)
        ax.fill_between([0, diag_max], [0, diag_max], y_max, color=shade_above, alpha=1.0, zorder=0)
        if x_max > diag_max:
            ax.add_patch(
                Rectangle(
                    (diag_max, 0),
                    x_max - diag_max,
                    y_max,
                    facecolor=shade_below,
                    edgecolor="none",
                    alpha=1.0,
                    zorder=0,
                )
            )

        s = [marker_map.get(c, 120) for c in sub["country"]]
        ax.scatter(
            sub["demand_share"],
            sub["supply_share"],
            s=s,
            color=domain_colors.get(domain, NEUTRAL_GRAY),
            alpha=0.75,
            linewidth=0,
        )
        ax.plot([0, diag_max], [0, diag_max], ls="--", color=REFERENCE_LINE, lw=1.1)
        ax.set_xlim(0, x_max)
        ax.set_ylim(0, y_max)
        ax.xaxis.set_major_formatter(percent_fmt)
        ax.yaxis.set_major_formatter(percent_fmt)
        ax.tick_params(axis="y", pad=1.0)
        x_t, y_t, ha_t, va_t = label_positions.get(idx, (0.98, 0.06, "right", "bottom"))
        ax.text(
            x_t,
            y_t,
            domain,
            transform=ax.transAxes,
            ha=ha_t,
            va=va_t,
            fontsize=11,
            fontweight="bold",
            color=domain_colors.get(domain, NEUTRAL_GRAY),
            alpha=0.95,
        )

        # Deterministic label placements where adjustText cannot separate long
        # labels in dense clusters: (domain, country) -> (dx, dy, ha, va) offsets
        # in data units relative to the point.
        manual_label_offsets: dict[tuple[str, str], tuple[float, float, str, str]] = {
            ("Life Sciences", KOREA_DISPLAY_LABEL): (0.005, 0.08, "left", "bottom"),
        }

        texts: list[plt.Text] = []
        points: list[tuple[float, float]] = []
        sizes: list[float] = []
        manual_texts: list[plt.Text] = []
        manual_points: list[tuple[float, float]] = []
        manual_sizes: list[float] = []
        for _, row in sub.iterrows():
            x = float(row["demand_share"])
            y = float(row["supply_share"])
            country = str(row["country"])
            override = manual_label_offsets.get((domain, country))
            if override is not None:
                dx, dy, ha_o, va_o = override
                manual_texts.append(
                    ax.text(
                        x + dx,
                        y + dy,
                        country,
                        ha=ha_o,
                        va=va_o,
                        fontsize=8,
                        alpha=0.9,
                    )
                )
                manual_points.append((x, y))
                manual_sizes.append(float(marker_map.get(country, 120.0)))
                continue
            texts.append(
                ax.text(
                    x,
                    y,
                    country,
                    ha="left",
                    va="center",
                    fontsize=8,
                    alpha=0.9,
                )
            )
            points.append((x, y))
            sizes.append(float(marker_map.get(country, 120.0)))
        _adjust_text_with_keepout(
            ax,
            texts,
            points,
            sizes=sizes,
            min_len_px=8,
            expand_text=(1.18, 1.35),
            lim=600,
        )
        _add_edge_connectors(ax, texts + manual_texts, points + manual_points, sizes=sizes + manual_sizes)

    fig.suptitle("Domain shares by policy source country and research country", y=0.965)
    fig.supxlabel("Domain share of research cited by policy documents\nPolicy source country", ha="center")
    fig.supylabel(
        "Domain share of each country's research cited by policy documents\nResearch country, first author",
        x=0.01,
        ha="center",
    )

    from matplotlib.lines import Line2D

    vol_values = size_base["volume"].astype(float).to_numpy()
    size_min = float(size_base["size"].min())
    size_max = float(size_base["size"].max())

    def _marker_for_volume(v: float) -> float:
        v = float(max(v, 1.0))
        v_log = float(np.log10(v))
        if size_base["size"].nunique() <= 1 or size_max == size_min:
            return 140.0
        v_norm = (v_log - size_min) / (size_max - size_min)
        return 60.0 + float(np.clip(v_norm, 0.0, 1.0)) * 220.0

    q = np.quantile(vol_values, [0.25, 0.5, 0.75]).astype(float).tolist() if vol_values.size else []
    legend_volumes = sorted({float(v) for v in q if v > 0})
    if len(legend_volumes) < 3 and vol_values.size:
        q2 = np.quantile(vol_values, [0.1, 0.5, 0.9]).astype(float).tolist()
        legend_volumes = sorted({float(v) for v in q2 if v > 0})
    if len(legend_volumes) > 3:
        legend_volumes = [legend_volumes[0], legend_volumes[len(legend_volumes) // 2], legend_volumes[-1]]

    size_legend_handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            color="w",
            markerfacecolor=NEUTRAL_GRAY,
            markersize=np.sqrt(_marker_for_volume(v)),
            alpha=0.7,
            label=_fmt_short(v),
        )
        for v in legend_volumes
    ]
    _transparent(fig, list(axes_list))
    fig.tight_layout(pad=0.45, rect=(0.0, 0.0, 1.0, 0.92))
    fig.subplots_adjust(wspace=0.08, hspace=0.12)
    if size_legend_handles:
        fig.legend(
            handles=size_legend_handles,
            title="Citation count\n(policy source + research country)",
            loc="center right",
            bbox_to_anchor=(0.95, 0.5),
            frameon=True,
            fancybox=True,
            framealpha=0.95,
        )

    out_png = out_dir / f"{run_tag}_country_domain_demand_supply_scatter.png"
    out_csv = out_dir / f"{run_tag}_country_domain_demand_supply_scatter.csv"
    combined.to_csv(out_csv, index=False)
    save_report_figure(fig, out_png, dpi=300, transparent=True, bbox_inches="tight", pad_inches=0.06)
    plt.close(fig)
    return out_png, out_csv
