from __future__ import annotations

from pathlib import Path

import random

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.ticker import FuncFormatter, PercentFormatter

from .common import (
    AUX_CATEG,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    AUX_HIGHLIGHT,
    CORE_CATEG,
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    DOMAIN_LEGEND_LABELS,
    KOREA_DISPLAY_LABEL,
    KOREA_LABEL_ALIASES,
    NEUTRAL_GRAY,
    SOURCE_TYPE_MAJOR_COLORS,
    _add_edge_connectors,
    _adjust_text_with_keepout,
    _annotate_stacked_barh_percent,
    _ccdf_from_counts,
    _contrast_text_color,
    _display_country_label,
    _ellipsize,
    _fmt_short,
    _iso2_to_label,
    _make_domain_palette,
    _openalex_output_shares_by_country_domain,
    _policy_country_label,
    _policy_to_iso2,
    _row_normalize,
    _set_theme,
    _sql_quote,
    _stacked_barh_percent,
    _stacked_barh_percent_grouped,
    _tint,
    _transparent,
)

def figure_si_country_domain_demand_supply_delta_heatmap(*, run_tag: str, in_dir: Path, out_dir: Path) -> Path:
    _doc_color, _core_primary, _text_color, _cmap = _set_theme()

    csv_path = out_dir / f"{run_tag}_country_domain_demand_supply_scatter.csv"
    if not csv_path.exists():
        csv_path = in_dir / f"{run_tag}_country_domain_demand_supply_scatter.csv"
    if not csv_path.exists():
        raise FileNotFoundError(f"Missing demand/supply scatter CSV: {csv_path}")

    df = pd.read_csv(csv_path)
    df = df.dropna(subset=["country", "domain", "demand_share", "supply_share"]).copy()
    df["delta_pp"] = (df["demand_share"] - df["supply_share"]) * 100.0

    order = (
        df[["country", "demand_total"]]
        .drop_duplicates()
        .sort_values("demand_total", ascending=False)["country"]
        .tolist()
    )
    pivot = df.pivot_table(index="country", columns="domain", values="delta_pp", aggfunc="mean")
    pivot = pivot.reindex(index=order, columns=DOMAIN_ORDER)
    pivot = pivot.rename(columns=DOMAIN_LEGEND_LABELS)
    max_abs = float(np.nanmax(np.abs(pivot.to_numpy()))) if pivot.size else 1.0
    if max_abs == 0:
        max_abs = 1.0

    fig, ax = plt.subplots(figsize=(8.8, 5.0))
    cmap = sns.diverging_palette(15, 150, s=70, l=55, as_cmap=True)
    sns.heatmap(
        pivot,
        ax=ax,
        cmap=cmap,
        center=0,
        vmin=-max_abs,
        vmax=max_abs,
        annot=True,
        fmt=".1f",
        cbar_kws={"label": "Policy-source-country share - research-country share (pp)"},
    )
    ax.set_title("Domain-share difference: policy source country minus research country")
    ax.set_xlabel("Domain")
    ax.set_ylabel("Policy source country")
    ax.tick_params(axis="x", rotation=0)

    _transparent(fig, [ax])
    fig.tight_layout(pad=0.6)
    out_png = out_dir / f"{run_tag}_country_domain_demand_supply_delta_heatmap.png"
    fig.savefig(out_png, dpi=300, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)
    return out_png
