from __future__ import annotations

from pathlib import Path

import random

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.ticker import FuncFormatter, PercentFormatter

from .common import (
    AUX_CATEG,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    AUX_HIGHLIGHT,
    CORE_CATEG,
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    DOMAIN_LEGEND_LABELS,
    KOREA_DISPLAY_LABEL,
    KOREA_LABEL_ALIASES,
    NEUTRAL_GRAY,
    SOFT_GRID,
    SOURCE_TYPE_MAJOR_COLORS,
    _add_edge_connectors,
    _adjust_text_with_keepout,
    _annotate_stacked_barh_percent,
    _ccdf_from_counts,
    _contrast_text_color,
    _display_country_label,
    _ellipsize,
    _fmt_short,
    _iso2_to_label,
    _make_domain_palette,
    _openalex_output_shares_by_country_domain,
    _policy_country_label,
    _policy_to_iso2,
    _row_normalize,
    _set_theme,
    _sql_quote,
    _stacked_barh_percent,
    _stacked_barh_percent_grouped,
    _tint,
    _transparent,
)

def figure_si_citation_distribution_ccdf(*, run_tag: str, out_dir: Path) -> Path:
    _doc_color, core_primary, text_color, _cmap = _set_theme()

    citations_path = Path("Data/raw_df_citation_non_duplicated.parquet")
    if not citations_path.exists():
        raise FileNotFoundError(f"Missing citation parquet: {citations_path}")

    import duckdb

    def _ensure_doc_counts_parquet(*, con: duckdb.DuckDBPyConnection) -> Path:
        out_path = out_dir / f"{run_tag}_doc_citation_counts.parquet"
        if out_path.exists():
            return out_path
        out_dir.mkdir(parents=True, exist_ok=True)
        con.execute(
            f"""
            COPY (
                SELECT policy_document_id, COUNT(*) AS n
                FROM read_parquet('{citations_path}')
                GROUP BY policy_document_id
            ) TO '{out_path}' (FORMAT PARQUET)
            """
        )
        return out_path

    def _ensure_paper_counts_parquet(*, con: duckdb.DuckDBPyConnection) -> Path:
        out_path = out_dir / f"{run_tag}_paper_citing_doc_counts.parquet"
        if out_path.exists():
            return out_path
        out_dir.mkdir(parents=True, exist_ok=True)
        con.execute(
            f"""
            COPY (
                SELECT oaid_w, COUNT(DISTINCT policy_document_id) AS n
                FROM read_parquet('{citations_path}')
                WHERE oaid_w IS NOT NULL AND oaid_w <> ''
                GROUP BY oaid_w
            ) TO '{out_path}' (FORMAT PARQUET)
            """
        )
        return out_path

    con = duckdb.connect()
    doc_counts_path = _ensure_doc_counts_parquet(con=con)
    paper_counts_path = _ensure_paper_counts_parquet(con=con)
    doc_counts = con.execute(f"SELECT n FROM read_parquet('{doc_counts_path}')").df()
    paper_counts = con.execute(f"SELECT n FROM read_parquet('{paper_counts_path}')").df()

    doc_ccdf = _ccdf_from_counts(doc_counts["n"]) if not doc_counts.empty else pd.DataFrame({"x": [], "ccdf": []})
    paper_ccdf = _ccdf_from_counts(paper_counts["n"]) if not paper_counts.empty else pd.DataFrame({"x": [], "ccdf": []})

    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.2), sharey=True)
    panels = [
        (doc_ccdf, "Policy documents", "DOI citations per policy document", AUX_PRIMARY),
        (paper_ccdf, "Papers", "Policy documents citing a paper", AUX_SECONDARY),
    ]

    for ax, (data, title, xlabel, color) in zip(axes, panels):
        if data.empty:
            ax.text(0.5, 0.5, "No data", ha="center", va="center", color=text_color, fontsize=9)
            ax.set_axis_off()
            continue
        ax.plot(data["x"], data["ccdf"], color=color, linewidth=2.0)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_xlim(left=1)
        ax.grid(True, which="both", color=SOFT_GRID, linewidth=0.8)
        ax.set_axisbelow(True)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_color(SOFT_GRID)
        ax.spines["bottom"].set_color(SOFT_GRID)

    axes[0].set_ylabel("Share of items (>= x)")
    fig.suptitle("Citation concentration (log-log CCDF)", y=1.02)

    _transparent(fig, list(axes))
    fig.tight_layout(pad=0.6)

    out_png = out_dir / f"{run_tag}_citation_distribution_ccdf.png"
    fig.savefig(out_png, dpi=300, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)
    return out_png
