from __future__ import annotations

from pathlib import Path

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

from .common import _fmt_short, _set_theme, _transparent, save_report_figure


def figure_7_source_type_citations(*, run_tag: str, in_dir: Path, out_dir: Path) -> Path:
    _doc_color, core_primary, _text_color, _cmap = _set_theme()

    source_type_cit = pd.read_csv(in_dir / f"{run_tag}_source_type_citations.csv")
    plot_df = source_type_cit.nlargest(10, "citation_rows").copy().sort_values("citation_rows", ascending=False)

    fig, ax = plt.subplots(figsize=(8, 5))
    sns.barplot(
        data=plot_df,
        y="source_type",
        x="citation_rows",
        order=plot_df["source_type"].tolist(),
        ax=ax,
        color=core_primary,
    )
    ax.yaxis.grid(False)
    ax.xaxis.grid(True)
    ax.set_title("Citations by policy source type (top 10)")
    ax.set_xlabel("Citations")
    ax.set_ylabel("Source type")
    ax.xaxis.set_major_formatter(FuncFormatter(_fmt_short))

    _transparent(fig, [ax])
    fig.tight_layout()
    out_path = out_dir / f"{run_tag}_source_type_citations_top10.png"
    save_report_figure(fig, out_path, dpi=200, transparent=True)
    plt.close(fig)
    return out_path
