from __future__ import annotations

from pathlib import Path

import random

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.ticker import FuncFormatter, PercentFormatter

from .common import (
    AUX_CATEG,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    AUX_HIGHLIGHT,
    CORE_CATEG,
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    DOMAIN_LEGEND_LABELS,
    KOREA_DISPLAY_LABEL,
    KOREA_LABEL_ALIASES,
    NEUTRAL_GRAY,
    SOURCE_TYPE_MAJOR_COLORS,
    _add_edge_connectors,
    _adjust_text_with_keepout,
    _annotate_stacked_barh_percent,
    _ccdf_from_counts,
    _contrast_text_color,
    _display_country_label,
    _ellipsize,
    _fmt_short,
    _iso2_to_label,
    _make_domain_palette,
    _openalex_output_shares_by_country_domain,
    _policy_country_label,
    _policy_to_iso2,
    _row_normalize,
    _set_theme,
    _sql_quote,
    _stacked_barh_percent,
    _stacked_barh_percent_grouped,
    _tint,
    _transparent,
)

def figure_si_korea_peer_group_by_policy_docs(
    *, run_tag: str, in_dir: Path, out_dir: Path, peer_count: int = 6
) -> Path:
    """
    Build a coverage-matched peer group for Korea to avoid over-reading rank comparisons.

    Matching criterion: number of policy-source documents tagged to a country in Overton metadata
    (see `{run_tag}_country_policy_docs.csv`). This is an *observed* coverage/volume proxy, not
    an all-policy denominator.
    """

    country_docs_path = in_dir / f"{run_tag}_country_policy_docs.csv"
    if not country_docs_path.exists():
        raise FileNotFoundError(f"Missing country policy-doc counts CSV: {country_docs_path}")

    country_cit_path = in_dir / f"{run_tag}_country_citations.csv"
    if not country_cit_path.exists():
        raise FileNotFoundError(f"Missing country citations CSV: {country_cit_path}")

    docs = pd.read_csv(country_docs_path)
    docs = docs.dropna(subset=["country", "policy_docs"]).copy()
    docs["policy_docs"] = pd.to_numeric(docs["policy_docs"], errors="coerce")
    docs = docs.dropna(subset=["policy_docs"]).copy()
    docs["country"] = docs["country"].astype(str)
    docs = docs[~docs["country"].str.contains(">")].copy()
    docs = docs[~docs["country"].isin(["Unknown", "EU", "IGO"])].copy()

    korea_key = "South Korea"
    if korea_key not in set(docs["country"].tolist()):
        raise ValueError(f"Korea row not found in {country_docs_path} (expected '{korea_key}').")

    korea_docs = float(docs.loc[docs["country"].eq(korea_key), "policy_docs"].iloc[0])
    docs["diff_policy_docs"] = (docs["policy_docs"] - korea_docs).abs()

    peer_count = int(peer_count)
    if peer_count < 1:
        raise ValueError("peer_count must be >= 1")

    # Keep Korea + nearest peers by observed policy-doc volume.
    selected = (
        docs.sort_values(["diff_policy_docs", "policy_docs"], ascending=[True, True])
        .head(1 + peer_count)["country"]
        .astype(str)
        .tolist()
    )

    cit = pd.read_csv(country_cit_path)
    cit = cit.dropna(subset=["country", "citation_rows", "citing_policy_docs"]).copy()
    cit["country"] = cit["country"].astype(str)
    cit = cit[~cit["country"].str.contains(">")].copy()
    cit = cit[~cit["country"].isin(["Unknown", "EU", "IGO"])].copy()
    cit["citation_rows"] = pd.to_numeric(cit["citation_rows"], errors="coerce")
    cit["citing_policy_docs"] = pd.to_numeric(cit["citing_policy_docs"], errors="coerce")

    merged = docs.merge(cit, on="country", how="left")
    merged = merged[merged["country"].isin(selected)].copy()

    merged["citations_per_citing_doc"] = merged["citation_rows"] / merged["citing_policy_docs"]
    merged["citing_share"] = merged["citing_policy_docs"] / merged["policy_docs"].replace(0, np.nan)
    merged["country_label"] = merged["country"].map(_display_country_label)

    merged["is_korea"] = merged["country"].eq(korea_key)
    merged = merged.sort_values(["is_korea", "diff_policy_docs"], ascending=[False, True]).copy()

    out_csv = out_dir / f"{run_tag}_korea_peer_group_by_policy_docs.csv"
    merged[
        [
            "country",
            "country_label",
            "policy_docs",
            "citing_policy_docs",
            "citing_share",
            "citation_rows",
            "citations_per_citing_doc",
            "diff_policy_docs",
        ]
    ].to_csv(out_csv, index=False)

    return out_csv
