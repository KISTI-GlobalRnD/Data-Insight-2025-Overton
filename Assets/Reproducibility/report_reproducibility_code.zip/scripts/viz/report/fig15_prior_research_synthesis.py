from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from .common import (
    AUX_HIGHLIGHT,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    _set_theme,
    _transparent,
    save_report_figure,
)


def figure_15_prior_research_synthesis(*, run_tag: str, out_dir: Path) -> Path:
    """Replot published summary statistics without reproducing source artwork."""

    _doc_color, _core_primary, text_color, _cmap = _set_theme()

    fig, axes = plt.subplots(
        1,
        3,
        figsize=(13.8, 4.55),
        gridspec_kw={"width_ratios": [0.82, 1.18, 1.55], "wspace": 0.68},
    )
    ax_a, ax_b, ax_c = axes

    # Fang et al. (2024): 18,343,140 WoS publications, 2010-2019.
    coverage = 3.9
    ax_a.bar([0], [coverage], color=AUX_PRIMARY, width=0.52)
    ax_a.text(
        0,
        coverage + 0.35,
        f"{coverage:.1f}%",
        va="bottom",
        ha="center",
        fontsize=17,
        fontweight="bold",
        color=AUX_PRIMARY,
    )
    ax_a.set_xlim(-0.65, 0.65)
    ax_a.set_ylim(0, 15)
    ax_a.set_xticks([0])
    ax_a.set_xticklabels(["18.34M WoS publications\n(2010-2019)"], fontsize=8.5)
    ax_a.set_ylabel("Share of publications (%)")
    ax_a.set_title("A. Cited by policy documents\nat least once", fontsize=10.5, fontweight="bold")
    ax_a.xaxis.grid(False)
    ax_a.yaxis.grid(True)

    # Bornmann et al. (2022): paper-level Spearman correlations.
    corr_labels = ["All policy-cited\npapers", "Climate-policy-cited\npapers"]
    corr_values = [0.16, 0.20]
    corr_colors = [AUX_SECONDARY, AUX_PRIMARY]
    x_b = np.arange(len(corr_labels))
    ax_b.bar(x_b, corr_values, color=corr_colors, width=0.58)
    for x, value in zip(x_b, corr_values, strict=True):
        ax_b.text(x, value + 0.012, f"{value:.2f}", va="bottom", ha="center", fontsize=11, fontweight="bold")
    ax_b.set_xticks(x_b)
    ax_b.set_xticklabels(corr_labels, fontsize=8.5)
    ax_b.set_ylim(0, 0.30)
    ax_b.set_ylabel("Spearman correlation")
    ax_b.set_title("B. Scholarly citations vs.\ncitations from policy documents", fontsize=10.5, fontweight="bold")
    ax_b.xaxis.grid(False)
    ax_b.yaxis.grid(True)

    # Fang et al. (2024): policy-citation coverage by broad field.
    field_labels = [
        "Social Sciences\n& Humanities",
        "Life & Earth\nSciences",
        "Biomedical &\nHealth Sciences",
        "Mathematics &\nComputer Science",
        "Physical Sciences\n& Engineering",
    ]
    field_values = [12.34, 5.96, 5.72, 0.93, 0.62]
    field_colors = [AUX_PRIMARY, AUX_SECONDARY, AUX_TERTIARY, AUX_HIGHLIGHT, AUX_HIGHLIGHT]
    y_c = np.arange(len(field_labels))
    ax_c.barh(y_c, field_values, color=field_colors, height=0.58)
    for y, value in zip(y_c, field_values, strict=True):
        ax_c.text(value + 0.22, y, f"{value:.2f}%", va="center", ha="left", fontsize=9.5, fontweight="bold")
    ax_c.set_yticks(y_c)
    ax_c.set_yticklabels(field_labels)
    ax_c.invert_yaxis()
    ax_c.set_xlim(0, 14.6)
    ax_c.set_xlabel("Share cited at least once")
    ax_c.set_title("C. Share cited by policy documents\nvaries by field", fontsize=10.5, fontweight="bold")
    ax_c.xaxis.grid(True)
    ax_c.yaxis.grid(False)

    for ax in axes:
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    fig.suptitle(
        "Prior evidence: scholarly papers are cited selectively by policy documents, with field differences",
        fontsize=13,
        fontweight="bold",
        y=0.98,
    )
    fig.text(
        0.5,
        0.025,
        "Sources: Fang et al. (2024), panels A and C; Bornmann et al. (2022), panel B. Samples and denominators differ across panels.",
        ha="center",
        va="bottom",
        fontsize=8.3,
        color=text_color,
    )
    _transparent(fig, list(axes))
    fig.subplots_adjust(left=0.06, right=0.985, bottom=0.22, top=0.78, wspace=0.68)

    out_path = out_dir / f"{run_tag}_prior_research_synthesis.png"
    save_report_figure(fig, out_path, dpi=220, transparent=True, bbox_inches="tight", pad_inches=0.05)
    plt.close(fig)
    return out_path
