from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from .common import (
    DOMAIN_LEGEND_LABELS,
    REFERENCE_LINE,
    REFERENCE_TEXT,
    _add_edge_connectors,
    _adjust_text_with_keepout,
    _ellipsize,
    _make_domain_palette,
    _set_theme,
    _transparent,
    save_report_figure,
)


def figure_4_topic_intensity_vs_recency(*, run_tag: str, in_dir: Path, out_dir: Path) -> tuple[Path, Path]:
    _doc_color, _core_primary, _text_color, _cmap = _set_theme()

    df = pd.read_csv(in_dir / f"{run_tag}_topic_intensity_recency.csv")
    required = {"topic", "domain", "intensity", "recent_paper_share"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(
            "Topic metric input uses the legacy citation-row recency definition. "
            "Run scripts/make_topic_intensity_recency.py first. "
            f"Missing columns: {sorted(missing)}"
        )
    df = df.dropna(subset=list(required)).copy()
    df = df[df["intensity"] > 0].copy()
    domain_order, domain_palette = _make_domain_palette(df["domain"])

    fig, ax = plt.subplots(figsize=(9.2, 6.2))
    sns.scatterplot(
        data=df,
        x="intensity",
        y="recent_paper_share",
        hue="domain",
        hue_order=domain_order or None,
        palette=domain_palette or None,
        alpha=0.75,
        linewidth=0,
        zorder=2,
        ax=ax,
    )
    recent_max = float(df["recent_paper_share"].max())
    ax.set_ylim(0, min(1.0, max(0.15, recent_max * 1.12)))
    ax.set_xlabel("Policy citations per paper")
    ax.set_ylabel("Share of unique papers published in 2022-2024")

    intensity = df["intensity"].astype(float).replace([np.inf, -np.inf], np.nan).dropna()
    if len(intensity):
        intensity_mean = float(intensity.mean())
        ax.axvline(intensity_mean, color=REFERENCE_LINE, linestyle="--", linewidth=1.2, alpha=0.7, zorder=1)
    recent_mean = float(df["recent_paper_share"].astype(float).mean())
    ax.axhline(recent_mean, color=REFERENCE_LINE, linestyle="--", linewidth=1.2, alpha=0.7, zorder=1)
    from matplotlib.ticker import PercentFormatter

    ax.yaxis.set_major_formatter(PercentFormatter(1.0))

    median_label_color = REFERENCE_TEXT
    if len(intensity):
        ax.annotate(
            "Mean policy citations per paper",
            xy=(intensity_mean, 0.02),
            xycoords=ax.get_xaxis_transform(),
            xytext=(0, -10),
            textcoords="offset points",
            ha="center",
            va="top",
            fontsize=8,
            color=median_label_color,
        )
    ax.annotate(
        "Mean recent unique-paper share",
        xy=(0.02, recent_mean),
        xycoords=ax.get_yaxis_transform(),
        xytext=(0, -8),
        textcoords="offset points",
        ha="left",
        va="top",
        fontsize=8,
        color=median_label_color,
    )

    # Label the clearest high-recency and high-intensity examples without crowding the chart.
    label_recent = df.sort_values("recent_paper_share", ascending=False).head(8)
    label_intensity = df.sort_values("intensity", ascending=False).head(3)
    label_df = (
        pd.concat([label_recent, label_intensity], ignore_index=True)
        .drop_duplicates(subset=["topic"], keep="first")
        .copy()
    )
    intensity_topics = set(label_intensity["topic"].astype(str).tolist())
    high_intensity_y = {
        str(topic): float(y)
        for topic, y in zip(
            label_intensity["topic"].astype(str),
            np.linspace(ax.get_ylim()[1] * 0.30, ax.get_ylim()[1] * 0.18, len(label_intensity)),
        )
    }
    texts = []
    points = []
    sizes = []
    default_s = plt.rcParams["lines.markersize"] ** 2
    for _, row in label_df.iterrows():
        is_high_intensity = str(row["topic"]) in intensity_topics
        y = float(row["recent_paper_share"])
        if is_high_intensity:
            y = high_intensity_y[str(row["topic"])]
        texts.append(
            ax.text(
                float(row["intensity"]),
                y,
                _ellipsize(row["topic"], 25),
                ha="right",
                va="bottom" if is_high_intensity else "center",
                fontsize=8,
                alpha=0.85,
            )
        )
        points.append((float(row["intensity"]), float(row["recent_paper_share"])))
        sizes.append(default_s)
    _adjust_text_with_keepout(
        ax,
        texts,
        points,
        sizes=sizes,
        min_len_px=10,
        only_move={"points": "xy", "text": "y"},
    )
    _add_edge_connectors(ax, texts, points, sizes=sizes)
    handles, labels = ax.get_legend_handles_labels()
    labels = [DOMAIN_LEGEND_LABELS.get(label, label) for label in labels]
    ax.legend(handles=handles, labels=labels, title="Domain", loc="upper right", frameon=True)

    _transparent(fig, [ax])
    fig.tight_layout()

    out_png = out_dir / f"{run_tag}_topic_intensity_vs_recency.png"
    out_csv = out_dir / f"{run_tag}_topic_intensity_recency.csv"
    df.to_csv(out_csv, index=False)
    save_report_figure(fig, out_png, dpi=200, transparent=True)
    plt.close(fig)
    return out_png, out_csv
