from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

from .common import (
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    NEUTRAL_GRAY,
    REFERENCE_LINE,
    REFERENCE_TEXT,
    _set_theme,
    _transparent,
    save_report_figure,
)


def _require_paths(paths: list[Path]) -> None:
    missing = [path for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError(
            "Missing integrated Korea source-structure inputs: " + ", ".join(map(str, missing))
        )


def _metric_map(frame: pd.DataFrame) -> dict[str, float]:
    return frame.set_index("metric")["value"].astype(float).to_dict()


def figure_18_korea_integrated_source_structure(
    *, run_tag: str, out_dir: Path
) -> Path:
    """Combine the report's Korea decomposition and peer-context visuals.

    The renderer consumes the aggregate CSVs written by figures 16 and 17. It does
    not recalculate the decomposition or institutional comparison, so the existing
    public verification targets and detailed SI figures remain unchanged.
    """

    _set_theme()
    out_dir.mkdir(parents=True, exist_ok=True)

    decomposition_path = out_dir / f"{run_tag}_korea_social_science_gap_decomposition.csv"
    source_type_path = out_dir / f"{run_tag}_korea_policy_source_type_composition.csv"
    country_path = out_dir / f"{run_tag}_country_think_tank_concentration.csv"
    eligible_path = out_dir / f"{run_tag}_foreign_think_tank_field_distribution.csv"
    peer_summary_path = out_dir / f"{run_tag}_kdi_kiep_peer_institution_summary.csv"
    institution_path = out_dir / f"{run_tag}_korea_policy_source_concentration.csv"
    _require_paths(
        [
            decomposition_path,
            source_type_path,
            country_path,
            eligible_path,
            peer_summary_path,
            institution_path,
        ]
    )

    decomposition = _metric_map(pd.read_csv(decomposition_path))
    source_type = pd.read_csv(source_type_path)
    countries = pd.read_csv(country_path)
    eligible = pd.read_csv(eligible_path)
    peer_summary = _metric_map(pd.read_csv(peer_summary_path))
    institutions = pd.read_csv(institution_path)

    composition_pp = decomposition["source_group_composition_component"]
    within_pp = decomposition["within_source_group_component"]
    observed_pp = decomposition["observed_social_science_gap"]
    kdi_kiep_all_share = decomposition[
        "kdi_kiep_combined_citation_share_within_korea_policy_documents"
    ]
    korea_policy_think_share = float(
        source_type.loc[
            source_type["direction"].eq("Korea policy documents citing research")
            & source_type["source_group"].eq("Think tank"),
            "citation_share",
        ].iloc[0]
    )
    korea_research_think_share = float(
        source_type.loc[
            source_type["direction"].eq("Policy documents citing Korea-authored research")
            & source_type["source_group"].eq("Think tank"),
            "citation_share",
        ].iloc[0]
    )
    kdi_kiep_documents = float(
        institutions.loc[
            institutions["source_slug"].isin(["kdi", "kiep"]), "policy_documents"
        ].sum()
    )
    doi_citing_documents = float(institutions["policy_documents"].sum())
    kdi_kiep_document_share = kdi_kiep_documents / doi_citing_documents

    # Panel B remains the main chart. Panels A and C share a separate inset axis:
    # both locate social-science shares among four-domain citation assignments.
    # A is drawn as a floating decomposition from the Korea-research direction to
    # the Korea-policy direction; C puts the foreign think-tank distribution and
    # the KDI/KIEP points on that same social-science-share axis.
    fig = plt.figure(figsize=(8.4, 10.0))
    grid = fig.add_gridspec(2, 1, height_ratios=[1.58, 0.78], hspace=0.46)
    ax = fig.add_subplot(grid[0])
    ax_ac = fig.add_subplot(grid[1])

    country_rows = countries.sort_values("think_tank_citation_share", ascending=False).copy()
    country_rows["label"] = country_rows["display_country"]
    country_rows.loc[country_rows["display_country"].eq("Republic of Korea"), "label"] = (
        "Korea policy docs → research"
    )
    labels = country_rows["label"].tolist() + ["Policy docs → Korea research"]
    bar_values = country_rows["think_tank_citation_share"].astype(float).tolist() + [
        korea_research_think_share
    ]
    bar_positions = list(np.arange(len(country_rows), dtype=float)) + [len(country_rows) + 0.65]
    colors = [
        AUX_TERTIARY if label == "Korea policy docs → research" else NEUTRAL_GRAY
        for label in country_rows["label"]
    ] + [AUX_SECONDARY]
    edgecolors = ["white"] * len(country_rows) + [AUX_PRIMARY]
    bars = ax.barh(
        bar_positions,
        bar_values,
        height=0.66,
        color=colors,
        edgecolor=edgecolors,
        linewidth=1.2,
    )
    for bar, value, label in zip(bars, bar_values, labels):
        inside = value >= 0.14
        ax.text(
            value - 0.012 if inside else value + 0.012,
            bar.get_y() + bar.get_height() / 2,
            f"{value:.1%}",
            ha="right" if inside else "left",
            va="center",
            fontsize=10.4,
            fontweight="bold" if label in {
                "Korea policy docs → research",
                "Policy docs → Korea research",
            } else "normal",
            color="white" if inside else "#405047",
        )
    key_countries = {"Republic of Korea", "Brazil", "Germany"}
    for index, row in country_rows.reset_index(drop=True).iterrows():
        if row["display_country"] not in key_countries:
            continue
        if row["display_country"] == "Republic of Korea":
            annotation = (
                f"KDI + KIEP: {float(row['top2_share_within_think_tanks']):.1%} of TT citations\n"
                f"{kdi_kiep_all_share:.1%} of all citations · "
                f"{kdi_kiep_document_share:.1%} of DOI-citing documents"
            )
        else:
            annotation = f"top 2 of TT citations: {float(row['top2_share_within_think_tanks']):.1%}"
        ax.text(
            1.035,
            bar_positions[index],
            annotation,
            ha="left",
            va="center",
            fontsize=9.2,
            color="#53635A",
            fontweight="bold" if row["display_country"] == "Republic of Korea" else "normal",
        )
    ax.axhline(len(country_rows) + 0.28, color=REFERENCE_LINE, linewidth=1.0)

    # A/C inset: one common social-science-share axis, two distinct rows.
    peer_values = eligible["Social Sciences"].astype(float).sort_values().to_numpy()
    median = float(np.median(peer_values))
    kdi_social = peer_summary["kdi_social_science_share"]
    kiep_social = peer_summary["kiep_social_science_share"]
    kdi_percentile = float(np.mean(peer_values <= kdi_social))
    kiep_percentile = float(np.mean(peer_values <= kiep_social))
    korea_policy_social = decomposition[
        "social_science_share_korea_policy_documents_citing_research"
    ]
    korea_research_social = decomposition[
        "social_science_share_policy_documents_citing_korea_research"
    ]

    ax_ac.set_facecolor("#FCFDFC")
    ax_ac.axhspan(-0.40, 0.40, color="#F4F8F5", zorder=0)
    ax_ac.barh(
        [1.0],
        [composition_pp / 100],
        left=[korea_research_social],
        color=AUX_PRIMARY,
        height=0.43,
        zorder=3,
    )
    ax_ac.barh(
        [1.0],
        [within_pp / 100],
        left=[korea_research_social + composition_pp / 100],
        color=AUX_TERTIARY,
        height=0.43,
        zorder=3,
    )
    ax_ac.scatter(
        [korea_research_social, korea_policy_social],
        [1.0, 1.0],
        s=46,
        marker="|",
        color="#263A31",
        linewidth=2.0,
        zorder=5,
    )
    ax_ac.text(
        korea_research_social + (composition_pp / 100) / 2,
        1.0,
        f"Source mix\n{composition_pp:.1f} pp",
        ha="center",
        va="center",
        color="white",
        fontsize=10.2,
        fontweight="bold",
        zorder=6,
    )
    ax_ac.text(
        korea_research_social + composition_pp / 100 + (within_pp / 100) / 2,
        1.0,
        f"Within type\n{within_pp:.1f} pp",
        ha="center",
        va="center",
        color="white",
        fontsize=9.6,
        fontweight="bold",
        zorder=6,
    )
    ax_ac.annotate(
        f"Policy → Korea research\n{korea_research_social:.1%}",
        xy=(korea_research_social, 1.0),
        xytext=(korea_research_social, 1.37),
        ha="center",
        va="bottom",
        fontsize=10.0,
        fontweight="bold",
        color="#405047",
        arrowprops={"arrowstyle": "-", "color": REFERENCE_LINE, "linewidth": 0.9},
    )
    ax_ac.annotate(
        f"Korea policy → research\n{korea_policy_social:.1%}",
        xy=(korea_policy_social, 1.0),
        xytext=(korea_policy_social, 1.37),
        ha="center",
        va="bottom",
        fontsize=10.0,
        fontweight="bold",
        color="#405047",
        arrowprops={"arrowstyle": "-", "color": REFERENCE_LINE, "linewidth": 0.9},
    )
    ax_ac.text(
        (korea_research_social + korea_policy_social) / 2,
        0.67,
        f"Observed gap {observed_pp:.1f} pp",
        ha="center",
        va="center",
        fontsize=10.2,
        fontweight="bold",
        color="#405047",
    )

    distribution_position = 0.0
    ax_ac.boxplot(
        peer_values,
        vert=False,
        positions=[distribution_position],
        widths=0.46,
        patch_artist=True,
        showfliers=False,
        manage_ticks=False,
        boxprops={"facecolor": NEUTRAL_GRAY, "edgecolor": REFERENCE_LINE},
        medianprops={"color": AUX_PRIMARY, "linewidth": 2.1},
        whiskerprops={"color": REFERENCE_LINE, "linewidth": 1.2},
        capprops={"color": REFERENCE_LINE, "linewidth": 1.2},
    )
    jitter = np.random.default_rng(20251026).uniform(-0.16, 0.16, len(peer_values))
    ax_ac.scatter(
        peer_values,
        distribution_position + jitter,
        s=10,
        color="#7D9488",
        alpha=0.52,
        edgecolor="white",
        linewidth=0.25,
        zorder=3,
    )
    ax_ac.scatter(
        [kdi_social],
        [distribution_position + 0.12],
        s=72,
        marker="D",
        color=AUX_PRIMARY,
        edgecolor="white",
        linewidth=1.1,
        zorder=5,
    )
    ax_ac.scatter(
        [kiep_social],
        [distribution_position - 0.12],
        s=72,
        marker="D",
        color=AUX_TERTIARY,
        edgecolor="white",
        linewidth=1.1,
        zorder=5,
    )
    ax_ac.text(
        median,
        distribution_position - 0.34,
        f"Median {median:.1%}",
        ha="center",
        va="top",
        fontsize=9.8,
        color="#405047",
    )
    ax_ac.axvline(
        korea_policy_social,
        ymin=0.15,
        ymax=0.68,
        color=REFERENCE_LINE,
        linewidth=0.9,
        linestyle=(0, (3, 3)),
        zorder=1,
    )
    ax_ac.set_xlim(0, 1)
    ax_ac.set_ylim(-0.52, 1.62)
    ax_ac.set_xticks(np.linspace(0, 1, 6))
    ax_ac.xaxis.set_major_formatter(
        plt.FuncFormatter(lambda value, _pos=None: f"{value:.0%}")
    )
    ax_ac.set_yticks(
        [1.0, 0.0],
        [
            "A  Gap\ndecomposition",
            (
                "C  Foreign think tanks\n"
                f"({int(peer_summary['foreign_eligible_think_tank_count'])}; "
                f"{int(peer_summary['foreign_eligible_think_tank_country_count'])} countries)"
            ),
        ],
    )
    ax_ac.tick_params(axis="x", labelsize=9.8, pad=2)
    ax_ac.tick_params(axis="y", labelsize=9.8, length=0, pad=5)
    ax_ac.set_xlabel(
        "Social-science share of four-domain citation assignments",
        fontsize=10.0,
        labelpad=3,
    )
    ax_ac.set_title(
        "A/C. Gap decomposition and foreign distribution",
        loc="left",
        fontsize=11.3,
        fontweight="bold",
        pad=5,
    )
    ax_ac.grid(axis="x", color="#E5ECE8", linewidth=0.8)
    ax_ac.grid(axis="y", visible=False)
    for spine in ("right", "top", "left"):
        ax_ac.spines[spine].set_visible(False)
    ax_ac.spines["bottom"].set_color(REFERENCE_LINE)

    ax.set_yticks(bar_positions, labels)
    ax.set_ylim(len(country_rows) + 1.28, -1.05)
    ax.set_xlim(0, 1.52)
    ax.set_xticks(np.linspace(0, 1, 6))
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda value, _pos=None: f"{value:.0%}"))
    ax.set_xlabel("Think-tank share of DOI-linked citations", fontsize=11.3, labelpad=7)
    ax.tick_params(axis="x", labelsize=10.0)
    ax.tick_params(axis="y", labelsize=9.8)
    ax.set_title(
        "B. Think-tank shares of DOI-linked citations",
        loc="left",
        fontsize=12.5,
        fontweight="bold",
        pad=10,
    )
    ax.grid(axis="y", visible=False)
    for spine in ("right", "top"):
        ax.spines[spine].set_visible(False)

    fig.suptitle(
        "Korea's large social-science gap is observed mainly in source composition,\n"
        "with strong institutional concentration",
        fontsize=14.2,
        fontweight="bold",
        y=0.985,
    )
    legend_handles = [
        Patch(facecolor=AUX_TERTIARY, edgecolor="white", label="Korea policy → research"),
        Patch(facecolor=NEUTRAL_GRAY, edgecolor="white", label="Comparison country"),
        Patch(facecolor=AUX_SECONDARY, edgecolor=AUX_PRIMARY, label="Policy → Korea research"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor="#7D9488", markeredgecolor="white", markersize=7, label="Foreign think tanks"),
        Line2D([0], [0], marker="D", color="none", markerfacecolor=AUX_PRIMARY, markeredgecolor="white", markersize=7, label=f"KDI {kdi_social:.1%} ({100*kdi_percentile:.1f}th pct.)"),
        Line2D([0], [0], marker="D", color="none", markerfacecolor=AUX_TERTIARY, markeredgecolor="white", markersize=7, label=f"KIEP {kiep_social:.1%} ({100*kiep_percentile:.1f}th pct.)"),
    ]
    fig.legend(
        handles=legend_handles,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.052),
        ncol=3,
        frameon=False,
        fontsize=8.9,
        handlelength=1.6,
        columnspacing=1.0,
        labelspacing=0.55,
        borderaxespad=0,
    )
    fig.text(
        0.5,
        0.014,
        "B uses all DOI-linked citations; A and C share a separate social-science axis based on four-domain citation assignments. "
        "A components are percentage-point contributions, and their order is not a causal sequence; top-two values in B are conditional on think-tank citations. "
        "Descriptive, not causal; source type does not establish equivalent institutional roles.",
        ha="center",
        va="bottom",
        fontsize=8.8,
        color="#53635A",
        wrap=True,
    )
    fig.subplots_adjust(left=0.23, right=0.985, top=0.91, bottom=0.17)
    _transparent(fig, [ax, ax_ac])

    out_png = out_dir / f"{run_tag}_korea_field_gap_source_structure.png"
    save_report_figure(
        fig,
        out_png,
        dpi=300,
        transparent=True,
        bbox_inches="tight",
        pad_inches=0.06,
    )
    plt.close(fig)
    return out_png
