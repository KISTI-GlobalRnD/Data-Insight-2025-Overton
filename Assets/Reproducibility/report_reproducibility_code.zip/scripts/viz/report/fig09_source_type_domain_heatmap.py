from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from .common import (
    DOMAIN_LEGEND_LABELS,
    DOMAIN_ORDER,
    REFERENCE_TEXT,
    SOURCE_TYPE_MAJOR_LABELS,
    _display_source_type_label,
    _fmt_short,
    _set_theme,
    _transparent,
    save_report_figure,
)


def figure_9_source_type_domain_heatmap(*, run_tag: str, in_dir: Path, out_dir: Path) -> Path:
    _doc_color, _core_primary, _text_color, cmap = _set_theme()

    mat = pd.read_csv(in_dir / f"{run_tag}_source_type_domain_matrix.csv")
    mat = mat.dropna(subset=["domain"]).copy()
    mat["major_type"] = mat["source_type"].astype(str).str.split(">").str[0].str.strip()
    major_counts = (
        mat[mat["major_type"].ne("")]
        .groupby("major_type")["source_type"]
        .nunique()
        .sort_values(ascending=False)
    )
    major_subtype_counts = (
        mat[mat["major_type"].ne("") & mat["source_type"].ne(mat["major_type"])]
        .groupby("major_type")["source_type"]
        .nunique()
        .sort_values(ascending=False)
    )
    source_major_map = (
        mat.drop_duplicates(subset=["source_type"])
        .set_index("source_type")["major_type"]
        .to_dict()
    )

    pivot = mat.pivot_table(index="source_type", columns="domain", values="citation_rows", fill_value=0)

    major_order = (
        mat.groupby("major_type")["citation_rows"]
        .sum()
        .sort_values(ascending=False)
        .index.tolist()
    )

    # Select source types that cover ~90% of citations within each major type.
    source_totals = (
        mat.groupby(["major_type", "source_type"], as_index=False)["citation_rows"]
        .sum()
        .sort_values(["major_type", "citation_rows"], ascending=[True, False])
    )
    source_types: list[str] = []
    for major in major_order:
        sub = source_totals[source_totals["major_type"] == major].copy()
        if sub.empty:
            continue
        sub["share"] = sub["citation_rows"] / sub["citation_rows"].sum()
        sub["cum_share"] = sub["share"].cumsum()
        keep = sub[sub["cum_share"] <= 0.9]
        if keep.empty:
            keep = sub.head(1)
        else:
            last_idx = keep.index[-1]
            if float(sub.loc[last_idx, "cum_share"]) < 0.9 and len(keep) < len(sub):
                keep = sub.head(len(keep) + 1)
        source_types.extend(keep["source_type"].tolist())

    major_counts_selected = (
        mat[mat["source_type"].isin(source_types)]
        .groupby("major_type")["source_type"]
        .nunique()
        .sort_values(ascending=False)
    )
    coverage_share = {}
    for major in major_order:
        major_total = float(source_totals.loc[source_totals["major_type"] == major, "citation_rows"].sum())
        major_sel = float(
            source_totals.loc[
                (source_totals["major_type"] == major)
                & (source_totals["source_type"].isin(source_types)),
                "citation_rows",
            ].sum()
        )
        coverage_share[major] = major_sel / major_total if major_total > 0 else 0.0
    source_types_ordered: list[str] = []
    for major in major_order:
        group = [s for s in source_types if source_major_map.get(s) == major]
        group = sorted(group, key=lambda s: float(pivot.sum(axis=1).get(s, 0.0)), reverse=True)
        source_types_ordered.extend(group)
    # append any remaining (e.g., missing major)
    for s in source_types:
        if s not in source_types_ordered:
            source_types_ordered.append(s)
    pivot_sel = pivot.loc[source_types_ordered]
    domains_raw = pivot_sel.sum(axis=0).sort_values(ascending=False).head(6).index.astype(str).tolist()
    domains_extra = [d for d in domains_raw if d not in DOMAIN_ORDER and d != "Unknown"]
    domains = [d for d in DOMAIN_ORDER if d in domains_raw] + domains_extra
    if "Unknown" in domains_raw:
        domains.append("Unknown")
    pivot_share = pivot_sel.div(pivot_sel.sum(axis=1).replace(0, np.nan), axis=0).fillna(0)
    share_sel = pivot_share.loc[:, domains]
    dominant = share_sel.idxmax(axis=1)
    dominant_share = share_sel.max(axis=1)
    domain_rank = {d: i for i, d in enumerate(domains)}
    source_types_ordered = source_types_ordered
    pivot_plot = pivot_share.loc[source_types_ordered, domains].T  # domain x source_type (share)

    n_cols = pivot_plot.shape[1]
    n_rows = pivot_plot.shape[0]
    cell_size = 0.75
    fig_w = max(11.0, cell_size * n_cols + 3.2)
    fig_h = max(4.8, cell_size * n_rows + 2.6)
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    vmax = 0.60
    im = ax.imshow(
        pivot_plot.values,
        cmap=cmap,
        vmin=0.0,
        vmax=vmax,
        interpolation="nearest",
    )
    from mpl_toolkits.axes_grid1 import make_axes_locatable
    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="3.5%", pad=0.08)
    cbar = fig.colorbar(im, cax=cax)
    cbar.set_label("Share within source type")
    cbar.set_ticks([0.0, 0.2, 0.4, 0.6])
    cbar.ax.set_yticklabels(["0%", "20%", "40%", ">60%"])
    for i in range(pivot_plot.shape[0]):
        for j in range(pivot_plot.shape[1]):
            val = pivot_plot.iat[i, j]
            label = f"{val:.0%}" if pd.notna(val) else ""
            if label:
                ax.text(
                    j,
                    i,
                    label,
                    ha="center",
                    va="center",
                    fontsize=7,
                    color="#1F2933",
                )
    ax.set_xlim(-0.5, n_cols - 0.5)
    ax.set_ylim(n_rows - 0.5, -0.5)
    ax.set_yticks(np.arange(n_rows))
    ax.set_yticklabels([DOMAIN_LEGEND_LABELS.get(label, label) for label in pivot_plot.index])
    ax.grid(False)
    ax.xaxis.grid(False)
    ax.yaxis.grid(False)
    ax.set_aspect("equal", adjustable="box")
    ax.set_title(
        "Domain × source type heatmap\n"
        f"({len(domains)} domains, normalized within source type)",
        pad=52,
    )
    ax.set_xlabel("Policy source type")
    ax.set_ylabel("Domain")
    def _wrap_source_type(label: object) -> str:
        text = _display_source_type_label(label, compact=True)
        return text if text else "Unclassified"

    labels = [_wrap_source_type(label) for label in pivot_plot.columns]
    ax.set_xticks(np.arange(len(labels)))
    ax.set_xticklabels(labels)
    ax.tick_params(axis="x", rotation=45, labelsize=9, pad=6, length=0)
    ax.tick_params(axis="y", length=0)

    # Group headers by major type (top axis) + separators.
    group_labels: list[tuple[str, float]] = []
    group_boundaries: list[int] = []
    start = 0
    for major in major_order:
        group = [s for s in source_types_ordered if source_major_map.get(s) == major]
        if not group:
            continue
        end = start + len(group)
        center = (start + end - 1) / 2
        count_all = int(major_counts.get(major, len(group)))
        count_sel = int(major_counts_selected.get(major, len(group)))
        cov = coverage_share.get(major, 0.0)
        label = f"{SOURCE_TYPE_MAJOR_LABELS.get(major, major)} ({count_sel}/{count_all}; {cov:.0%})"
        group_labels.append((label, center))
        group_boundaries.append(end)
        start = end

    # Group separators (between major types).
    for boundary in group_boundaries[:-1]:
        ax.axvline(boundary - 0.5, color="#D1D5DB", linewidth=1.2, zorder=3)

    # Column totals + group headers (axes coords so aspect doesn't shift alignment).
    col_totals = pivot_sel.sum(axis=1)
    for i, source_type in enumerate(pivot_plot.columns):
        total = float(col_totals.get(source_type, 0.0))
        ax.text(
            (i + 0.5) / max(n_cols, 1),
            1.01,
            _fmt_short(total),
            transform=ax.transAxes,
            ha="center",
            va="bottom",
            fontsize=8,
            color=REFERENCE_TEXT,
            clip_on=False,
        )

    for label, center in group_labels:
        ax.text(
            (center + 0.5) / max(n_cols, 1),
            1.07,
            label,
            transform=ax.transAxes,
            ha="center",
            va="bottom",
            fontsize=9,
            color="#374151",
            clip_on=False,
        )

    _transparent(fig, [ax])
    fig.tight_layout(pad=0.8)
    out_png = out_dir / f"{run_tag}_source_type_domain_heatmap.png"
    save_report_figure(fig, out_png, dpi=300, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)
    return out_png
