from __future__ import annotations

from pathlib import Path

import duckdb
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .common import (
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    NEUTRAL_GRAY,
    REFERENCE_LINE,
    _set_theme,
    _transparent,
    save_report_figure,
)


DOMAINS = ("Social Sciences", "Health Sciences", "Physical Sciences", "Life Sciences")


def _sql_path(path: Path) -> str:
    return path.as_posix().replace("'", "''")


def _require_paths(paths: list[Path]) -> None:
    missing = [path for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing Korea gap-decomposition inputs: " + ", ".join(map(str, missing)))


def figure_16_korea_gap_decomposition(
    *, run_tag: str, in_dir: Path, out_dir: Path
) -> tuple[Path, Path, Path, Path, Path]:
    """Explain Korea's social-science field-share gap by observed policy-source composition.

    The symmetric two-group decomposition uses four-domain citation assignments and
    separates the difference between the two citation directions into:
    (1) the think-tank/non-think-tank source-composition component and
    (2) the within-source-group field-composition component.
    It is a descriptive decomposition, not a causal estimate.
    """

    _set_theme()
    out_dir.mkdir(parents=True, exist_ok=True)

    raw_path = Path("Data/raw_df_citation_non_duplicated.parquet")
    works_path = Path("Data/matched_openalex_with_oa_country_unique.parquet")
    topics_path = Path("Data/openalex_topics.parquet")
    policy_country_path = Path("Data/overton_policy_meta/policy_source_country_clean.parquet")
    policy_type_path = Path("Data/overton_policy_meta/policy_source_type_clean.parquet")
    peer_path = out_dir / f"{run_tag}_country_domain_demand_supply_scatter.csv"
    _require_paths([raw_path, works_path, topics_path, policy_country_path, policy_type_path, peer_path])

    con = duckdb.connect()
    source_type_status = con.execute(
        f"""
        WITH policy_type AS (
          SELECT
            policy_document_id,
            COUNT(DISTINCT split_part(lower(policy_source_type), ' >', 1)) AS top_type_count
          FROM read_parquet('{_sql_path(policy_type_path)}')
          GROUP BY 1
        ), korea_policy_documents AS (
          SELECT DISTINCT policy_document_id
          FROM read_parquet('{_sql_path(policy_country_path)}')
          WHERE policy_source_country = 'South Korea'
        ), korea_authored_works AS (
          SELECT oaid_w
          FROM read_parquet('{_sql_path(works_path)}')
          WHERE first_author_country = 'KR'
        ), relevant_documents AS (
          SELECT DISTINCT c.policy_document_id
          FROM read_parquet('{_sql_path(raw_path)}') c
          JOIN korea_policy_documents k USING (policy_document_id)

          UNION

          SELECT DISTINCT c.policy_document_id
          FROM read_parquet('{_sql_path(raw_path)}') c
          JOIN korea_authored_works k USING (oaid_w)
        )
        SELECT
          COUNT(*) FILTER (WHERE p.policy_document_id IS NULL) AS missing_top_type,
          COUNT(*) FILTER (WHERE p.top_type_count <> 1) AS ambiguous_top_type
        FROM relevant_documents r
        LEFT JOIN policy_type p USING (policy_document_id)
        """
    ).fetchone()
    if source_type_status != (0, 0):
        raise ValueError(
            "Korea direction decomposition requires exactly one top-level source type "
            f"per relevant policy document; missing={source_type_status[0]}, "
            f"ambiguous={source_type_status[1]}"
        )

    flow_groups = con.execute(
        f"""
        WITH policy_type AS (
          SELECT DISTINCT
            policy_document_id,
            CASE
              WHEN split_part(lower(policy_source_type), ' >', 1) = 'think tank'
                THEN 'Think tank'
              ELSE 'Non-think tank'
            END AS source_group
          FROM read_parquet('{_sql_path(policy_type_path)}')
        ), work_domain AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('{_sql_path(topics_path)}')
          WHERE domain IN ({','.join(repr(domain) for domain in DOMAINS)})
        ), korea_policy_documents AS (
          SELECT DISTINCT policy_document_id
          FROM read_parquet('{_sql_path(policy_country_path)}')
          WHERE policy_source_country = 'South Korea'
        ), korea_authored_works AS (
          SELECT oaid_w
          FROM read_parquet('{_sql_path(works_path)}')
          WHERE first_author_country = 'KR'
        ), flow_counts AS (
          SELECT
            'Korea policy documents citing research' AS direction,
            t.source_group,
            d.domain,
            COUNT(*) AS citation_assignments
          FROM read_parquet('{_sql_path(raw_path)}') c
          JOIN korea_policy_documents k USING (policy_document_id)
          JOIN policy_type t USING (policy_document_id)
          JOIN work_domain d USING (oaid_w)
          GROUP BY 1, 2, 3

          UNION ALL

          SELECT
            'Policy documents citing Korea-authored research' AS direction,
            t.source_group,
            d.domain,
            COUNT(*) AS citation_assignments
          FROM read_parquet('{_sql_path(raw_path)}') c
          JOIN korea_authored_works k USING (oaid_w)
          JOIN policy_type t USING (policy_document_id)
          JOIN work_domain d USING (oaid_w)
          GROUP BY 1, 2, 3
        )
        SELECT
          direction,
          source_group,
          SUM(citation_assignments) AS citation_assignments,
          SUM(CASE WHEN domain = 'Social Sciences' THEN citation_assignments ELSE 0 END)
            AS social_science_assignments
        FROM flow_counts
        GROUP BY 1, 2
        ORDER BY 1, 2
        """
    ).df()

    source_citations = con.execute(
        f"""
        WITH policy_type AS (
          SELECT DISTINCT
            policy_document_id,
            split_part(lower(policy_source_type), ' >', 1) AS top_type
          FROM read_parquet('{_sql_path(policy_type_path)}')
        ), korea_policy_documents AS (
          SELECT DISTINCT policy_document_id
          FROM read_parquet('{_sql_path(policy_country_path)}')
          WHERE policy_source_country = 'South Korea'
        ), korea_authored_works AS (
          SELECT oaid_w
          FROM read_parquet('{_sql_path(works_path)}')
          WHERE first_author_country = 'KR'
        ), flow_counts AS (
          SELECT
            'Korea policy documents citing research' AS direction,
            t.top_type,
            COUNT(*) AS citations
          FROM read_parquet('{_sql_path(raw_path)}') c
          JOIN korea_policy_documents k USING (policy_document_id)
          JOIN policy_type t USING (policy_document_id)
          GROUP BY 1, 2

          UNION ALL

          SELECT
            'Policy documents citing Korea-authored research' AS direction,
            t.top_type,
            COUNT(*) AS citations
          FROM read_parquet('{_sql_path(raw_path)}') c
          JOIN korea_authored_works k USING (oaid_w)
          JOIN policy_type t USING (policy_document_id)
          GROUP BY 1, 2
        )
        SELECT
          direction,
          top_type,
          citations,
          citations / SUM(citations) OVER (PARTITION BY direction) AS citation_share
        FROM flow_counts
        ORDER BY 1, citations DESC
        """
    ).df()

    korea_sources = con.execute(
        f"""
        WITH korea_policy_documents AS (
          SELECT DISTINCT policy_document_id
          FROM read_parquet('{_sql_path(policy_country_path)}')
          WHERE policy_source_country = 'South Korea'
        ), citation_counts AS (
          SELECT policy_document_id, COUNT(*) AS citations
          FROM read_parquet('{_sql_path(raw_path)}')
          GROUP BY 1
        )
        SELECT
          regexp_replace(k.policy_document_id, '-[^-]+$', '') AS source_slug,
          COUNT(DISTINCT k.policy_document_id) AS policy_documents,
          SUM(c.citations) AS citations
        FROM korea_policy_documents k
        JOIN citation_counts c USING (policy_document_id)
        GROUP BY 1
        ORDER BY citations DESC
        """
    ).df()
    korea_source_domains = con.execute(
        f"""
        WITH korea_policy_documents AS (
          SELECT DISTINCT policy_document_id
          FROM read_parquet('{_sql_path(policy_country_path)}')
          WHERE policy_source_country = 'South Korea'
        ), work_domain AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('{_sql_path(topics_path)}')
          WHERE domain IN ({','.join(repr(domain) for domain in DOMAINS)})
        )
        SELECT
          regexp_replace(k.policy_document_id, '-[^-]+$', '') AS source_slug,
          COUNT(*) AS domain_citation_assignments,
          COUNT(*) FILTER (WHERE d.domain = 'Social Sciences') AS social_science_assignments
        FROM korea_policy_documents k
        JOIN read_parquet('{_sql_path(raw_path)}') c USING (policy_document_id)
        JOIN work_domain d USING (oaid_w)
        GROUP BY 1
        ORDER BY domain_citation_assignments DESC
        """
    ).df()
    con.close()

    flow_groups["source_weight"] = flow_groups.groupby("direction")["citation_assignments"].transform(
        lambda values: values / values.sum()
    )
    flow_groups["social_science_share"] = (
        flow_groups["social_science_assignments"] / flow_groups["citation_assignments"]
    )

    demand_label = "Korea policy documents citing research"
    supply_label = "Policy documents citing Korea-authored research"
    weight = flow_groups.pivot(index="source_group", columns="direction", values="source_weight")
    conditional = flow_groups.pivot(
        index="source_group", columns="direction", values="social_science_share"
    )
    for group in ("Think tank", "Non-think tank"):
        if group not in weight.index or group not in conditional.index:
            raise ValueError(f"Missing source group required for decomposition: {group}")

    demand_share = float((weight[demand_label] * conditional[demand_label]).sum())
    supply_share = float((weight[supply_label] * conditional[supply_label]).sum())
    total_gap = demand_share - supply_share
    composition_component = float(
        ((weight[demand_label] - weight[supply_label]) * (conditional[demand_label] + conditional[supply_label]) / 2).sum()
    )
    within_component = float(
        ((conditional[demand_label] - conditional[supply_label]) * (weight[demand_label] + weight[supply_label]) / 2).sum()
    )
    if not np.isclose(total_gap, composition_component + within_component, atol=1e-12):
        raise ValueError("Korea social-science decomposition does not sum to the observed gap")

    source_summary = source_citations.copy()
    source_summary["source_group"] = np.where(
        source_summary["top_type"].eq("think tank"), "Think tank", "Non-think tank"
    )
    source_summary = (
        source_summary.groupby(["direction", "source_group"], as_index=False)["citations"]
        .sum()
        .sort_values(["direction", "source_group"])
    )
    source_summary["citation_share"] = source_summary.groupby("direction")["citations"].transform(
        lambda values: values / values.sum()
    )

    korea_sources = korea_sources.merge(korea_source_domains, on="source_slug", how="left", validate="one_to_one")
    korea_sources["social_science_share"] = (
        korea_sources["social_science_assignments"] / korea_sources["domain_citation_assignments"]
    )
    korea_sources["citation_share"] = korea_sources["citations"] / korea_sources["citations"].sum()
    kdi_kiep_share = float(
        korea_sources.loc[korea_sources["source_slug"].isin(["kdi", "kiep"]), "citation_share"].sum()
    )
    kdi_share = float(korea_sources.loc[korea_sources["source_slug"].eq("kdi"), "citation_share"].sum())
    kiep_share = float(korea_sources.loc[korea_sources["source_slug"].eq("kiep"), "citation_share"].sum())

    decomposition = pd.DataFrame(
        [
            {
                "metric": "social_science_share_korea_policy_documents_citing_research",
                "value": demand_share,
                "unit": "share",
                "definition": "Four-domain citation assignments from Korea policy documents",
            },
            {
                "metric": "social_science_share_policy_documents_citing_korea_research",
                "value": supply_share,
                "unit": "share",
                "definition": "Four-domain citation assignments to Korea-authored research",
            },
            {
                "metric": "observed_social_science_gap",
                "value": total_gap * 100,
                "unit": "percentage_points",
                "definition": "Korea-policy-document direction minus Korea-authored-research direction",
            },
            {
                "metric": "source_group_composition_component",
                "value": composition_component * 100,
                "unit": "percentage_points",
                "definition": "Symmetric decomposition; think tank versus non-think tank source weights",
            },
            {
                "metric": "within_source_group_component",
                "value": within_component * 100,
                "unit": "percentage_points",
                "definition": "Symmetric decomposition; within-group social-science shares",
            },
            {
                "metric": "kdi_citation_share_within_korea_policy_documents",
                "value": kdi_share,
                "unit": "share",
                "definition": "DOI-linked citations from Korea policy documents",
            },
            {
                "metric": "kiep_citation_share_within_korea_policy_documents",
                "value": kiep_share,
                "unit": "share",
                "definition": "DOI-linked citations from Korea policy documents",
            },
            {
                "metric": "kdi_kiep_combined_citation_share_within_korea_policy_documents",
                "value": kdi_kiep_share,
                "unit": "share",
                "definition": "DOI-linked citations from Korea policy documents",
            },
        ]
    )

    peer = pd.read_csv(peer_path)
    peer["delta"] = peer["demand_share"] - peer["supply_share"]
    peer_gap = (
        peer.assign(abs_delta=lambda frame: frame["delta"].abs())
        .groupby("country", as_index=False)
        .agg(
            absolute_field_gap_pp=("abs_delta", lambda values: float(values.sum() * 100)),
            maximum_field_gap_pp=("abs_delta", lambda values: float(values.max() * 100)),
        )
    )
    social_delta = (
        peer.loc[peer["domain"].eq("Social Sciences"), ["country", "delta"]]
        .rename(columns={"delta": "social_science_gap"})
        .copy()
    )
    social_delta["social_science_gap_pp"] = social_delta.pop("social_science_gap") * 100
    peer_gap = peer_gap.merge(social_delta, on="country", how="left").sort_values(
        "absolute_field_gap_pp", ascending=False
    )
    peer_gap["rank_by_absolute_field_gap"] = np.arange(1, len(peer_gap) + 1)

    decomposition_path = out_dir / f"{run_tag}_korea_social_science_gap_decomposition.csv"
    source_path = out_dir / f"{run_tag}_korea_policy_source_concentration.csv"
    source_type_path = out_dir / f"{run_tag}_korea_policy_source_type_composition.csv"
    peer_gap_path = out_dir / f"{run_tag}_country_field_gap_comparison.csv"
    decomposition.to_csv(decomposition_path, index=False)
    korea_sources.to_csv(source_path, index=False)
    source_summary.to_csv(source_type_path, index=False)
    peer_gap.to_csv(peer_gap_path, index=False)

    fig, (ax0, ax1) = plt.subplots(
        1,
        2,
        figsize=(13.2, 5.7),
        gridspec_kw={"width_ratios": [1.08, 0.92]},
        constrained_layout=False,
    )

    components_pp = np.array([composition_component, within_component]) * 100
    starts = np.array([0.0, components_pp[0]])
    x = np.arange(3)
    ax0.bar(x[:2], components_pp, bottom=starts, width=0.62, color=[AUX_PRIMARY, AUX_TERTIARY])
    ax0.bar(x[2], total_gap * 100, width=0.62, color=AUX_SECONDARY)
    ax0.plot([x[0] + 0.31, x[1] - 0.31], [components_pp[0], components_pp[0]], color=REFERENCE_LINE, lw=1.2)
    ax0.plot([x[1] + 0.31, x[2] - 0.31], [total_gap * 100, total_gap * 100], color=REFERENCE_LINE, lw=1.2)
    for xpos, value, start in zip(x[:2], components_pp, starts):
        ax0.text(xpos, start + value / 2, f"+{value:.1f} pp", ha="center", va="center", color="white", fontweight="bold", fontsize=11)
    ax0.text(x[2], total_gap * 100 / 2, f"{total_gap*100:.1f} pp", ha="center", va="center", color="white", fontweight="bold", fontsize=12)
    ax0.set_xticks(x)
    ax0.set_xticklabels(
        [
            "Policy-source\ntype mix",
            "Within-source-type\nfield mix",
            "Observed\nsocial-science gap",
        ]
    )
    ax0.set_ylabel("Percentage-point difference")
    ax0.set_ylim(0, max(65, total_gap * 100 + 7))
    ax0.set_title("A. Decomposition of Korea's social-science field gap", fontsize=11.5, fontweight="bold", pad=10)
    ax0.grid(axis="x", visible=False)

    plot_order = [demand_label, supply_label]
    think_share = (
        source_summary.loc[source_summary["source_group"].eq("Think tank")]
        .set_index("direction")
        .reindex(plot_order)["citation_share"]
        .astype(float)
    )
    non_share = 1 - think_share
    y = np.arange(len(plot_order))
    ax1.barh(y, think_share.to_numpy(), color=AUX_TERTIARY, height=0.54, label="Think tank")
    ax1.barh(y, non_share.to_numpy(), left=think_share.to_numpy(), color=NEUTRAL_GRAY, height=0.54, label="Non-think tank")
    for idx, value in enumerate(think_share):
        ax1.text(value / 2, idx, f"{value:.1%}", ha="center", va="center", color="white", fontweight="bold", fontsize=10.5)
        ax1.text(value + non_share.iloc[idx] / 2, idx, f"{non_share.iloc[idx]:.1%}", ha="center", va="center", color="#405047", fontweight="bold", fontsize=10)
    ax1.set_yticks(y)
    ax1.set_yticklabels(
        [
            "Korea policy documents\nciting research",
            "Policy documents citing\nKorea-authored research",
        ]
    )
    ax1.invert_yaxis()
    ax1.set_xlim(0, 1)
    ax1.set_xlabel("Share of DOI-linked citations")
    ax1.xaxis.set_major_formatter(plt.FuncFormatter(lambda value, _pos=None: f"{value:.0%}"))
    ax1.set_title("B. Policy-source type composition differs by direction", fontsize=11.5, fontweight="bold", pad=10)
    ax1.legend(loc="lower center", bbox_to_anchor=(0.5, -0.31), ncol=2, frameon=True)
    ax1.text(
        0.02,
        0.49,
        f"KDI + KIEP: {kdi_kiep_share:.1%} of citations\nfrom Korea policy documents",
        transform=ax1.transAxes,
        ha="left",
        va="bottom",
        fontsize=9.5,
        color="#405047",
        bbox={"boxstyle": "round,pad=0.35", "facecolor": "white", "edgecolor": REFERENCE_LINE, "alpha": 0.95},
    )
    ax1.grid(axis="y", visible=False)

    fig.suptitle("Where Korea's large citation-direction difference is observed", fontsize=14, fontweight="bold", y=0.985)
    fig.text(
        0.5,
        0.012,
        "Panel A: symmetric two-group decomposition of four-domain citation assignments. "
        "Panel B: top-level policy-source type shares among DOI-linked citations. Descriptive, not causal.",
        ha="center",
        va="bottom",
        fontsize=8.5,
        color="#53635A",
    )
    fig.subplots_adjust(left=0.08, right=0.985, top=0.86, bottom=0.25, wspace=0.32)
    _transparent(fig, [ax0, ax1])

    out_png = out_dir / f"{run_tag}_korea_social_science_gap_decomposition.png"
    save_report_figure(fig, out_png, dpi=300, transparent=True, bbox_inches="tight", pad_inches=0.06)
    plt.close(fig)
    return out_png, decomposition_path, source_path, source_type_path, peer_gap_path
