from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

from .common import (
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    NEUTRAL_GRAY,
    _ellipsize,
    _fmt_short,
    _set_theme,
    _tint,
    _transparent,
    save_report_figure,
)


def figure_2_domain_top10(*, run_tag: str, in_dir: Path, out_dir: Path) -> tuple[Path, Path]:
    _doc_color, _core_primary, text_color, _cmap = _set_theme()

    df = pd.read_csv(in_dir / f"{run_tag}_domain_counts.csv")
    df["domain"] = df["domain"].fillna("Unknown").replace({"": "Unknown"})
    df = df.sort_values("citation_rows", ascending=False).head(10).copy()
    df["citation_rows"] = df["citation_rows"].astype(float)

    top_domains = [d for d in DOMAIN_ORDER if d in df["domain"].tolist()]
    if not top_domains:
        top_domains = df[df["domain"].ne("Unknown")]["domain"].head(4).tolist()

    field_cache = out_dir / f"{run_tag}_domain_field_counts.csv"
    if field_cache.exists():
        field_df = pd.read_csv(field_cache)
    else:
        import duckdb

        con = duckdb.connect()
        domain_list = ",".join([f"'{d}'" for d in top_domains])
        field_df = con.execute(
            f"""
            WITH citations AS (
              SELECT oaid_w, COUNT(*) AS cite_count
              FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet')
              WHERE oaid_w IS NOT NULL
              GROUP BY 1
            ),
            work_domain_field AS (
              SELECT DISTINCT oaid_w, domain, field
              FROM read_parquet('Data/openalex_topics.parquet')
              WHERE domain IN ({domain_list})
                AND field IS NOT NULL
                AND field != ''
            ),
            work_domain_field_nf AS (
              SELECT
                oaid_w,
                domain,
                field,
                COUNT(*) OVER (PARTITION BY oaid_w, domain) AS n_fields
              FROM work_domain_field
            )
            SELECT
              domain,
              field,
              SUM(c.cite_count / w.n_fields) AS citation_rows
            FROM citations c
            JOIN work_domain_field_nf w USING (oaid_w)
            GROUP BY 1, 2
            ORDER BY 1, citation_rows DESC
            """
        ).df()
        con.close()
        field_df.to_csv(field_cache, index=False)

    field_df = field_df.dropna(subset=["domain", "field", "citation_rows"]).copy()
    field_df["domain"] = field_df["domain"].astype(str).str.strip()
    field_df["field"] = field_df["field"].astype(str).str.strip()
    field_df = field_df[(field_df["domain"].isin(top_domains)) & (field_df["field"].ne(""))].copy()

    top_k = 3
    top_fields_by_domain: dict[str, list[str]] = {}
    for domain in top_domains:
        dom_fields = field_df[field_df["domain"] == domain].nlargest(top_k, "citation_rows")["field"].tolist()
        top_fields_by_domain[domain] = dom_fields

    domain_totals = df.set_index("domain")["citation_rows"].to_dict()

    field_totals = field_df.groupby(["domain", "field"], as_index=False)["citation_rows"].sum()
    domain_field_sum = field_totals.groupby("domain", as_index=False)["citation_rows"].sum().rename(
        columns={"citation_rows": "domain_total_raw"}
    )
    field_totals = field_totals.merge(domain_field_sum, on="domain", how="left")
    domain_total_raw_map = domain_field_sum.set_index("domain")["domain_total_raw"].to_dict()

    plot_domains = [d for d in df["domain"].tolist() if d in top_domains]
    if "Unknown" in domain_totals:
        plot_domains.append("Unknown")

    fig, ax = plt.subplots(figsize=(10.8, 5.4))
    y = np.arange(len(plot_domains))
    shade_levels = [0.0, 0.32, 0.58]
    seen_labels: set[str] = set()

    max_total = 0.0
    for domain in plot_domains:
        max_total = max(max_total, float(domain_totals.get(domain, 0.0)))
    label_offset = max_total * 0.012
    label_style = dict(fontsize=10, fontweight="bold", color=text_color)
    segment_label_style = dict(fontsize=8.5, color=text_color)
    min_segment_share = 0.05
    min_segment_share_inside = 0.08
    min_segment_share_inside_life = 0.10

    for i, domain in enumerate(plot_domains):
        total = float(domain_totals.get(domain, 0.0))
        if domain == "Unknown":
            ax.barh([i], [total], left=0, color=_tint(NEUTRAL_GRAY, 0.35), label=None)
            ax.text(
                total + label_offset,
                i,
                _fmt_short(total),
                va="center",
                ha="left",
                **label_style,
            )
            continue

        dom_fields = top_fields_by_domain.get(domain, [])
        outside_labels: list[tuple[float, str]] = []
        allow_outside = domain == "Life Sciences"
        segments: list[tuple[str, float]] = []
        for field in dom_fields:
            val = float(
                field_totals[(field_totals["domain"] == domain) & (field_totals["field"] == field)][
                    "citation_rows"
                ]
                .fillna(0)
                .sum()
            )
            segments.append((field, val))
        segments = [(f, v) for f, v in segments if v > 0]
        segments.sort(key=lambda x: x[1], reverse=True)

        used = float(sum(v for _f, v in segments))
        domain_total_raw = float(domain_total_raw_map.get(domain, 0.0))
        other_val = max(domain_total_raw - used, 0.0)
        missing_val = max(total - domain_total_raw, 0.0)
        if missing_val < 0.5:
            missing_val = 0.0

        left = 0.0
        base = DOMAIN_PALETTE.get(domain, NEUTRAL_GRAY)
        inside_threshold = min_segment_share_inside_life if allow_outside else min_segment_share_inside
        for rank, (field, val) in enumerate(segments):
            tint = shade_levels[min(rank, len(shade_levels) - 1)]
            color = _tint(base, tint)
            label = _ellipsize(field, 28) if field not in seen_labels else None
            seen_labels.add(field)
            ax.barh([i], [val], left=left, color=color, label=label)
            if total > 0 and val / total >= min_segment_share:
                if (val / total >= inside_threshold) or not allow_outside:
                    ax.text(left + val * 0.5, i, _fmt_short(val), va="center", ha="center", **segment_label_style)
                else:
                    outside_labels.append((left + val * 0.5, _fmt_short(val)))
            left += val

        label_other = "Other" if "Other" not in seen_labels else None
        seen_labels.add("Other")
        ax.barh([i], [other_val], left=left, color=NEUTRAL_GRAY, label=label_other)
        if total > 0 and other_val / total >= min_segment_share:
            if (other_val / total >= inside_threshold) or not allow_outside:
                ax.text(
                    left + other_val * 0.5,
                    i,
                    _fmt_short(other_val),
                    va="center",
                    ha="center",
                    **segment_label_style,
                )
            else:
                outside_labels.append((left + other_val * 0.5, _fmt_short(other_val)))
        left += other_val

        if missing_val > 0:
            label_missing = "Field missing" if "Field missing" not in seen_labels else None
            seen_labels.add("Field missing")
            ax.barh(
                [i],
                [missing_val],
                left=left,
                color=_tint(NEUTRAL_GRAY, 0.35),
                alpha=0.4,
                label=label_missing,
            )
            if total > 0 and missing_val / total >= min_segment_share:
                if (missing_val / total >= inside_threshold) or not allow_outside:
                    ax.text(
                        left + missing_val * 0.5,
                        i,
                        _fmt_short(missing_val),
                        va="center",
                        ha="center",
                        **segment_label_style,
                    )
                else:
                    outside_labels.append((left + missing_val * 0.5, _fmt_short(missing_val)))

        if outside_labels:
            if allow_outside:
                offsets_x = np.linspace(-18, 18, len(outside_labels))
                offsets_y = np.linspace(-12, -22, len(outside_labels))
                for (x_anchor, label_text), dx, dy in zip(outside_labels, offsets_x, offsets_y):
                    ax.annotate(
                        label_text,
                        xy=(x_anchor, i),
                        xytext=(dx, dy),
                        textcoords="offset points",
                        ha="center",
                        va="top",
                        fontsize=segment_label_style["fontsize"],
                        color=segment_label_style["color"],
                        arrowprops=dict(arrowstyle="-", color="#4B5563", lw=0.8),
                    )
            else:
                offsets = np.linspace(-0.24, 0.24, len(outside_labels))
                label_x = total + label_offset * 0.2
                for (x_anchor, label_text), dy in zip(outside_labels, offsets):
                    ax.annotate(
                        label_text,
                        xy=(x_anchor, i),
                        xytext=(label_x, i + dy),
                        textcoords="data",
                        ha="left",
                        va="center",
                        fontsize=segment_label_style["fontsize"],
                        color=segment_label_style["color"],
                        arrowprops=dict(arrowstyle="-", color="#4B5563", lw=0.8),
                    )
        ax.text(
            total + label_offset,
            i,
            _fmt_short(total),
            va="center",
            ha="left",
            **label_style,
        )

    ax.set_yticks(y, labels=plot_domains)
    ax.invert_yaxis()
    ax.yaxis.grid(False)
    ax.xaxis.grid(True)
    ax.set_title("Policy citations by domain")
    ax.set_xlabel("Citations")
    ax.set_ylabel("Domain")
    ax.xaxis.set_major_formatter(FuncFormatter(_fmt_short))
    ax.set_xlim(0, max_total * 1.12)
    from matplotlib.patches import Patch

    handles, labels = ax.get_legend_handles_labels()
    label_to_handle = {label: handle for label, handle in zip(labels, handles)}

    ncol = 3
    desired_row_major: list[str] = []
    for domain in top_domains:
        domain_labels: list[str] = []
        for field in top_fields_by_domain.get(domain, []):
            label = _ellipsize(field, 28)
            if label in label_to_handle and label not in domain_labels:
                domain_labels.append(label)
        while len(domain_labels) < ncol:
            domain_labels.append("")
        desired_row_major.extend(domain_labels[:ncol])

    extra_labels: list[str] = []
    for label in ["Other", "Field missing"]:
        if label in label_to_handle:
            extra_labels.append(label)
    if extra_labels:
        while len(extra_labels) < ncol:
            extra_labels.append("")
        desired_row_major.extend(extra_labels[:ncol])

    for label in labels:
        if label not in desired_row_major:
            desired_row_major.append(label)
    if desired_row_major and ncol > 1:
        remainder = len(desired_row_major) % ncol
        if remainder:
            desired_row_major.extend([""] * (ncol - remainder))
        n_rows = len(desired_row_major) // ncol
        order = []
        for col in range(ncol):
            for row in range(n_rows):
                order.append(row * ncol + col)
        labels = [desired_row_major[i] for i in order]
        handles = [
            (label_to_handle[label] if label else Patch(facecolor="none", edgecolor="none"))
            for label in labels
        ]
    ax.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.14),
        frameon=True,
        fancybox=True,
        framealpha=0.95,
        title="",
        ncol=ncol,
        columnspacing=1.6,
        handletextpad=0.6,
    )

    _transparent(fig, [ax])
    fig.tight_layout(pad=0.6)

    out_png = out_dir / f"{run_tag}_domain_top10.png"
    out_csv = out_dir / f"{run_tag}_domain_counts.csv"
    df.to_csv(out_csv, index=False)
    save_report_figure(fig, out_png, dpi=200, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)
    return out_png, out_csv
