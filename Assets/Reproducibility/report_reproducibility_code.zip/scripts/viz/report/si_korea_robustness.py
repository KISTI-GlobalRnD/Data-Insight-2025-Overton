from __future__ import annotations

from pathlib import Path

import duckdb
import pandas as pd


DOMAINS = ("Social Sciences", "Health Sciences", "Physical Sciences", "Life Sciences")


def _sql_path(path: Path) -> str:
    return path.as_posix().replace("'", "''")


def _require_paths(paths: list[Path]) -> None:
    missing = [path for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing Korea robustness inputs: " + ", ".join(map(str, missing)))


def write_si_korea_robustness(*, run_tag: str, out_dir: Path) -> tuple[Path, Path, Path, Path]:
    """Write audit-requested Korea weighting, missingness, and institution diagnostics.

    The report's citation-row/full-domain calculation remains the primary result.
    The alternative rows change one aggregation choice at a time and are descriptive
    sensitivity checks, not replacement estimands.
    """

    raw_path = Path("Data/raw_df_citation_non_duplicated.parquet")
    works_path = Path("Data/matched_openalex_with_oa_country_unique.parquet")
    topics_path = Path("Data/openalex_topics.parquet")
    policy_country_path = Path("Data/overton_policy_meta/policy_source_country_clean.parquet")
    institution_path = out_dir / f"{run_tag}_korea_policy_source_concentration.csv"
    _require_paths([raw_path, works_path, topics_path, policy_country_path, institution_path])
    out_dir.mkdir(parents=True, exist_ok=True)

    raw = f"read_parquet('{_sql_path(raw_path)}')"
    works = f"read_parquet('{_sql_path(works_path)}')"
    topics = f"read_parquet('{_sql_path(topics_path)}')"
    policy_country = f"read_parquet('{_sql_path(policy_country_path)}')"
    domains_sql = ",".join(repr(domain) for domain in DOMAINS)

    con = duckdb.connect()
    row_count, pair_count = con.execute(
        f"""
        SELECT
          COUNT(*),
          COUNT(DISTINCT policy_document_id || '|' || oaid_w)
        FROM {raw}
        """
    ).fetchone()
    if row_count != pair_count:
        raise ValueError(
            "Korea robustness calculations require one row per policy-document/work pair; "
            f"rows={row_count}, distinct_pairs={pair_count}"
        )

    sensitivity_long = con.execute(
        f"""
        WITH korea_docs AS (
          SELECT DISTINCT policy_document_id
          FROM {policy_country}
          WHERE policy_source_country = 'South Korea'
        ), korea_works AS (
          SELECT oaid_w
          FROM {works}
          WHERE first_author_country = 'KR'
        ), domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM {topics}
          WHERE domain IN ({domains_sql})
        ), domain_count AS (
          SELECT oaid_w, COUNT(*) AS n_domains
          FROM domains
          GROUP BY 1
        ), base AS (
          SELECT
            'korea_policy_to_research' AS direction,
            c.policy_document_id,
            c.oaid_w,
            d.domain,
            n.n_domains
          FROM {raw} c
          JOIN korea_docs k USING (policy_document_id)
          JOIN domains d USING (oaid_w)
          JOIN domain_count n USING (oaid_w)

          UNION ALL

          SELECT
            'policy_to_korea_research' AS direction,
            c.policy_document_id,
            c.oaid_w,
            d.domain,
            n.n_domains
          FROM {raw} c
          JOIN korea_works k USING (oaid_w)
          JOIN domains d USING (oaid_w)
          JOIN domain_count n USING (oaid_w)
        ), citation_full AS (
          SELECT
            direction,
            'citation_rows_full_domain' AS weighting,
            SUM(CASE WHEN domain = 'Social Sciences' THEN 1 ELSE 0 END)::DOUBLE / COUNT(*)
              AS social_share,
            COUNT(*)::DOUBLE AS denominator,
            COUNT(DISTINCT policy_document_id || '|' || oaid_w)::DOUBLE AS observation_units
          FROM base
          GROUP BY 1
        ), unique_work AS (
          SELECT
            direction,
            'unique_works_full_domain' AS weighting,
            SUM(CASE WHEN domain = 'Social Sciences' THEN 1 ELSE 0 END)::DOUBLE / COUNT(*)
              AS social_share,
            COUNT(*)::DOUBLE AS denominator,
            COUNT(DISTINCT oaid_w)::DOUBLE AS observation_units
          FROM (SELECT DISTINCT direction, oaid_w, domain FROM base)
          GROUP BY 1
        ), fractional_domain AS (
          SELECT
            direction,
            'citation_rows_fractional_domain' AS weighting,
            SUM(CASE WHEN domain = 'Social Sciences' THEN 1.0 / n_domains ELSE 0 END)
              / SUM(1.0 / n_domains) AS social_share,
            SUM(1.0 / n_domains) AS denominator,
            COUNT(DISTINCT policy_document_id || '|' || oaid_w)::DOUBLE AS observation_units
          FROM base
          GROUP BY 1
        ), document_share AS (
          SELECT
            direction,
            policy_document_id,
            SUM(CASE WHEN domain = 'Social Sciences' THEN 1 ELSE 0 END)::DOUBLE / COUNT(*)
              AS social_share
          FROM base
          GROUP BY 1, 2
        ), document_equal AS (
          SELECT
            direction,
            'policy_documents_equal_weight' AS weighting,
            AVG(social_share) AS social_share,
            COUNT(*)::DOUBLE AS denominator,
            COUNT(*)::DOUBLE AS observation_units
          FROM document_share
          GROUP BY 1
        )
        SELECT * FROM citation_full
        UNION ALL SELECT * FROM unique_work
        UNION ALL SELECT * FROM fractional_domain
        UNION ALL SELECT * FROM document_equal
        ORDER BY weighting, direction
        """
    ).df()

    definitions = {
        "citation_rows_full_domain": (
            "Primary result: each policy-document/work citation contributes once to every assigned domain"
        ),
        "unique_works_full_domain": (
            "Each distinct cited work contributes once to every assigned domain within each direction"
        ),
        "citation_rows_fractional_domain": (
            "Each citation has total weight one, divided equally across its assigned domains"
        ),
        "policy_documents_equal_weight": (
            "Mean of policy-document social-science shares among documents with at least one four-domain assignment"
        ),
    }
    denominator_units = {
        "citation_rows_full_domain": "citation-domain assignments",
        "unique_works_full_domain": "unique-work-domain assignments",
        "citation_rows_fractional_domain": "fractionally weighted citations",
        "policy_documents_equal_weight": "policy documents",
    }

    share = sensitivity_long.pivot(index="weighting", columns="direction", values="social_share")
    denominator = sensitivity_long.pivot(index="weighting", columns="direction", values="denominator")
    observations = sensitivity_long.pivot(index="weighting", columns="direction", values="observation_units")
    sensitivity = pd.DataFrame(index=share.index).reset_index()
    sensitivity["definition"] = sensitivity["weighting"].map(definitions)
    sensitivity["denominator_unit"] = sensitivity["weighting"].map(denominator_units)
    sensitivity["korea_policy_to_research_social_share"] = sensitivity["weighting"].map(
        share["korea_policy_to_research"]
    )
    sensitivity["policy_to_korea_research_social_share"] = sensitivity["weighting"].map(
        share["policy_to_korea_research"]
    )
    sensitivity["gap_pp"] = 100 * (
        sensitivity["korea_policy_to_research_social_share"]
        - sensitivity["policy_to_korea_research_social_share"]
    )
    sensitivity["korea_policy_denominator"] = sensitivity["weighting"].map(
        denominator["korea_policy_to_research"]
    )
    sensitivity["korea_research_denominator"] = sensitivity["weighting"].map(
        denominator["policy_to_korea_research"]
    )
    sensitivity["korea_policy_observation_units"] = sensitivity["weighting"].map(
        observations["korea_policy_to_research"]
    )
    sensitivity["korea_research_observation_units"] = sensitivity["weighting"].map(
        observations["policy_to_korea_research"]
    )
    weighting_order = [
        "citation_rows_full_domain",
        "unique_works_full_domain",
        "policy_documents_equal_weight",
        "citation_rows_fractional_domain",
    ]
    sensitivity["_order"] = sensitivity["weighting"].map(
        {weighting: index for index, weighting in enumerate(weighting_order)}
    )
    sensitivity = sensitivity.sort_values("_order").drop(columns="_order")

    missingness = con.execute(
        f"""
        WITH korea_docs AS (
          SELECT DISTINCT policy_document_id
          FROM {policy_country}
          WHERE policy_source_country = 'South Korea'
        ), work_country AS (
          SELECT oaid_w, NULLIF(TRIM(first_author_country), '') AS research_country
          FROM {works}
        ), domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM {topics}
          WHERE domain IN ({domains_sql})
        ), base AS (
          SELECT
            c.policy_document_id,
            c.oaid_w,
            regexp_replace(c.policy_document_id, '-[^-]+$', '') AS source_slug,
            w.research_country
          FROM {raw} c
          JOIN korea_docs k USING (policy_document_id)
          LEFT JOIN work_country w USING (oaid_w)
        ), strata AS (
          SELECT
            'overall' AS dimension,
            'All Korea policy-document citations' AS stratum,
            COUNT(*) AS citations,
            SUM(CASE WHEN research_country IS NOT NULL THEN 1 ELSE 0 END)::BIGINT AS assigned,
            SUM(CASE WHEN research_country IS NULL THEN 1 ELSE 0 END)::BIGINT AS missing
          FROM base

          UNION ALL

          SELECT
            'institution' AS dimension,
            CASE
              WHEN source_slug = 'kdi' THEN 'KDI'
              WHEN source_slug = 'kiep' THEN 'KIEP'
              ELSE 'Other institutions'
            END AS stratum,
            COUNT(*) AS citations,
            SUM(CASE WHEN research_country IS NOT NULL THEN 1 ELSE 0 END)::BIGINT AS assigned,
            SUM(CASE WHEN research_country IS NULL THEN 1 ELSE 0 END)::BIGINT AS missing
          FROM base
          GROUP BY 1, 2

          UNION ALL

          SELECT
            'domain assignments' AS dimension,
            d.domain AS stratum,
            COUNT(*) AS citations,
            SUM(CASE WHEN b.research_country IS NOT NULL THEN 1 ELSE 0 END)::BIGINT AS assigned,
            SUM(CASE WHEN b.research_country IS NULL THEN 1 ELSE 0 END)::BIGINT AS missing
          FROM base b
          JOIN domains d USING (oaid_w)
          GROUP BY 1, 2
        )
        SELECT
          dimension,
          stratum,
          citations,
          assigned,
          missing,
          missing::DOUBLE / citations AS missing_share
        FROM strata
        ORDER BY
          CASE dimension WHEN 'overall' THEN 0 WHEN 'institution' THEN 1 ELSE 2 END,
          stratum
        """
    ).df()

    bounds = con.execute(
        f"""
        WITH korea_docs AS (
          SELECT DISTINCT policy_document_id
          FROM {policy_country}
          WHERE policy_source_country = 'South Korea'
        ), work_country AS (
          SELECT oaid_w, NULLIF(TRIM(first_author_country), '') AS research_country
          FROM {works}
        ), counts AS (
          SELECT
            COUNT(*) AS total_citations,
            SUM(CASE WHEN research_country IS NOT NULL THEN 1 ELSE 0 END)::BIGINT AS assigned_citations,
            SUM(CASE WHEN research_country IS NULL THEN 1 ELSE 0 END)::BIGINT AS missing_citations,
            SUM(CASE WHEN research_country = 'US' THEN 1 ELSE 0 END)::BIGINT AS assigned_us_citations
          FROM {raw} c
          JOIN korea_docs k USING (policy_document_id)
          LEFT JOIN work_country w USING (oaid_w)
        )
        SELECT
          scenario,
          total_citations,
          assigned_citations,
          missing_citations,
          us_citations,
          denominator,
          us_citations::DOUBLE / denominator AS us_share
        FROM counts,
        LATERAL (
          VALUES
            ('assigned_country_only', assigned_us_citations, assigned_citations),
            ('all_unassigned_are_non_us', assigned_us_citations, total_citations),
            ('all_unassigned_are_us', assigned_us_citations + missing_citations, total_citations)
        ) AS scenarios(scenario, us_citations, denominator)
        ORDER BY CASE scenario
          WHEN 'assigned_country_only' THEN 0
          WHEN 'all_unassigned_are_non_us' THEN 1
          ELSE 2
        END
        """
    ).df()
    all_korea_documents = con.execute(
        f"""
        SELECT
          CASE
            WHEN regexp_replace(policy_document_id, '-[^-]+$', '') IN ('kdi', 'kiep')
              THEN 'KDI + KIEP'
            ELSE 'other_institutions'
          END AS source_group,
          COUNT(DISTINCT policy_document_id) AS all_policy_documents
        FROM {policy_country}
        WHERE policy_source_country = 'South Korea'
        GROUP BY 1
        """
    ).df()
    con.close()

    institutions = pd.read_csv(institution_path)
    institutions["source_group"] = institutions["source_slug"].where(
        institutions["source_slug"].isin(["kdi", "kiep"]), "other_institutions"
    )
    institutions.loc[institutions["source_slug"].isin(["kdi", "kiep"]), "source_group"] = (
        "KDI + KIEP"
    )
    institution_summary = (
        institutions.groupby("source_group", as_index=False)[["policy_documents", "citations"]]
        .sum()
        .sort_values("citations", ascending=False)
    )
    institution_summary = institution_summary.rename(
        columns={"policy_documents": "doi_citing_policy_documents"}
    ).merge(all_korea_documents, on="source_group", how="left", validate="one_to_one")
    total_all_documents = float(institution_summary["all_policy_documents"].sum())
    total_citing_documents = float(institution_summary["doi_citing_policy_documents"].sum())
    total_citations = float(institution_summary["citations"].sum())
    institution_summary["share_of_all_policy_documents"] = (
        institution_summary["all_policy_documents"] / total_all_documents
    )
    institution_summary["share_of_doi_citing_policy_documents"] = (
        institution_summary["doi_citing_policy_documents"] / total_citing_documents
    )
    institution_summary["citation_share"] = institution_summary["citations"] / total_citations
    institution_summary["citations_per_doi_citing_policy_document"] = (
        institution_summary["citations"] / institution_summary["doi_citing_policy_documents"]
    )

    sensitivity_path = out_dir / f"{run_tag}_korea_field_gap_weighting_sensitivity.csv"
    missingness_path = out_dir / f"{run_tag}_korea_research_country_missingness.csv"
    bounds_path = out_dir / f"{run_tag}_korea_us_share_missingness_bounds.csv"
    institution_summary_path = out_dir / f"{run_tag}_korea_institution_concentration_summary.csv"
    sensitivity.to_csv(sensitivity_path, index=False)
    missingness.to_csv(missingness_path, index=False)
    bounds.to_csv(bounds_path, index=False)
    institution_summary.to_csv(institution_summary_path, index=False)
    return sensitivity_path, missingness_path, bounds_path, institution_summary_path
