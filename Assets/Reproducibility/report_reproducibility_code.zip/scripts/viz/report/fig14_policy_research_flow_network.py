from __future__ import annotations

from pathlib import Path

import random

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.ticker import FuncFormatter, PercentFormatter

from .common import (
    AUX_CATEG,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    AUX_HIGHLIGHT,
    CORE_CATEG,
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    DOMAIN_LEGEND_LABELS,
    KOREA_DISPLAY_LABEL,
    KOREA_LABEL_ALIASES,
    NEUTRAL_GRAY,
    REFERENCE_LINE,
    SOURCE_TYPE_MAJOR_COLORS,
    _add_edge_connectors,
    _adjust_text_with_keepout,
    _annotate_stacked_barh_percent,
    _ccdf_from_counts,
    _contrast_text_color,
    _display_country_label,
    _ellipsize,
    _fmt_short,
    _iso2_to_label,
    _make_domain_palette,
    _openalex_output_shares_by_country_domain,
    _policy_country_label,
    _policy_to_iso2,
    _row_normalize,
    _set_theme,
    _sql_quote,
    _stacked_barh_percent,
    _stacked_barh_percent_grouped,
    _tint,
    _transparent,
    save_report_figure,
)

def figure_14_policy_research_flow_network(
    *, run_tag: str, in_dir: Path, out_dir: Path, node_count: int = 50, layout_seed: int = 2026
) -> tuple[Path, Path]:
    _doc_color, core_primary, text_color, _cmap = _set_theme()

    random.seed(layout_seed)
    np.random.seed(layout_seed)

    mat = pd.read_csv(
        in_dir / f"{run_tag}_policy_country_research_country.csv",
        keep_default_na=False,
    )
    mat = mat.dropna(subset=["policy_country", "research_country", "citation_rows"]).copy()
    mat = mat[mat["citation_rows"] > 0].copy()

    iso2_to_label = _iso2_to_label()
    mat["policy_country_label"] = mat["policy_country"].map(_policy_country_label)
    mat["policy_country_label"] = mat["policy_country_label"].apply(
        lambda v: _display_country_label(v) if pd.notna(v) else v
    )
    mat["research_country_label"] = (
        mat["research_country"]
        .map(iso2_to_label)
        .fillna(mat["research_country"].astype(str))
        .apply(_display_country_label)
    )
    mat = mat.dropna(subset=["policy_country_label"]).copy()
    mat = mat[mat["policy_country_label"].ne("") & mat["policy_country_label"].ne("Unknown")].copy()
    mat = mat[mat["research_country_label"].ne("") & mat["research_country_label"].ne("Unknown")].copy()

    korea_label = KOREA_DISPLAY_LABEL
    top_k = 3
    label_overrides = {
        KOREA_DISPLAY_LABEL: "Republic\nof Korea",
        "EU": "EU",
        "IGO": "IGO",
    }

    flows = mat.rename(
        columns={
            "research_country_label": "exporter",
            "policy_country_label": "importer",
            "citation_rows": "weight",
        }
    )[["exporter", "importer", "weight"]].copy()
    flows = flows[flows["exporter"].ne(flows["importer"])].copy()
    if flows.empty:
        raise ValueError("No cross-entity flows found after removing self-links.")

    out_sum = flows.groupby("exporter", as_index=True)["weight"].sum()
    in_sum = flows.groupby("importer", as_index=True)["weight"].sum()
    node_total_all = out_sum.add(in_sum, fill_value=0).sort_values(ascending=False)

    nodes = node_total_all.head(max(1, node_count)).index.tolist()
    if korea_label in node_total_all.index and korea_label not in nodes:
        nodes.append(korea_label)

    flows = flows[flows["exporter"].isin(nodes) & flows["importer"].isin(nodes)].copy()
    if flows.empty:
        raise ValueError("No flows remaining after filtering to selected nodes.")

    # Node size should reflect "total flow" in the induced subgraph of selected nodes.
    # This is computed *before* top-k edge pruning so that node size is not an artifact
    # of the visualization filtering step.
    node_tot_out_full = flows.groupby("exporter", as_index=True)["weight"].sum()
    node_tot_in_full = flows.groupby("importer", as_index=True)["weight"].sum()
    node_total_full = node_tot_out_full.add(node_tot_in_full, fill_value=0).reindex(nodes).fillna(0)

    exporters_full = set(flows["exporter"].astype(str).tolist())
    importers_full = set(flows["importer"].astype(str).tolist())

    top_exports = flows.sort_values("weight", ascending=False).groupby("exporter", as_index=False).head(top_k)
    top_imports = flows.sort_values("weight", ascending=False).groupby("importer", as_index=False).head(top_k)
    edges = pd.concat([top_exports, top_imports], ignore_index=True).drop_duplicates(subset=["exporter", "importer"])
    if edges.empty:
        raise ValueError("No flows found after top-k filtering.")

    exporters = set(edges["exporter"].astype(str).tolist())
    importers = set(edges["importer"].astype(str).tolist())
    nodes = sorted(set(nodes).intersection(exporters.union(importers)))

    node_total = node_total_full.reindex(nodes).fillna(0)
    nodes_sorted = node_total.sort_values(ascending=False).index.tolist()

    vol = node_total.clip(lower=1).astype(float)
    vol_log = np.log10(vol)
    if vol_log.nunique() > 1:
        vol_norm = (vol_log - vol_log.min()) / (vol_log.max() - vol_log.min())
        node_sizes = 90 + vol_norm * 430
    else:
        node_sizes = pd.Series([240.0] * len(nodes_sorted), index=nodes_sorted)

    both_color = AUX_PRIMARY
    policy_only_color = AUX_SECONDARY
    research_only_color = AUX_TERTIARY
    korea_color = AUX_HIGHLIGHT

    node_colors: dict[str, str] = {}
    for node in nodes_sorted:
        if node == korea_label:
            node_colors[node] = korea_color
            continue
        is_policy = node in importers_full
        is_research = node in exporters_full
        if is_policy and is_research:
            node_colors[node] = both_color
        elif is_policy:
            node_colors[node] = policy_only_color
        elif is_research:
            node_colors[node] = research_only_color
        else:
            node_colors[node] = both_color

    max_w = float(edges["weight"].max()) if not edges.empty else 1.0

    def _edge_lw(w: float) -> float:
        if max_w <= 0:
            return 1.0
        w_norm = (float(w) / float(max_w)) ** 0.55
        return 0.6 + 6.0 * w_norm

    def _normalize_positions(pos: np.ndarray) -> np.ndarray:
        pos = pos.astype(float, copy=True)
        pos -= pos.mean(axis=0, keepdims=True)
        max_abs = float(np.max(np.abs(pos))) if pos.size else 1.0
        if max_abs > 0:
            pos /= max_abs
        return pos

    def _igraph_positions_drl(edges_df: pd.DataFrame, nodes_order: list[str]) -> dict[str, tuple[float, float]]:
        import igraph as ig  # type: ignore

        idx = {node: i for i, node in enumerate(nodes_order)}
        pair_weight: dict[tuple[int, int], float] = {}
        for row in edges_df.itertuples(index=False):
            u = idx.get(str(row.exporter))
            v = idx.get(str(row.importer))
            if u is None or v is None or u == v:
                continue
            a, b = (u, v) if u < v else (v, u)
            pair_weight[(a, b)] = pair_weight.get((a, b), 0.0) + float(row.weight)

        g = ig.Graph(n=len(nodes_order), directed=False)
        g.vs["name"] = nodes_order
        if pair_weight:
            edge_list = list(pair_weight.keys())
            weights = [float(np.log1p(pair_weight[e])) for e in edge_list]
            g.add_edges(edge_list)
            g.es["weight"] = weights

        n = len(nodes_order)
        angles = np.linspace(0.0, 2 * np.pi, num=n, endpoint=False)
        seed = np.column_stack([np.cos(angles), np.sin(angles)]).tolist()
        coords = np.asarray(g.layout_drl(weights="weight", seed=seed, options="default").coords, dtype=float)
        coords = _normalize_positions(coords)
        return {nodes_order[i]: (float(coords[i, 0]), float(coords[i, 1])) for i in range(n)}

    def _adjacency_matrix(edges_df: pd.DataFrame, nodes_order: list[str]) -> tuple[np.ndarray, dict[str, int]]:
        n = len(nodes_order)
        idx = {node: i for i, node in enumerate(nodes_order)}
        a = np.zeros((n, n), dtype=float)
        for row in edges_df.itertuples(index=False):
            u = idx.get(str(row.exporter))
            v = idx.get(str(row.importer))
            if u is None or v is None or u == v:
                continue
            w = float(np.log1p(float(row.weight)))
            a[u, v] += w
            a[v, u] += w
        np.fill_diagonal(a, 0.0)
        return a, idx

    def _forceatlas2_positions(
        edges_df: pd.DataFrame, nodes_order: list[str], *, seed_pos: dict[str, tuple[float, float]] | None = None
    ) -> dict[str, tuple[float, float]]:
        import forceatlas2  # type: ignore

        a, idx = _adjacency_matrix(edges_df, nodes_order)
        init = None
        if seed_pos is not None:
            init = np.asarray([seed_pos[n] for n in nodes_order], dtype=float)
        coords = forceatlas2.forceatlas2(
            a,
            pos=init,
            niter=450,
            edgeWeightInfluence=1.0,
            jitterTolerance=1.0,
            scalingRatio=2.8,
            gravity=1.0,
            strongGravityMode=True,
        )
        coords = _normalize_positions(np.asarray(coords, dtype=float))
        return {node: (float(coords[idx[node], 0]), float(coords[idx[node], 1])) for node in nodes_order}

    def _circle_positions(nodes_order: list[str]) -> dict[str, tuple[float, float]]:
        n = len(nodes_order)
        angles = np.linspace(np.pi / 2, np.pi / 2 + 2 * np.pi, num=n, endpoint=False)
        return {node: (float(np.cos(a)), float(np.sin(a))) for node, a in zip(nodes_order, angles)}

    positions_circle = _circle_positions(nodes_sorted)
    positions_drl = _igraph_positions_drl(edges, nodes_sorted)
    positions_fa2 = _forceatlas2_positions(edges, nodes_sorted, seed_pos=positions_drl)

    from matplotlib.lines import Line2D
    from matplotlib.patches import FancyArrowPatch, Patch

    def _size_for_total(v: float) -> float:
        v = float(max(v, 1.0))
        v_log = float(np.log10(v))
        if vol_log.nunique() <= 1:
            return 240.0
        v_norm = (v_log - float(vol_log.min())) / (float(vol_log.max()) - float(vol_log.min()))
        return 90.0 + float(np.clip(v_norm, 0.0, 1.0)) * 430.0

    size_values = np.quantile(vol.to_numpy(dtype=float), [0.25, 0.5, 0.75]).astype(float).tolist() if len(vol) else []
    size_values = sorted({float(v) for v in size_values if v > 0})
    if len(size_values) < 3 and len(vol):
        size_values = np.quantile(vol.to_numpy(dtype=float), [0.1, 0.5, 0.9]).astype(float).tolist()
        size_values = sorted({float(v) for v in size_values if v > 0})
    if len(size_values) > 3:
        size_values = [size_values[0], size_values[len(size_values) // 2], size_values[-1]]

    color_legend_handles = [
        Patch(facecolor=both_color, label="Policy source & research country", alpha=0.9),
        Patch(facecolor=policy_only_color, label="Policy source only", alpha=0.9),
        Patch(facecolor=research_only_color, label="Research country only", alpha=0.9),
        Patch(facecolor=korea_color, label="Republic of Korea (highlight)", alpha=0.9),
    ]
    size_legend_handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            color="w",
            markerfacecolor=NEUTRAL_GRAY,
            markersize=np.sqrt(_size_for_total(v)),
            alpha=0.7,
            label=_fmt_short(v),
        )
        for v in size_values
    ]

    def _draw(pos: dict[str, tuple[float, float]], *, out_path: Path, title: str) -> None:
        fig, ax = plt.subplots(figsize=(10.8, 7.6))
        ax.axis("off")

        coords = np.array([pos[n] for n in nodes_sorted if n in pos], dtype=float)
        if coords.size:
            x_min, y_min = coords.min(axis=0)
            x_max, y_max = coords.max(axis=0)
        else:
            x_min = y_min = -1.0
            x_max = y_max = 1.0
        pad = 0.35
        pad_left = pad + 0.60
        ax.set_xlim(float(x_min - pad_left), float(x_max + pad))
        ax.set_ylim(float(y_min - pad), float(y_max + pad))

        edges_draw = edges.copy()
        edges_draw["is_korea"] = edges_draw["exporter"].eq(korea_label) | edges_draw["importer"].eq(korea_label)
        edges_draw = edges_draw.sort_values(["is_korea", "weight"], ascending=[True, True])
        for row in edges_draw.itertuples(index=False):
            src = str(row.exporter)
            dst = str(row.importer)
            if src not in pos or dst not in pos:
                continue
            x0, y0 = pos[src]
            x1, y1 = pos[dst]
            w = float(row.weight)
            is_korea = bool(row.is_korea)
            ax.add_patch(
                FancyArrowPatch(
                    (x0, y0),
                    (x1, y1),
                    arrowstyle="-|>",
                    mutation_scale=9,
                    shrinkA=14,
                    shrinkB=14,
                    linewidth=_edge_lw(w),
                    color=korea_color if is_korea else both_color,
                    alpha=0.40 if is_korea else 0.12,
                    connectionstyle="arc3,rad=0.12",
                    zorder=2 if is_korea else 1,
                )
            )

        for node in nodes_sorted:
            if node not in pos:
                continue
            x, y = pos[node]
            size = float(node_sizes.get(node, 240.0))
            ax.scatter(
                [x],
                [y],
                s=size,
                color=node_colors.get(node, both_color),
                edgecolor="white",
                linewidth=0.9,
                zorder=3,
            )

        points: list[tuple[float, float]] = []
        sizes: list[float] = []
        texts: list[plt.Text] = []
        fs = 10 if len(nodes_sorted) <= 25 else 8
        for node in nodes_sorted:
            if node not in pos:
                continue
            x, y = pos[node]
            points.append((x, y))
            sizes.append(float(node_sizes.get(node, 240.0)))
            label = label_overrides.get(node, node)
            texts.append(
                ax.text(
                    x,
                    y,
                    label,
                    ha="center",
                    va="center",
                    fontsize=fs,
                    color=text_color,
                    alpha=0.92,
                    zorder=6,
                )
            )

        adjusted = _adjust_text_with_keepout(ax, texts, points, sizes=sizes, min_len_px=8)
        if adjusted:
            _add_edge_connectors(ax, texts, points, sizes=sizes, lw=0.7, color=REFERENCE_LINE, alpha=0.55)
        else:
            for text, (x, y), s in zip(texts, points, sizes):
                ang = float(np.arctan2(y, x)) if (x != 0 or y != 0) else 0.0
                dx = 0.08 * np.cos(ang)
                dy = 0.08 * np.sin(ang)
                text.set_position((x + dx, y + dy))
                text.set_ha("left" if np.cos(ang) >= 0 else "right")

        ax.text(
            0.985,
            0.02,
            "Node size = total citation count before top-link filtering.\n"
            "Arrows run from cited research countries to citing policy sources,\n"
            "links keep the top 3 research countries per policy source and\n"
            "the top 3 policy sources per research country,\n"
            "and node types reflect roles in the selected 50-node graph.",
            transform=ax.transAxes,
            ha="right",
            va="bottom",
            fontsize=10,
            color=text_color,
            alpha=0.9,
            zorder=6,
        )
        ax.set_title(title, fontsize=14, pad=8)

        leg1 = ax.legend(
            handles=color_legend_handles,
            title="Node type",
            loc="upper left",
            bbox_to_anchor=(0.02, 0.82),
            frameon=True,
            fancybox=True,
            framealpha=0.95,
        )
        leg1.set_zorder(20)
        ax.add_artist(leg1)
        if size_legend_handles:
            leg2 = ax.legend(
                handles=size_legend_handles,
                title="Total citation count (selected nodes)",
                loc="lower left",
                frameon=True,
                fancybox=True,
                framealpha=0.95,
            )
            leg2.set_zorder(20)

        _transparent(fig, [ax])
        fig.tight_layout(pad=0.6)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        save_report_figure(fig, out_path, dpi=300, transparent=True, bbox_inches="tight", pad_inches=0.04)
        plt.close(fig)

    title = "Policy source and research country citation network"
    out_circle = out_dir / f"{run_tag}_policy_research_flow_network.png"
    out_drl = out_dir / f"{run_tag}_policy_research_flow_network_drl.png"
    out_fa2 = out_dir / f"{run_tag}_policy_research_flow_network_fa2.png"
    out_csv = out_dir / f"{run_tag}_policy_research_flow_network_edges.csv"
    edges.to_csv(out_csv, index=False)

    _draw(positions_circle, out_path=out_circle, title=title)
    _draw(positions_drl, out_path=out_drl, title=title)
    _draw(positions_fa2, out_path=out_fa2, title=title)

    return out_drl, out_csv
