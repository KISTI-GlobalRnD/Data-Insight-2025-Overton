from __future__ import annotations

from pathlib import Path

import duckdb
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .common import (
    AUX_PRIMARY,
    AUX_TERTIARY,
    NEUTRAL_GRAY,
    REFERENCE_LINE,
    _set_theme,
    _transparent,
    save_report_figure,
)


DOMAINS = ("Social Sciences", "Health Sciences", "Physical Sciences", "Life Sciences")
MIN_TOPIC_ASSIGNMENTS = 500
TOP_MATCHES = 25


def _sql_path(path: Path) -> str:
    return path.as_posix().replace("'", "''")


def _sql_values(values: list[str]) -> str:
    return ",".join("'" + value.replace("'", "''") + "'" for value in values)


def _require_paths(paths: list[Path]) -> None:
    missing = [path for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing KDI/KIEP peer-institution inputs: " + ", ".join(map(str, missing)))


def figure_17_kdi_kiep_peer_institutions(
    *, run_tag: str, in_dir: Path, out_dir: Path
) -> tuple[Path, Path, Path, Path, Path]:
    """Compare Korea's policy-source composition with foreign think tanks.

    The outcome-independent comparison set includes all non-Korean sources tagged as
    think tanks in Overton with at least 500 cited-topic assignments. Separately, the
    same candidates are ranked by the equally weighted mean of their cosine similarities
    to the KDI and KIEP cited-topic profiles. Neither set is a legal or organizational
    role crosswalk.
    """

    _set_theme()
    out_dir.mkdir(parents=True, exist_ok=True)

    raw_path = Path("Data/raw_df_citation_non_duplicated.parquet")
    topics_path = Path("Data/openalex_topics.parquet")
    policy_country_path = Path("Data/overton_policy_meta/policy_source_country_clean.parquet")
    policy_type_path = Path("Data/overton_policy_meta/policy_source_type_clean.parquet")
    peer_path = out_dir / f"{run_tag}_country_domain_demand_supply_scatter.csv"
    _require_paths([raw_path, topics_path, policy_country_path, policy_type_path, peer_path])

    peer_rows = pd.read_csv(peer_path)
    peer_countries = peer_rows["country"].drop_duplicates().tolist()
    source_country_by_display = {
        country: ("South Korea" if country == "Republic of Korea" else country)
        for country in peer_countries
    }
    source_countries = list(source_country_by_display.values())
    selected_country_values = ",".join(
        "('" + country.replace("'", "''") + "')" for country in source_countries
    )

    con = duckdb.connect()
    country_metrics = con.execute(
        f"""
        WITH selected_countries(country) AS (
          VALUES {selected_country_values}
        ), document_country AS (
          SELECT
            policy_document_id,
            CASE
              WHEN COUNT(DISTINCT policy_source_country) = 1 THEN MIN(policy_source_country)
            END AS country
          FROM read_parquet('{_sql_path(policy_country_path)}')
          GROUP BY 1
        ), document_type AS (
          SELECT
            policy_document_id,
            BOOL_OR(split_part(lower(policy_source_type), ' >', 1) = 'think tank') AS is_think_tank
          FROM read_parquet('{_sql_path(policy_type_path)}')
          GROUP BY 1
        ), document_citations AS (
          SELECT policy_document_id, COUNT(*) AS citations
          FROM read_parquet('{_sql_path(raw_path)}')
          GROUP BY 1
        ), institution_counts AS (
          SELECT
            c.country,
            regexp_replace(d.policy_document_id, '-[^-]+$', '') AS institution,
            t.is_think_tank,
            COUNT(DISTINCT d.policy_document_id) AS policy_documents,
            SUM(d.citations) AS citations
          FROM document_citations d
          JOIN document_country c USING (policy_document_id)
          JOIN document_type t USING (policy_document_id)
          JOIN selected_countries s USING (country)
          GROUP BY 1, 2, 3
        ), country_totals AS (
          SELECT country, SUM(citations) AS total_citations
          FROM institution_counts
          GROUP BY 1
        ), think_tank_rank AS (
          SELECT
            country,
            institution,
            policy_documents,
            citations,
            ROW_NUMBER() OVER (PARTITION BY country ORDER BY citations DESC, institution) AS institution_rank
          FROM institution_counts
          WHERE is_think_tank
        )
        SELECT
          c.country,
          c.total_citations,
          COUNT(*) AS think_tank_institutions,
          SUM(t.policy_documents) AS think_tank_policy_documents,
          SUM(t.citations) AS think_tank_citations,
          SUM(t.citations) / c.total_citations AS think_tank_citation_share,
          MAX(t.citations) / SUM(t.citations) AS top1_share_within_think_tanks,
          SUM(t.citations) FILTER (WHERE t.institution_rank <= 2) / SUM(t.citations)
            AS top2_share_within_think_tanks,
          STRING_AGG(t.institution, ', ' ORDER BY t.citations DESC, t.institution)
            FILTER (WHERE t.institution_rank <= 2) AS top2_institutions
        FROM country_totals c
        JOIN think_tank_rank t USING (country)
        GROUP BY 1, 2
        ORDER BY think_tank_citation_share DESC
        """
    ).df()

    topic_similarity = con.execute(
        f"""
        WITH document_country AS (
          SELECT
            policy_document_id,
            CASE
              WHEN COUNT(DISTINCT policy_source_country) = 1 THEN MIN(policy_source_country)
            END AS country
          FROM read_parquet('{_sql_path(policy_country_path)}')
          GROUP BY 1
        ), think_tank_documents AS (
          SELECT policy_document_id
          FROM read_parquet('{_sql_path(policy_type_path)}')
          GROUP BY 1
          HAVING BOOL_OR(split_part(lower(policy_source_type), ' >', 1) = 'think tank')
        ), topic_map AS (
          SELECT DISTINCT oaid_w, topic
          FROM read_parquet('{_sql_path(topics_path)}')
        ), institution_topic AS (
          SELECT
            regexp_replace(c.policy_document_id, '-[^-]+$', '') AS institution,
            d.country,
            t.topic,
            COUNT(*) AS topic_assignments
          FROM read_parquet('{_sql_path(raw_path)}') c
          JOIN think_tank_documents k USING (policy_document_id)
          JOIN document_country d USING (policy_document_id)
          JOIN topic_map t USING (oaid_w)
          WHERE d.country IS NOT NULL
          GROUP BY 1, 2, 3
        ), institution_norm AS (
          SELECT
            institution,
            country,
            SUM(topic_assignments) AS topic_assignments,
            SQRT(SUM(topic_assignments * topic_assignments)) AS topic_norm
          FROM institution_topic
          GROUP BY 1, 2
        ), target_topic AS (
          SELECT institution AS target_institution, topic, topic_assignments
          FROM institution_topic
          WHERE institution IN ('kdi', 'kiep')
        ), target_norm AS (
          SELECT
            institution AS target_institution,
            SQRT(SUM(topic_assignments * topic_assignments)) AS topic_norm
          FROM institution_topic
          WHERE institution IN ('kdi', 'kiep')
          GROUP BY 1
        ), similarity_by_target AS (
          SELECT
            i.institution,
            i.country,
            t.target_institution,
            SUM(i.topic_assignments * t.topic_assignments) / (n.topic_norm * q.topic_norm)
              AS cosine_similarity,
            n.topic_assignments
          FROM institution_topic i
          JOIN target_topic t USING (topic)
          JOIN institution_norm n USING (institution, country)
          JOIN target_norm q USING (target_institution)
          WHERE i.country <> 'South Korea'
            AND n.topic_assignments >= {MIN_TOPIC_ASSIGNMENTS}
          GROUP BY 1, 2, 3, 5, n.topic_norm, q.topic_norm
        ), mean_similarity AS (
          SELECT
            institution,
            country,
            MAX(topic_assignments) AS topic_assignments,
            MAX(cosine_similarity) FILTER (WHERE target_institution = 'kdi') AS similarity_to_kdi,
            MAX(cosine_similarity) FILTER (WHERE target_institution = 'kiep') AS similarity_to_kiep,
            AVG(cosine_similarity) AS mean_similarity
          FROM similarity_by_target
          GROUP BY 1, 2
          HAVING COUNT(*) = 2
        )
        SELECT
          *,
          ROW_NUMBER() OVER (ORDER BY mean_similarity DESC, institution) AS similarity_rank
        FROM mean_similarity
        ORDER BY similarity_rank
        """
    ).df()

    profile_institutions = ["kdi", "kiep"] + topic_similarity["institution"].tolist()
    domain_profiles = con.execute(
        f"""
        WITH document_country AS (
          SELECT
            policy_document_id,
            CASE
              WHEN COUNT(DISTINCT policy_source_country) = 1 THEN MIN(policy_source_country)
            END AS country
          FROM read_parquet('{_sql_path(policy_country_path)}')
          GROUP BY 1
        ), think_tank_documents AS (
          SELECT policy_document_id
          FROM read_parquet('{_sql_path(policy_type_path)}')
          GROUP BY 1
          HAVING BOOL_OR(split_part(lower(policy_source_type), ' >', 1) = 'think tank')
        ), domain_map AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('{_sql_path(topics_path)}')
          WHERE domain IN ({_sql_values(list(DOMAINS))})
        ), assignments AS (
          SELECT
            regexp_replace(c.policy_document_id, '-[^-]+$', '') AS institution,
            d.country,
            m.domain,
            COUNT(*) AS domain_citation_assignments
          FROM read_parquet('{_sql_path(raw_path)}') c
          JOIN think_tank_documents k USING (policy_document_id)
          JOIN document_country d USING (policy_document_id)
          JOIN domain_map m USING (oaid_w)
          WHERE regexp_replace(c.policy_document_id, '-[^-]+$', '')
            IN ({_sql_values(profile_institutions)})
          GROUP BY 1, 2, 3
        )
        SELECT
          institution,
          country,
          domain,
          domain_citation_assignments,
          domain_citation_assignments / SUM(domain_citation_assignments)
            OVER (PARTITION BY institution, country) AS domain_share
        FROM assignments
        ORDER BY institution, domain
        """
    ).df()
    con.close()

    display_country_by_source = {value: key for key, value in source_country_by_display.items()}
    country_metrics["display_country"] = country_metrics["country"].map(display_country_by_source)
    if country_metrics["display_country"].isna().any() or len(country_metrics) != len(peer_countries):
        raise ValueError("Country think-tank metrics do not cover the 11 report comparison countries")

    domain_wide = domain_profiles.pivot_table(
        index=["institution", "country"], columns="domain", values="domain_share", fill_value=0
    ).reset_index()
    for domain in DOMAINS:
        if domain not in domain_wide:
            domain_wide[domain] = 0.0

    eligible_foreign = topic_similarity.merge(
        domain_wide, on=["institution", "country"], how="left", validate="one_to_one"
    )
    peer_institutions = eligible_foreign.loc[
        eligible_foreign["similarity_rank"].le(TOP_MATCHES)
    ].copy()
    targets = domain_wide.loc[domain_wide["institution"].isin(["kdi", "kiep"])].copy()
    if (
        set(targets["institution"]) != {"kdi", "kiep"}
        or len(peer_institutions) != TOP_MATCHES
        or eligible_foreign.empty
    ):
        raise ValueError("KDI/KIEP target or foreign think-tank profile is incomplete")

    korea = country_metrics.loc[country_metrics["display_country"].eq("Republic of Korea")].iloc[0]
    kdi_social = float(targets.loc[targets["institution"].eq("kdi"), "Social Sciences"].iloc[0])
    kiep_social = float(targets.loc[targets["institution"].eq("kiep"), "Social Sciences"].iloc[0])
    eligible_social = eligible_foreign["Social Sciences"].astype(float)
    peer_social = peer_institutions["Social Sciences"].astype(float)
    summary = pd.DataFrame(
        [
            ("korea_think_tank_citation_share", float(korea["think_tank_citation_share"]), "share"),
            ("korea_top2_share_within_think_tanks", float(korea["top2_share_within_think_tanks"]), "share"),
            ("foreign_eligible_think_tank_count", float(len(eligible_foreign)), "institutions"),
            ("foreign_eligible_think_tank_country_count", float(eligible_foreign["country"].nunique()), "countries"),
            ("foreign_eligible_social_science_median", float(eligible_social.median()), "share"),
            ("foreign_eligible_social_science_min", float(eligible_social.min()), "share"),
            ("foreign_eligible_social_science_max", float(eligible_social.max()), "share"),
            ("foreign_profile_match_count", float(len(peer_institutions)), "institutions"),
            ("foreign_profile_match_country_count", float(peer_institutions["country"].nunique()), "countries"),
            ("foreign_profile_match_social_science_median", float(peer_social.median()), "share"),
            ("foreign_profile_match_social_science_min", float(peer_social.min()), "share"),
            ("foreign_profile_match_social_science_max", float(peer_social.max()), "share"),
            ("foreign_profile_match_similarity_min", float(peer_institutions["mean_similarity"].min()), "cosine"),
            ("foreign_profile_match_similarity_max", float(peer_institutions["mean_similarity"].max()), "cosine"),
            ("kdi_social_science_share", kdi_social, "share"),
            ("kiep_social_science_share", kiep_social, "share"),
        ],
        columns=["metric", "value", "unit"],
    )
    summary["definition"] = [
        "Share of DOI-linked citations from South Korea policy documents tagged as think tanks",
        "KDI and KIEP share among DOI-linked citations from South Korea think-tank policy documents",
        "All non-Korean Overton think-tank sources with at least 500 cited-topic assignments",
        "Distinct source countries among all eligible foreign think tanks",
        "Median social-science share among all eligible foreign think tanks",
        "Minimum social-science share among all eligible foreign think tanks",
        "Maximum social-science share among all eligible foreign think tanks",
        "Top foreign think tanks by equally weighted KDI/KIEP cited-topic cosine similarity",
        "Distinct source countries among the top foreign citation-profile matches",
        "Median social-science share among top foreign citation-profile matches",
        "Minimum social-science share among top foreign citation-profile matches",
        "Maximum social-science share among top foreign citation-profile matches",
        "Minimum mean KDI/KIEP topic-profile cosine similarity among selected matches",
        "Maximum mean KDI/KIEP topic-profile cosine similarity among selected matches",
        "Social-science share of four-domain citation assignments from KDI policy documents",
        "Social-science share of four-domain citation assignments from KIEP policy documents",
    ]

    country_path = out_dir / f"{run_tag}_country_think_tank_concentration.csv"
    peer_path_out = out_dir / f"{run_tag}_kdi_kiep_topic_similar_think_tanks.csv"
    eligible_path = out_dir / f"{run_tag}_foreign_think_tank_field_distribution.csv"
    summary_path = out_dir / f"{run_tag}_kdi_kiep_peer_institution_summary.csv"
    country_metrics.to_csv(country_path, index=False)
    peer_institutions.to_csv(peer_path_out, index=False)
    eligible_foreign.to_csv(eligible_path, index=False)
    summary.to_csv(summary_path, index=False)

    fig, (ax0, ax1) = plt.subplots(1, 2, figsize=(13.2, 6.2), gridspec_kw={"width_ratios": [1.16, 0.94]})

    panel_a = country_metrics.sort_values("think_tank_citation_share", ascending=True).reset_index(drop=True)
    colors = [
        AUX_TERTIARY if country == "Republic of Korea" else NEUTRAL_GRAY
        for country in panel_a["display_country"]
    ]
    y = np.arange(len(panel_a))
    ax0.barh(y, panel_a["think_tank_citation_share"], color=colors, edgecolor="white", height=0.72)
    ax0.set_yticks(y, panel_a["display_country"])
    ax0.set_xlim(0, 1.48)
    ax0.set_xticks(np.linspace(0, 1, 6))
    ax0.xaxis.set_major_formatter(plt.FuncFormatter(lambda value, _pos=None: f"{value:.0%}"))
    ax0.set_xlabel("Think-tank share of DOI-linked citations")
    ax0.set_title("A. Think-tank share and within-type concentration", fontsize=11.5, fontweight="bold", pad=10)
    for index, row in panel_a.iterrows():
        share = float(row["think_tank_citation_share"])
        inside = share >= 0.14
        ax0.text(
            share - 0.015 if inside else share + 0.015,
            index,
            f"{share:.1%}",
            ha="right" if inside else "left",
            va="center",
            fontsize=8.8,
            fontweight="bold" if row["display_country"] == "Republic of Korea" else "normal",
            color="white" if inside else "#405047",
        )
        ax0.text(
            1.03,
            index,
            f"n={int(row['think_tank_institutions'])}; top 2={row['top2_share_within_think_tanks']:.1%}",
            ha="left",
            va="center",
            fontsize=8.2,
            color="#53635A",
        )
    ax0.text(1.03, len(panel_a) - 0.05, "institutions; concentration within think tanks", fontsize=7.8, color="#6F8A7C")
    ax0.grid(axis="y", visible=False)

    peer_values = np.sort(eligible_social.to_numpy())
    ax1.boxplot(
        peer_values,
        vert=False,
        positions=[0],
        widths=0.34,
        patch_artist=True,
        showfliers=False,
        boxprops={"facecolor": NEUTRAL_GRAY, "edgecolor": REFERENCE_LINE},
        medianprops={"color": AUX_PRIMARY, "linewidth": 2.2},
        whiskerprops={"color": REFERENCE_LINE, "linewidth": 1.3},
        capprops={"color": REFERENCE_LINE, "linewidth": 1.3},
    )
    jitter = np.random.default_rng(20251026).uniform(-0.11, 0.11, len(peer_values))
    ax1.scatter(peer_values, jitter, s=24, color="#7D9488", alpha=0.72, edgecolor="white", linewidth=0.4, zorder=3)
    ax1.scatter([kdi_social], [0.65], s=95, color=AUX_PRIMARY, edgecolor="white", linewidth=1.0, zorder=4)
    ax1.scatter([kiep_social], [1.18], s=95, color=AUX_TERTIARY, edgecolor="white", linewidth=1.0, zorder=4)
    ax1.text(kdi_social + 0.025, 0.65, f"{kdi_social:.1%}", va="center", fontsize=9.5, fontweight="bold")
    ax1.text(kiep_social + 0.025, 1.18, f"{kiep_social:.1%}", va="center", fontsize=9.5, fontweight="bold")
    ax1.text(
        float(eligible_social.median()),
        0.25,
        f"Eligible foreign median  {eligible_social.median():.1%}",
        ha="center",
        va="bottom",
        fontsize=8.8,
        color="#405047",
    )
    ax1.set_yticks(
        [0, 0.65, 1.18],
        [f"{len(eligible_foreign)} eligible foreign\nthink tanks", "KDI", "KIEP"],
    )
    ax1.set_ylim(-0.45, 1.55)
    ax1.set_xlim(0.0, 1.0)
    ax1.xaxis.set_major_formatter(plt.FuncFormatter(lambda value, _pos=None: f"{value:.0%}"))
    ax1.set_xlabel("Social-science share of four-domain citation assignments")
    ax1.set_title("B. KDI and KIEP within the foreign think-tank distribution", fontsize=11.5, fontweight="bold", pad=10)
    ax1.grid(axis="y", visible=False)

    top_examples = topic_similarity.head(5)["institution"].str.upper().tolist()
    fig.suptitle("Is Korea different after comparing foreign think tanks?", fontsize=14, fontweight="bold", y=0.985)
    fig.text(
        0.5,
        0.012,
        f"Panel A: 11 report comparison countries. Panel B: all non-Korean Overton think tanks with at least "
        f"{MIN_TOPIC_ASSIGNMENTS} cited-topic assignments. The top {TOP_MATCHES} by the equally weighted mean of KDI and KIEP "
        f"cited-topic cosine similarity span {peer_institutions['country'].nunique()} countries; closest include "
        f"{', '.join(top_examples)}. Source-type and profile similarity do not establish equivalent institutional roles.",
        ha="center",
        va="bottom",
        fontsize=8.2,
        color="#53635A",
        wrap=True,
    )
    fig.subplots_adjust(left=0.09, right=0.985, top=0.86, bottom=0.19, wspace=0.30)
    _transparent(fig, [ax0, ax1])

    out_png = out_dir / f"{run_tag}_kdi_kiep_peer_institutions.png"
    save_report_figure(fig, out_png, dpi=300, transparent=True, bbox_inches="tight", pad_inches=0.06)
    plt.close(fig)
    return out_png, country_path, peer_path_out, eligible_path, summary_path
