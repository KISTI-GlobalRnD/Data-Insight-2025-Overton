from __future__ import annotations

from pathlib import Path

import random

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.ticker import FuncFormatter, PercentFormatter

from .common import (
    AUX_CATEG,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    AUX_HIGHLIGHT,
    CORE_CATEG,
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    DOMAIN_LEGEND_LABELS,
    KOREA_DISPLAY_LABEL,
    KOREA_LABEL_ALIASES,
    NEUTRAL_GRAY,
    REFERENCE_TEXT,
    SOURCE_TYPE_MAJOR_COLORS,
    _add_edge_connectors,
    _adjust_text_with_keepout,
    _annotate_stacked_barh_percent,
    _ccdf_from_counts,
    _contrast_text_color,
    _display_country_label,
    _ellipsize,
    _fmt_short,
    _iso2_to_label,
    _make_domain_palette,
    _openalex_output_shares_by_country_domain,
    _policy_country_label,
    _policy_to_iso2,
    _row_normalize,
    _set_theme,
    _sql_quote,
    _stacked_barh_percent,
    _stacked_barh_percent_grouped,
    _tint,
    _transparent,
    save_report_figure,
)

def figure_11_self_share_selected(*, run_tag: str, in_dir: Path, out_dir: Path) -> tuple[Path, Path]:
    _doc_color, core_primary, _text_color, _cmap = _set_theme()

    mat = pd.read_csv(
        in_dir / f"{run_tag}_policy_country_research_country.csv",
        keep_default_na=False,
    )
    mat["research_country"] = mat["research_country"].fillna("")

    policy_to_iso2 = _policy_to_iso2()
    mat["policy_root"] = mat["policy_country"].astype(str).str.split(" > ").str[0]
    mat["policy_iso2"] = mat["policy_root"].map(policy_to_iso2)

    known = mat[(mat["policy_iso2"].notna()) & (mat["research_country"] != "")].copy()

    agg = (
        known.groupby(["policy_root", "policy_iso2"], as_index=False)["citation_rows"]
        .sum()
        .rename(columns={"policy_root": "policy_country", "citation_rows": "known_citations"})
    )
    self_agg = (
        known[known["research_country"] == known["policy_iso2"]]
        .groupby(["policy_root", "policy_iso2"], as_index=False)["citation_rows"]
        .sum()
        .rename(columns={"policy_root": "policy_country", "citation_rows": "self_citations"})
    )

    share = agg.merge(self_agg, on=["policy_country", "policy_iso2"], how="left").fillna({"self_citations": 0})
    share["self_share"] = share["self_citations"] / share["known_citations"]
    share = share.sort_values("known_citations", ascending=False)

    policy_total = (
        mat[mat["policy_iso2"].notna()]
        .groupby("policy_root", as_index=False)["citation_rows"]
        .sum()
        .rename(columns={"policy_root": "policy_country", "citation_rows": "total_citations"})
        .sort_values("total_citations", ascending=False)
    )
    korea_candidates = ["South Korea", "Republic of Korea", "Korea"]
    korea_label = next(
        (c for c in korea_candidates if c in set(policy_total["policy_country"].astype(str))),
        "South Korea",
    )
    top_countries = policy_total[policy_total["policy_country"].ne(korea_label)]["policy_country"].head(7).tolist()
    selected = top_countries + ([korea_label] if korea_label in share["policy_country"].values else [])

    sel = share[share["policy_country"].isin(selected)].copy()
    sel = sel.set_index("policy_country").reindex(selected).reset_index()

    plot_sel = sel.sort_values("self_share", ascending=False)
    overall = float(share["self_citations"].sum() / share["known_citations"].sum()) if share["known_citations"].sum() else 0.0

    order = plot_sel["policy_country"].tolist()

    dom = pd.read_csv(in_dir / f"{run_tag}_country_domain_matrix.csv")
    dom = dom.dropna(subset=["country", "domain", "citation_rows"]).copy()
    dom = dom[dom["country"].isin(order)].copy()
    dom = dom[dom["domain"].isin(DOMAIN_ORDER)].copy()
    dom_pivot = dom.pivot_table(index="country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0)
    dom_pivot = dom_pivot.reindex(index=order, columns=DOMAIN_ORDER, fill_value=0)
    dom_shares = _row_normalize(dom_pivot)

    # Domain mix for self-citations vs non-self citations (top countries + KR).
    policy_iso2_map = sel[["policy_country", "policy_iso2"]].dropna().drop_duplicates().copy()
    policy_iso2_map = policy_iso2_map[policy_iso2_map["policy_iso2"].astype(str).str.len() > 0]
    self_share = pd.DataFrame(index=order, columns=DOMAIN_ORDER, data=0.0)
    non_share = pd.DataFrame(index=order, columns=DOMAIN_ORDER, data=0.0)
    if not policy_iso2_map.empty:
        import duckdb

        domain_list = ",".join([f"'{d}'" for d in DOMAIN_ORDER])
        con = duckdb.connect()
        con.register("policy_iso2_map", policy_iso2_map)
        self_domains = con.execute(
            f"""
            WITH policy_country AS (
              SELECT DISTINCT
                policy_document_id,
                split_part(policy_source_country, ' > ', 1) AS policy_country
              FROM read_parquet('Data/overton_policy_meta/policy_source_country.parquet')
              WHERE policy_source_country IS NOT NULL
            ),
            work_country AS (
              SELECT oaid_w, first_author_country
              FROM read_parquet('Data/matched_openalex_with_oa_country_unique.parquet')
              WHERE first_author_country IS NOT NULL
                AND first_author_country <> ''
            ),
            work_domains AS (
              SELECT DISTINCT oaid_w, domain
              FROM read_parquet('Data/openalex_topics.parquet')
              WHERE domain IS NOT NULL
            )
            SELECT
              m.policy_country,
              wd.domain,
              COUNT(*) AS citation_rows
            FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
            JOIN policy_country pc USING (policy_document_id)
            JOIN policy_iso2_map m ON pc.policy_country = m.policy_country
            JOIN work_country wc USING (oaid_w)
            JOIN work_domains wd USING (oaid_w)
            WHERE wc.first_author_country = m.policy_iso2
              AND wd.domain IN ({domain_list})
            GROUP BY 1, 2
            """
        ).df()
        non_domains = con.execute(
            f"""
            WITH policy_country AS (
              SELECT DISTINCT
                policy_document_id,
                split_part(policy_source_country, ' > ', 1) AS policy_country
              FROM read_parquet('Data/overton_policy_meta/policy_source_country.parquet')
              WHERE policy_source_country IS NOT NULL
            ),
            work_country AS (
              SELECT oaid_w, first_author_country
              FROM read_parquet('Data/matched_openalex_with_oa_country_unique.parquet')
              WHERE first_author_country IS NOT NULL
                AND first_author_country <> ''
            ),
            work_domains AS (
              SELECT DISTINCT oaid_w, domain
              FROM read_parquet('Data/openalex_topics.parquet')
              WHERE domain IS NOT NULL
            )
            SELECT
              m.policy_country,
              wd.domain,
              COUNT(*) AS citation_rows
            FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
            JOIN policy_country pc USING (policy_document_id)
            JOIN policy_iso2_map m ON pc.policy_country = m.policy_country
            JOIN work_country wc USING (oaid_w)
            JOIN work_domains wd USING (oaid_w)
            WHERE wc.first_author_country <> m.policy_iso2
              AND wd.domain IN ({domain_list})
            GROUP BY 1, 2
            """
        ).df()
        con.close()

        if not self_domains.empty:
            self_pivot = self_domains.pivot_table(
                index="policy_country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0
            ).reindex(index=order, columns=DOMAIN_ORDER, fill_value=0)
            self_share = _row_normalize(self_pivot)
        if not non_domains.empty:
            non_pivot = non_domains.pivot_table(
                index="policy_country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0
            ).reindex(index=order, columns=DOMAIN_ORDER, fill_value=0)
            non_share = _row_normalize(non_pivot)

    # Domain-adjusted reference share within the DOI-linked article sample.
    output_share_csv = out_dir / f"{run_tag}_openalex_country_domain_output_share.csv"
    output_share_long = _openalex_output_shares_by_country_domain(domains=DOMAIN_ORDER, cache_csv=output_share_csv)
    output_share_pivot = (
        output_share_long.pivot_table(index="iso2", columns="domain", values="share", aggfunc="sum", fill_value=0)
        .reindex(columns=DOMAIN_ORDER, fill_value=0)
        .copy()
    )
    policy_country_to_iso2 = sel.set_index("policy_country")["policy_iso2"].to_dict()
    expected = []
    for policy_country in sel["policy_country"].tolist():
        iso2 = policy_country_to_iso2.get(policy_country)
        if not iso2 or iso2 not in output_share_pivot.index:
            expected.append(np.nan)
            continue
        expected.append(float((dom_shares.loc[policy_country] * output_share_pivot.loc[iso2]).sum()))
    sel["expected_self_share"] = expected
    sel["delta_pp"] = (sel["self_share"] - sel["expected_self_share"]) * 100.0
    out_csv = out_dir / f"{run_tag}_policy_country_self_share_selected.csv"
    sel_out = sel.copy()
    sel_out["policy_country"] = sel_out["policy_country"].map(_display_country_label)
    sel_out.to_csv(out_csv, index=False)

    order_display = [_display_country_label(c) for c in order]
    rename_map = {c: _display_country_label(c) for c in order}
    self_share_plot = self_share.rename(index=rename_map)
    non_share_plot = non_share.rename(index=rename_map)

    fig, (ax0, ax2) = plt.subplots(
        1,
        2,
        figsize=(13.6, 4.8),
        gridspec_kw={"width_ratios": [1.15, 1.0], "wspace": 0.06},
        constrained_layout=False,
    )

    self_vals = plot_sel.set_index("policy_country").loc[order]["self_share"].astype(float)
    expected_vals = sel.set_index("policy_country").loc[order]["expected_self_share"].astype(float)
    y = np.arange(len(order), dtype=float)
    bar_height = 0.50
    offset = bar_height * 0.15
    # With inverted y-axis, larger y is visually lower.
    y_expected = y + offset
    y_actual = y - offset
    ax0.barh(y_expected, expected_vals.to_numpy(), height=bar_height, color=NEUTRAL_GRAY, alpha=1.0, zorder=0)
    ax0.barh(y_actual, self_vals.to_numpy(), height=bar_height, color=AUX_SECONDARY, zorder=1)
    ax0.axvline(
        overall,
        color=REFERENCE_TEXT,
        linestyle="--",
        linewidth=1.2,
        alpha=0.9,
        label=f"Overall mean: {overall:.1%}",
        zorder=0,
    )
    ax0.annotate(
        f"Overall mean domestic-share ({overall:.1%})",
        xy=(overall, 0.02),
        xycoords=ax0.get_xaxis_transform(),
        xytext=(0, -10),
        textcoords="offset points",
        ha="center",
        va="top",
        fontsize=8,
        color=REFERENCE_TEXT,
    )
    ax0.invert_yaxis()
    ax0.yaxis.grid(False)
    ax0.xaxis.grid(True)
    ax0.set_title("A. Domestic-citation share (observed vs reference)")
    ax0.set_xlabel("Share (%)\nAssigned first-author country only")
    ax0.set_ylabel("Policy source country")
    ax0.set_xlim(0, 0.90)
    ax0.xaxis.set_major_formatter(FuncFormatter(lambda x, _pos=None: f"{x:.0%}"))
    ax0.set_yticks(y)
    ax0.set_yticklabels(order_display)
    from matplotlib.patches import Patch

    ax0.legend(
        handles=[
            Patch(facecolor=AUX_SECONDARY, label="Observed"),
            Patch(facecolor=NEUTRAL_GRAY, label="Domain-adjusted reference"),
        ],
        loc="lower right",
        frameon=True,
        fancybox=True,
        framealpha=0.95,
    )
    for i, country in enumerate(order):
        val = float(self_vals.loc[country])
        exp = expected_vals.loc[country]
        ratio_txt = ""
        if pd.notna(exp) and float(exp) > 0:
            ratio_txt = f", {val/float(exp):.1f}x"
        suffix = f" (ref. {float(exp):.1%}{ratio_txt})" if pd.notna(exp) else ""
        ax0.text(
            val + 0.012,
            y_actual[i],
            f"  {val:.1%}{suffix}",
            va="center",
            ha="left",
            fontsize=9,
            color=_text_color,
            clip_on=True,
        )

    _stacked_barh_percent_grouped(
        ax2,
        non_share_plot,
        self_share_plot,
        order=order_display,
        palette=DOMAIN_PALETTE,
        xlabel="Share within policy source (normalized)",
        group_labels=("Domestic-cited research", "Non-domestic-cited research"),
        show_legend=False,
        top_alpha=0.6,
        bottom_alpha=1.0,
        annotate=True,
    )
    ax2.invert_yaxis()
    ax2.set_title("B. Domain mix of domestic vs non-domestic citations")
    ax2.set_ylabel("")
    ax2.set_yticklabels([])
    ax2.set_xlim(0, 1.0)
    ax2.yaxis.tick_right()
    ax2.set_yticks(np.arange(len(order)))
    ax2.set_yticklabels(order_display)
    ax2.tick_params(axis="y", labelright=True, labelleft=False, length=0, pad=6)

    from matplotlib.patches import Patch

    legend_handles = [
        Patch(facecolor=DOMAIN_PALETTE[d], label=DOMAIN_LEGEND_LABELS.get(d, d))
        for d in DOMAIN_ORDER
        if d in dom_shares.columns
    ]
    ax2.legend(
        handles=legend_handles,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.18),
        frameon=True,
        fancybox=True,
        framealpha=0.95,
        ncol=4,
        handlelength=1.0,
        fontsize=8.5,
    )

    fig.subplots_adjust(wspace=0.06)
    fig.suptitle(
        "Domestic-citation share and domain mix (top 7 policy source countries + Korea)"
    )
    _transparent(fig, [ax0, ax2])
    out_png = out_dir / f"{run_tag}_policy_country_self_share_selected.png"
    save_report_figure(fig, out_png, dpi=200, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)
    return out_png, out_csv
