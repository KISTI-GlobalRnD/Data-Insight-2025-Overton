from __future__ import annotations

from pathlib import Path

import random

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.ticker import FuncFormatter, PercentFormatter

from .common import (
    AUX_CATEG,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    AUX_HIGHLIGHT,
    CORE_CATEG,
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    DOMAIN_LEGEND_LABELS,
    KOREA_DISPLAY_LABEL,
    KOREA_LABEL_ALIASES,
    NEUTRAL_GRAY,
    SOFT_GRID,
    SOURCE_TYPE_MAJOR_COLORS,
    _add_edge_connectors,
    _adjust_text_with_keepout,
    _annotate_stacked_barh_percent,
    _ccdf_from_counts,
    _contrast_text_color,
    _display_country_label,
    _ellipsize,
    _fmt_short,
    _iso2_to_label,
    _make_domain_palette,
    _openalex_output_shares_by_country_domain,
    _policy_country_label,
    _policy_to_iso2,
    _row_normalize,
    _set_theme,
    _sql_quote,
    _stacked_barh_percent,
    _stacked_barh_percent_grouped,
    _tint,
    _transparent,
)

def figure_si_repeat_citation_sensitivity(
    *,
    run_tag: str,
    out_dir: Path,
    thresholds: tuple[int, ...] = (2, 5, 10),
    trim_unknown: bool = False,
) -> tuple[Path, Path, Path]:
    """
    Sensitivity check for the "repeat citation" headline.

    - Defines repeat use as: a work cited by >=k distinct policy documents.
    - Shows overall shares by threshold and cohort-by-pubyear (lag effect proxy).
    """

    _doc_color, _core_primary, text_color, _cmap = _set_theme()

    citations_path = Path("Data/raw_df_citation_non_duplicated.parquet")
    if not citations_path.exists():
        raise FileNotFoundError(f"Missing citation parquet: {citations_path}")

    matched_path = Path("Data/matched_openalex_with_oa_country_unique.parquet")
    if not matched_path.exists():
        raise FileNotFoundError(f"Missing OpenAlex matched parquet: {matched_path}")

    import duckdb

    con = duckdb.connect()
    paper_counts_path = out_dir / f"{run_tag}_paper_citing_doc_counts.parquet"
    if not paper_counts_path.exists():
        out_dir.mkdir(parents=True, exist_ok=True)
        con.execute(
            f"""
            COPY (
                SELECT oaid_w, COUNT(DISTINCT policy_document_id) AS n
                FROM read_parquet('{citations_path}')
                WHERE oaid_w IS NOT NULL AND oaid_w <> ''
                GROUP BY oaid_w
            ) TO '{paper_counts_path}' (FORMAT PARQUET)
            """
        )

    # Use a conservative pubyear dedupe (min pubyear per work).
    df = con.execute(
        f"""
        WITH counts AS (
            SELECT oaid_w, n
            FROM read_parquet('{paper_counts_path}')
        ),
        meta AS (
            SELECT oaid_w, MIN(pubyear) AS pubyear
            FROM read_parquet('{matched_path}')
            GROUP BY oaid_w
        ),
        joined AS (
            SELECT
                counts.oaid_w,
                counts.n,
                meta.pubyear,
                CASE
                    WHEN meta.pubyear IS NULL THEN 'Unknown'
                    WHEN meta.pubyear <= 2015 THEN '≤2015'
                    WHEN meta.pubyear BETWEEN 2016 AND 2019 THEN '2016–2019'
                    WHEN meta.pubyear BETWEEN 2020 AND 2021 THEN '2020–2021'
                    WHEN meta.pubyear BETWEEN 2022 AND 2025 THEN '2022–2025'
                    ELSE 'Other'
                END AS cohort
            FROM counts
            LEFT JOIN meta USING (oaid_w)
        )
        SELECT cohort, n
        FROM joined
        """
    ).df()

    df["n"] = pd.to_numeric(df["n"], errors="coerce")
    df = df.dropna(subset=["n"]).copy()
    df["n"] = df["n"].astype(int)
    df["cohort"] = df["cohort"].astype(str)
    if trim_unknown:
        df = df[df["cohort"].ne("Unknown")].copy()

    cohort_order = ["≤2015", "2016–2019", "2020–2021", "2022–2025", "Unknown", "Other"]
    cohort_order = [c for c in cohort_order if c in set(df["cohort"].tolist())]

    # Overall thresholds.
    total_works = int(df.shape[0])
    overall_rows: list[dict[str, object]] = []
    for k in thresholds:
        n_ge = int((df["n"] >= int(k)).sum())
        overall_rows.append(
            {"threshold": int(k), "works": total_works, "works_ge": n_ge, "share": (n_ge / total_works) if total_works else 0.0}
        )
    overall_df = pd.DataFrame(overall_rows)

    # Cohort thresholds.
    cohort_rows: list[dict[str, object]] = []
    for cohort in cohort_order:
        sub = df[df["cohort"].eq(cohort)]
        works = int(sub.shape[0])
        for k in thresholds:
            n_ge = int((sub["n"] >= int(k)).sum())
            cohort_rows.append(
                {
                    "cohort": cohort,
                    "threshold": int(k),
                    "works": works,
                    "works_ge": n_ge,
                    "share": (n_ge / works) if works else 0.0,
                }
            )
    cohort_df = pd.DataFrame(cohort_rows)

    out_csv_overall = out_dir / f"{run_tag}_repeat_citation_thresholds.csv"
    out_csv_cohort = out_dir / f"{run_tag}_repeat_citation_by_cohort.csv"
    overall_df.to_csv(out_csv_overall, index=False)
    cohort_df.to_csv(out_csv_cohort, index=False)

    # Plot: (A) overall thresholds, (B) cohort lines.
    fig, (ax_a, ax_b) = plt.subplots(1, 2, figsize=(11.8, 4.6), gridspec_kw={"width_ratios": [1.0, 1.4]})

    ax_a.bar(
        overall_df["threshold"].astype(str),
        overall_df["share"].astype(float) * 100.0,
        color=AUX_PRIMARY,
        alpha=0.85,
    )
    ax_a.set_title("A. Overall (share of cited works)")
    ax_a.set_xlabel("Repeat-use threshold (>=k policy docs)")
    ax_a.set_ylabel("Share of works (%)")
    ax_a.set_ylim(0, max(55.0, float(overall_df["share"].max() * 100.0) * 1.15 if len(overall_df) else 55.0))
    ax_a.yaxis.grid(True, color=SOFT_GRID, linewidth=0.8)
    ax_a.xaxis.grid(False)
    ax_a.spines["top"].set_visible(False)
    ax_a.spines["right"].set_visible(False)
    ax_a.spines["left"].set_color(SOFT_GRID)
    ax_a.spines["bottom"].set_color(SOFT_GRID)
    for i, row in overall_df.iterrows():
        ax_a.text(
            i,
            float(row["share"]) * 100.0 + 1.2,
            f"{float(row['share'])*100.0:.1f}%",
            ha="center",
            va="bottom",
            fontsize=9,
            color=text_color,
        )

    palette = {2: AUX_SECONDARY, 5: AUX_TERTIARY, 10: AUX_HIGHLIGHT}
    for k in thresholds:
        sub = cohort_df[cohort_df["threshold"].eq(int(k))].copy()
        sub["cohort"] = pd.Categorical(sub["cohort"], categories=cohort_order, ordered=True)
        sub = sub.sort_values("cohort")
        ax_b.plot(
            sub["cohort"].astype(str),
            sub["share"].astype(float) * 100.0,
            marker="o",
            linewidth=2.2,
            color=palette.get(int(k), AUX_SECONDARY),
            label=f">={int(k)}",
            alpha=0.9,
        )
    ax_b.set_title("B. Cohort by publication year (lag sensitivity)")
    ax_b.set_xlabel("Publication year cohort (OpenAlex)")
    ax_b.set_ylabel("Share of works (%)")
    ax_b.set_ylim(0, max(55.0, float(cohort_df["share"].max() * 100.0) * 1.15 if len(cohort_df) else 55.0))
    ax_b.yaxis.grid(True, color=SOFT_GRID, linewidth=0.8)
    ax_b.xaxis.grid(False)
    ax_b.spines["top"].set_visible(False)
    ax_b.spines["right"].set_visible(False)
    ax_b.spines["left"].set_color(SOFT_GRID)
    ax_b.spines["bottom"].set_color(SOFT_GRID)
    ax_b.tick_params(axis="x", rotation=0)
    ax_b.legend(title="Threshold", loc="lower right", frameon=True, fancybox=True, framealpha=0.95)

    fig.suptitle("Repeat citation sensitivity (distinct policy documents per cited work)", y=1.03)
    _transparent(fig, [ax_a, ax_b])
    fig.tight_layout(pad=0.7)

    out_png = out_dir / f"{run_tag}_repeat_citation_sensitivity.png"
    fig.savefig(out_png, dpi=300, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)

    return out_png, out_csv_overall, out_csv_cohort
