from __future__ import annotations

from pathlib import Path

import random

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.ticker import FuncFormatter, PercentFormatter

from .common import (
    AUX_CATEG,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    AUX_HIGHLIGHT,
    CORE_CATEG,
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    DOMAIN_LEGEND_LABELS,
    KOREA_DISPLAY_LABEL,
    KOREA_LABEL_ALIASES,
    NEUTRAL_GRAY,
    REFERENCE_TEXT,
    SOFT_GRID,
    SOURCE_TYPE_MAJOR_COLORS,
    _add_edge_connectors,
    _adjust_text_with_keepout,
    _annotate_stacked_barh_percent,
    _ccdf_from_counts,
    _contrast_text_color,
    _display_country_label,
    _ellipsize,
    _fmt_short,
    _iso2_to_label,
    _make_domain_palette,
    _openalex_output_shares_by_country_domain,
    _policy_country_label,
    _policy_to_iso2,
    _row_normalize,
    _set_theme,
    _sql_quote,
    _stacked_barh_percent,
    _stacked_barh_percent_grouped,
    _tint,
    _transparent,
)

def figure_si_density_robustness_policy_source_type(
    *, run_tag: str, in_dir: Path, out_dir: Path, trim_pct: float = 0.10, top_k: int = 14
) -> tuple[Path, Path]:
    _doc_color, _core_primary, text_color, _cmap = _set_theme()

    citations_path = Path("Data/raw_df_citation_non_duplicated.parquet")
    if not citations_path.exists():
        raise FileNotFoundError(f"Missing citation parquet: {citations_path}")

    meta_path = Path("Data/overton_policy_meta/policy_source_type.parquet")
    if not meta_path.exists():
        raise FileNotFoundError(f"Missing policy source type parquet: {meta_path}")

    # Select a manageable set: top-k types by citations (plus major buckets, in case).
    source_type_cit = pd.read_csv(in_dir / f"{run_tag}_source_type_citations.csv")
    source_type_cit = source_type_cit.dropna(subset=["source_type", "citation_rows"]).copy()
    source_type_cit["citation_rows"] = pd.to_numeric(source_type_cit["citation_rows"], errors="coerce").fillna(0.0)
    top_types = source_type_cit.nlargest(int(top_k), "citation_rows")["source_type"].astype(str).tolist()
    majors = ["government", "igo", "think tank", "other"]
    selected_raw = list(dict.fromkeys(top_types + majors))

    trim_pct = float(trim_pct)
    if not (0.0 < trim_pct < 0.5):
        raise ValueError("trim_pct must be in (0, 0.5)")
    q_lo = trim_pct / 2.0
    q_hi = 1.0 - (trim_pct / 2.0)

    import duckdb

    con = duckdb.connect()
    doc_counts_path = out_dir / f"{run_tag}_doc_citation_counts.parquet"
    if not doc_counts_path.exists():
        out_dir.mkdir(parents=True, exist_ok=True)
        con.execute(
            f"""
            COPY (
                SELECT policy_document_id, COUNT(*) AS n
                FROM read_parquet('{citations_path}')
                GROUP BY policy_document_id
            ) TO '{doc_counts_path}' (FORMAT PARQUET)
            """
        )

    def _sql_list(items: list[str]) -> str:
        return ", ".join("'" + str(x).replace("'", "''") + "'" for x in items)

    df = con.execute(
        f"""
        WITH meta AS (
            SELECT DISTINCT policy_document_id, policy_source_type AS group_value
            FROM read_parquet('{meta_path}')
            WHERE policy_source_type IN ({_sql_list(selected_raw)})
        ),
        docs AS (
            SELECT policy_document_id, n
            FROM read_parquet('{doc_counts_path}')
        ),
        joined AS (
            SELECT meta.group_value, meta.policy_document_id, docs.n
            FROM meta
            LEFT JOIN docs USING(policy_document_id)
        ),
        citing AS (
            SELECT group_value, n
            FROM joined
            WHERE n IS NOT NULL AND n > 0
        ),
        cutoffs AS (
            SELECT
                group_value,
                quantile_cont(n, {q_lo}) AS lo,
                quantile_cont(n, {q_hi}) AS hi
            FROM citing
            GROUP BY group_value
        )
        SELECT
            joined.group_value AS group_value,
            COUNT(DISTINCT joined.policy_document_id) AS policy_docs,
            COUNT(DISTINCT joined.policy_document_id) FILTER (WHERE joined.n IS NOT NULL) AS citing_policy_docs,
            SUM(COALESCE(joined.n, 0)) AS citation_rows,
            (COUNT(DISTINCT joined.policy_document_id) FILTER (WHERE joined.n IS NOT NULL)) * 1.0
                / NULLIF(COUNT(DISTINCT joined.policy_document_id), 0) AS citing_share,
            SUM(COALESCE(joined.n, 0)) * 1.0
                / NULLIF(COUNT(DISTINCT joined.policy_document_id) FILTER (WHERE joined.n IS NOT NULL), 0) AS mean_per_citing_doc,
            median(joined.n) FILTER (WHERE joined.n IS NOT NULL) AS median_per_citing_doc,
            AVG(joined.n) FILTER (WHERE joined.n BETWEEN cutoffs.lo AND cutoffs.hi) AS trimmed_mean_per_citing_doc,
            quantile_cont(joined.n, 0.75) FILTER (WHERE joined.n IS NOT NULL) AS p75_per_citing_doc
        FROM joined
        LEFT JOIN cutoffs USING (group_value)
        GROUP BY joined.group_value, cutoffs.lo, cutoffs.hi
        ORDER BY citation_rows DESC
        """
    ).df()

    df["group_label"] = df["group_value"].astype(str)
    df = df.sort_values("citation_rows", ascending=False).copy()

    out_csv = out_dir / f"{run_tag}_policy_source_type_density_robust.csv"
    df.to_csv(out_csv, index=False)

    fig_h = 0.40 * max(len(df), 8) + 1.8
    fig, ax = plt.subplots(figsize=(10.4, fig_h))
    y = np.arange(len(df))
    ax.scatter(
        df["mean_per_citing_doc"].astype(float),
        y,
        s=64,
        marker="o",
        color=AUX_SECONDARY,
        alpha=0.85,
        label="Mean (citing docs)",
        zorder=3,
    )
    ax.scatter(
        df["median_per_citing_doc"].astype(float),
        y,
        s=56,
        marker="s",
        color=AUX_PRIMARY,
        alpha=0.85,
        label="Median (citing docs)",
        zorder=4,
    )
    ax.scatter(
        df["trimmed_mean_per_citing_doc"].astype(float),
        y,
        s=60,
        marker="^",
        color=AUX_HIGHLIGHT,
        alpha=0.85,
        label=f"Trimmed mean ({int(q_lo*100)}–{int(q_hi*100)}%)",
        zorder=2,
    )
    ax.set_yticks(y)
    ax.set_yticklabels(df["group_label"].astype(str).tolist())
    ax.invert_yaxis()
    ax.set_xlabel("DOI citations per citing policy document")
    ax.set_ylabel("Policy source type")
    ax.set_title("Density robustness (policy source type): mean vs median vs trimmed mean")
    ax.xaxis.grid(True, color=SOFT_GRID, linewidth=0.8)
    ax.yaxis.grid(False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(SOFT_GRID)
    ax.spines["bottom"].set_color(SOFT_GRID)
    ax.legend(loc="lower right", frameon=True, fancybox=True, framealpha=0.95)

    x_max = float(
        np.nanmax(
            [
                df["mean_per_citing_doc"].astype(float).max(),
                df["median_per_citing_doc"].astype(float).max(),
                df["trimmed_mean_per_citing_doc"].astype(float).max(),
            ]
        )
    )
    ax.set_xlim(0, x_max * 1.18 if x_max > 0 else 1.0)
    for i, share in enumerate(df["citing_share"].astype(float).fillna(0.0).tolist()):
        ax.text(
            x_max * 1.02,
            i,
            f"{share:.0%}",
            ha="left",
            va="center",
            fontsize=9,
            color=REFERENCE_TEXT,
        )
    ax.text(
        0.985,
        0.02,
        "Right: citing share",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=9,
        color=REFERENCE_TEXT,
    )

    _transparent(fig, [ax])
    fig.tight_layout(pad=0.7)
    out_png = out_dir / f"{run_tag}_policy_source_type_density_robust.png"
    fig.savefig(out_png, dpi=300, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)

    return out_png, out_csv
