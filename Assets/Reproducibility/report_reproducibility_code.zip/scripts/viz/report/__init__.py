"""Report/SI static figure builders.

Each figure lives in its own module so we can rebuild only what changed.
"""

