from __future__ import annotations

from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt

from .common import (
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    KOREA_DISPLAY_LABEL,
    _display_country_label,
    _row_normalize,
    _set_theme,
    _stacked_barh_percent,
    _transparent,
    save_report_figure,
)


def figure_6_country_domain_heatmap(*, run_tag: str, in_dir: Path, out_dir: Path) -> Path:
    _doc_color, _core_primary, _text_color, _cmap = _set_theme()

    country_cit = pd.read_csv(in_dir / f"{run_tag}_country_citations.csv")
    country_cit = country_cit.dropna(subset=["country", "citation_rows"]).copy()
    country_cit["country"] = country_cit["country"].map(_display_country_label)
    country_cit["citation_rows"] = pd.to_numeric(country_cit["citation_rows"], errors="coerce").fillna(0.0)
    country_cit = (
        country_cit.groupby("country", as_index=False)["citation_rows"]
        .sum()
        .sort_values("citation_rows", ascending=False)
        .copy()
    )
    country_cit = country_cit[country_cit["citation_rows"] > 0].copy()
    top10 = country_cit.nlargest(10, "citation_rows").copy()
    korea = country_cit[country_cit["country"] == KOREA_DISPLAY_LABEL].copy()
    if korea.empty:
        raise ValueError("Korea row not found in country citations CSV.")
    korea = korea.nlargest(1, "citation_rows").copy()

    selected = pd.concat([top10, korea], ignore_index=True).drop_duplicates(subset=["country"], keep="first")[
        "country"
    ].tolist()

    mat = pd.read_csv(in_dir / f"{run_tag}_country_domain_matrix.csv")
    mat = mat.dropna(subset=["country", "domain", "citation_rows"]).copy()
    mat["country"] = mat["country"].map(_display_country_label)
    mat["citation_rows"] = pd.to_numeric(mat["citation_rows"], errors="coerce").fillna(0.0)
    mat = mat.groupby(["country", "domain"], as_index=False)["citation_rows"].sum()
    mat = mat[mat["country"].isin(selected)].copy()
    mat = mat[mat["domain"].isin(DOMAIN_ORDER)].copy()

    pivot = mat.pivot_table(index="country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0)
    pivot = pivot.reindex(index=selected, columns=DOMAIN_ORDER, fill_value=0)
    shares = _row_normalize(pivot)

    fig, ax = plt.subplots(figsize=(9.2, 5.4))
    _stacked_barh_percent(
        ax,
        shares,
        order=selected,
        palette=DOMAIN_PALETTE,
        xlabel="Share within policy source (normalized)",
        show_legend=True,
    )
    ax.invert_yaxis()
    ax.set_title("Domain mix by policy source (top 10 + Korea)", pad=2)
    ax.set_ylabel("Policy source country")

    _transparent(fig, [ax])
    fig.subplots_adjust(bottom=0.36)
    out_png = out_dir / f"{run_tag}_country_domain_heatmap.png"
    save_report_figure(fig, out_png, dpi=200, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)
    return out_png
