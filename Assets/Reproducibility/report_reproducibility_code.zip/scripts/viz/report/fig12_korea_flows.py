from __future__ import annotations

from pathlib import Path

import random

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.ticker import FuncFormatter, PercentFormatter

from .common import (
    AUX_CATEG,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    AUX_HIGHLIGHT,
    CORE_CATEG,
    DOMAIN_ORDER,
    DOMAIN_PALETTE,
    DOMAIN_LEGEND_LABELS,
    KOREA_DISPLAY_LABEL,
    KOREA_LABEL_ALIASES,
    NEUTRAL_GRAY,
    REFERENCE_TEXT,
    SOURCE_TYPE_MAJOR_COLORS,
    _add_edge_connectors,
    _adjust_text_with_keepout,
    _annotate_stacked_barh_percent,
    _ccdf_from_counts,
    _contrast_text_color,
    _display_country_label,
    _ellipsize,
    _fmt_short,
    _iso2_to_label,
    _make_domain_palette,
    _openalex_output_shares_by_country_domain,
    _policy_country_label,
    _policy_to_iso2,
    _row_normalize,
    _set_theme,
    _sql_quote,
    _stacked_barh_percent,
    _stacked_barh_percent_grouped,
    _tint,
    _transparent,
    save_report_figure,
)

def figure_12_korea_flows(*, run_tag: str, in_dir: Path, out_dir: Path) -> tuple[Path, Path]:
    _doc_color, core_primary, text_color, _cmap = _set_theme()

    flow = pd.read_csv(
        in_dir / f"{run_tag}_policy_country_research_country.csv",
        keep_default_na=False,
    )
    flow["research_country"] = flow["research_country"].fillna("").astype(str).str.strip()
    flow["policy_country"] = flow["policy_country"].astype(str).str.strip()

    def _fmt_k(x: float, _pos: int | None = None) -> str:
        if x >= 1_000_000:
            return f"{x/1_000_000:.1f}M"
        if x >= 1_000:
            return f"{x/1_000:.0f}K"
        return str(int(x))

    # Inbound: KR research cited by policy sources
    inbound = flow[flow["research_country"] == "KR"].copy()
    inbound = inbound.groupby("policy_country", as_index=False)["citation_rows"].sum().sort_values("citation_rows", ascending=False)
    inbound_total = inbound["citation_rows"].sum()
    inbound_top = inbound.head(10).copy()
    inbound_top["share"] = inbound_top["citation_rows"] / inbound_total if inbound_total else 0

    korea_candidates = ["South Korea", "Republic of Korea", "Korea"]
    korea_policy_label = next((c for c in korea_candidates if c in set(flow["policy_country"])), "South Korea")

    # Outbound: Republic of Korea policy cites which research countries
    outbound = flow[flow["policy_country"] == korea_policy_label].copy()
    outbound = outbound.dropna(subset=["research_country"])
    outbound = outbound[outbound["research_country"].astype(str).str.strip().ne("")].copy()
    outbound = outbound.groupby("research_country", as_index=False)["citation_rows"].sum().sort_values("citation_rows", ascending=False)
    outbound_total = outbound["citation_rows"].sum()
    outbound_top = outbound.head(10).copy()
    outbound_top["share"] = outbound_top["citation_rows"] / outbound_total if outbound_total else 0

    iso2_to_label = _iso2_to_label()
    outbound_top["research_country_label"] = outbound_top["research_country"].map(lambda c: iso2_to_label.get(c, c))

    # Domain-adjusted reference shares within the DOI-linked article sample:
    # - Inbound: reference share across policy sources, based on each source's citation volume and domain mix
    # - Outbound: reference share within KR policy, based on KR policy domain mix
    output_share_csv = out_dir / f"{run_tag}_openalex_country_domain_output_share.csv"
    output_share_long = _openalex_output_shares_by_country_domain(domains=DOMAIN_ORDER, cache_csv=output_share_csv)
    output_share_pivot = (
        output_share_long.pivot_table(index="iso2", columns="domain", values="share", aggfunc="sum", fill_value=0)
        .reindex(columns=DOMAIN_ORDER, fill_value=0)
        .copy()
    )
    kr_output_share = output_share_pivot.loc["KR"] if "KR" in output_share_pivot.index else pd.Series(index=DOMAIN_ORDER, dtype=float)

    dom = pd.read_csv(in_dir / f"{run_tag}_country_domain_matrix.csv")
    dom = dom.dropna(subset=["country", "domain", "citation_rows"]).copy()
    dom = dom[dom["domain"].isin(DOMAIN_ORDER)].copy()
    dom_pivot_all = dom.pivot_table(index="country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0)
    dom_pivot_all = dom_pivot_all.reindex(columns=DOMAIN_ORDER, fill_value=0)
    dom_share_all = _row_normalize(dom_pivot_all)

    known_totals = (
        flow[flow["research_country"].ne("")]
        .groupby("policy_country", as_index=False)["citation_rows"]
        .sum()
        .rename(columns={"citation_rows": "known_citations"})
    )
    expected_share_in_policy = (dom_share_all * kr_output_share).sum(axis=1).to_frame("expected_kr_share")
    expected_share_in_policy.index.name = "policy_country"
    expected_share_in_policy = expected_share_in_policy.reset_index()

    inbound_expected = known_totals.merge(expected_share_in_policy, on="policy_country", how="left")
    inbound_expected["expected_kr_citations"] = inbound_expected["known_citations"] * inbound_expected["expected_kr_share"]
    expected_total = float(inbound_expected["expected_kr_citations"].sum(skipna=True))
    inbound_expected["expected_share"] = (
        inbound_expected["expected_kr_citations"] / expected_total if expected_total else np.nan
    )
    inbound_expected = inbound_expected[["policy_country", "expected_share"]].copy()

    inbound_top = inbound_top.merge(inbound_expected, on="policy_country", how="left")
    inbound_top["delta_pp"] = (inbound_top["share"] - inbound_top["expected_share"]) * 100.0
    inbound_top["expected_citations_scaled"] = inbound_top["expected_share"] * float(inbound_total) if inbound_total else np.nan

    korea_policy_share_label = next((c for c in korea_candidates if c in dom_share_all.index), korea_policy_label)
    kr_policy_share = (
        dom_share_all.loc[korea_policy_share_label]
        if korea_policy_share_label in dom_share_all.index
        else pd.Series(index=DOMAIN_ORDER, dtype=float)
    )
    expected_out = []
    for iso2 in outbound_top["research_country"].astype(str).tolist():
        if iso2 in output_share_pivot.index:
            expected_out.append(float((kr_policy_share * output_share_pivot.loc[iso2]).sum()))
        else:
            expected_out.append(np.nan)
    outbound_top["expected_share"] = expected_out
    outbound_top["delta_pp"] = (outbound_top["share"] - outbound_top["expected_share"]) * 100.0
    outbound_top["expected_citations_scaled"] = outbound_top["expected_share"] * float(outbound_total) if outbound_total else np.nan

    out_csv = pd.concat(
        [
            inbound_top.rename(columns={"policy_country": "entity"})
            .assign(direction="Inbound (KR research cited by...)")[
                ["direction", "entity", "citation_rows", "share", "expected_share", "delta_pp"]
            ],
            outbound_top.rename(columns={"research_country_label": "entity"})
            .assign(direction=f"Outbound ({KOREA_DISPLAY_LABEL} policy cites...)")[
                ["direction", "entity", "citation_rows", "share", "expected_share", "delta_pp"]
            ],
        ],
        ignore_index=True,
    )
    out_csv["entity"] = out_csv["entity"].map(_display_country_label)

    out_csv_path = out_dir / f"{run_tag}_korea_policy_research_flows_top10.csv"
    out_csv.to_csv(out_csv_path, index=False)

    p_in = inbound_top.sort_values("citation_rows", ascending=True)
    p_out = outbound_top.sort_values("citation_rows", ascending=True)

    inbound_entities = p_in["policy_country"].astype(str).tolist()
    outbound_iso2 = outbound_top["research_country"].astype(str).tolist()
    outbound_entities = p_out["research_country_label"].astype(str).tolist()

    import duckdb

    con = duckdb.connect()
    inbound_list = ",".join([_sql_quote(c) for c in inbound_entities]) if inbound_entities else "''"
    outbound_list = ",".join([_sql_quote(c) for c in outbound_iso2]) if outbound_iso2 else "''"

    inbound_domains = con.execute(
        f"""
        WITH policy_country AS (
          SELECT DISTINCT
            policy_document_id,
            split_part(policy_source_country, ' > ', 1) AS policy_country
          FROM read_parquet('Data/overton_policy_meta/policy_source_country.parquet')
          WHERE policy_source_country IS NOT NULL
        ),
        kr_works AS (
          SELECT DISTINCT oaid_w
          FROM read_parquet('Data/matched_openalex_with_oa_country_unique.parquet')
          WHERE first_author_country = 'KR'
        ),
        work_domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('Data/openalex_topics.parquet')
          WHERE domain IS NOT NULL
        )
        SELECT
          pc.policy_country,
          wd.domain,
          COUNT(*) AS citation_rows
        FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
        JOIN policy_country pc USING (policy_document_id)
        JOIN kr_works k USING (oaid_w)
        JOIN work_domains wd USING (oaid_w)
        WHERE pc.policy_country IN ({inbound_list})
          AND wd.domain IN ({",".join([f"'{d}'" for d in DOMAIN_ORDER])})
        GROUP BY 1, 2
        """
    ).df()

    outbound_domains = con.execute(
        f"""
        WITH policy_country AS (
          SELECT DISTINCT
            policy_document_id,
            split_part(policy_source_country, ' > ', 1) AS policy_country
          FROM read_parquet('Data/overton_policy_meta/policy_source_country.parquet')
          WHERE policy_source_country IS NOT NULL
        ),
        work_country AS (
          SELECT oaid_w, first_author_country
          FROM read_parquet('Data/matched_openalex_with_oa_country_unique.parquet')
          WHERE first_author_country IS NOT NULL
        ),
        work_domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('Data/openalex_topics.parquet')
          WHERE domain IS NOT NULL
        )
        SELECT
          wc.first_author_country AS research_country,
          wd.domain,
          COUNT(*) AS citation_rows
        FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
        JOIN policy_country pc USING (policy_document_id)
        JOIN work_country wc USING (oaid_w)
        JOIN work_domains wd USING (oaid_w)
        WHERE pc.policy_country = {_sql_quote(korea_policy_label)}
          AND wc.first_author_country IN ({outbound_list})
          AND wd.domain IN ({",".join([f"'{d}'" for d in DOMAIN_ORDER])})
        GROUP BY 1, 2
        """
    ).df()

    inbound_non_kr_domains = con.execute(
        f"""
        WITH policy_country AS (
          SELECT DISTINCT
            policy_document_id,
            split_part(policy_source_country, ' > ', 1) AS policy_country
          FROM read_parquet('Data/overton_policy_meta/policy_source_country.parquet')
          WHERE policy_source_country IS NOT NULL
        ),
        work_country AS (
          SELECT oaid_w, first_author_country
          FROM read_parquet('Data/matched_openalex_with_oa_country_unique.parquet')
          WHERE first_author_country IS NOT NULL
        ),
        work_domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('Data/openalex_topics.parquet')
          WHERE domain IS NOT NULL
        )
        SELECT
          pc.policy_country,
          wd.domain,
          COUNT(*) AS citation_rows
        FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
        JOIN policy_country pc USING (policy_document_id)
        JOIN work_country wc USING (oaid_w)
        JOIN work_domains wd USING (oaid_w)
        WHERE pc.policy_country IN ({inbound_list})
          AND wc.first_author_country <> ''
          AND wc.first_author_country <> 'KR'
          AND wd.domain IN ({",".join([f"'{d}'" for d in DOMAIN_ORDER])})
        GROUP BY 1, 2
        """
    ).df()

    outbound_non_kr_policy_domains = con.execute(
        f"""
        WITH policy_country AS (
          SELECT DISTINCT
            policy_document_id,
            split_part(policy_source_country, ' > ', 1) AS policy_country
          FROM read_parquet('Data/overton_policy_meta/policy_source_country.parquet')
          WHERE policy_source_country IS NOT NULL
        ),
        work_country AS (
          SELECT oaid_w, first_author_country
          FROM read_parquet('Data/matched_openalex_with_oa_country_unique.parquet')
          WHERE first_author_country IS NOT NULL
        ),
        work_domains AS (
          SELECT DISTINCT oaid_w, domain
          FROM read_parquet('Data/openalex_topics.parquet')
          WHERE domain IS NOT NULL
        )
        SELECT
          wc.first_author_country AS research_country,
          wd.domain,
          COUNT(*) AS citation_rows
        FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet') c
        JOIN policy_country pc USING (policy_document_id)
        JOIN work_country wc USING (oaid_w)
        JOIN work_domains wd USING (oaid_w)
        WHERE pc.policy_country NOT IN ('South Korea', 'Korea', 'Republic of Korea')
          AND wc.first_author_country IN ({outbound_list})
          AND wd.domain IN ({",".join([f"'{d}'" for d in DOMAIN_ORDER])})
        GROUP BY 1, 2
        """
    ).df()
    con.close()

    inbound_domains = inbound_domains.dropna(subset=["policy_country", "domain", "citation_rows"]).copy()
    in_pivot = inbound_domains.pivot_table(
        index="policy_country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0
    )
    in_pivot = in_pivot.reindex(index=inbound_entities, columns=DOMAIN_ORDER, fill_value=0)
    in_share = _row_normalize(in_pivot)

    inbound_non_kr_domains = inbound_non_kr_domains.dropna(subset=["policy_country", "domain", "citation_rows"]).copy()
    in_non_pivot = inbound_non_kr_domains.pivot_table(
        index="policy_country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0
    )
    in_non_pivot = in_non_pivot.reindex(index=inbound_entities, columns=DOMAIN_ORDER, fill_value=0)
    in_non_share = _row_normalize(in_non_pivot)

    outbound_domains = outbound_domains.dropna(subset=["research_country", "domain", "citation_rows"]).copy()
    outbound_domains["research_country_label"] = outbound_domains["research_country"].map(lambda c: iso2_to_label.get(c, c))
    out_pivot = outbound_domains.pivot_table(
        index="research_country_label", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0
    )
    out_pivot = out_pivot.reindex(index=outbound_entities, columns=DOMAIN_ORDER, fill_value=0)
    out_share = _row_normalize(out_pivot)

    outbound_non_kr_policy_domains = outbound_non_kr_policy_domains.dropna(subset=["research_country", "domain", "citation_rows"]).copy()
    outbound_non_kr_policy_domains["research_country_label"] = outbound_non_kr_policy_domains["research_country"].map(
        lambda c: iso2_to_label.get(c, c)
    )
    out_non_pivot = outbound_non_kr_policy_domains.pivot_table(
        index="research_country_label", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0
    )
    out_non_pivot = out_non_pivot.reindex(index=outbound_entities, columns=DOMAIN_ORDER, fill_value=0)
    out_non_share = _row_normalize(out_non_pivot)

    fig, axes = plt.subplots(
        2,
        2,
        figsize=(13.4, 10.8),
        constrained_layout=True,
        gridspec_kw={"height_ratios": [1.15, 1.56]},
    )

    expected_in = p_in["expected_citations_scaled"].astype(float)
    expected_in = expected_in.where(np.isfinite(expected_in), 0.0)
    y = np.arange(len(p_in), dtype=float)
    bar_height = 0.50
    offset = bar_height * 0.15
    y_expected = y - offset
    y_actual = y + offset
    axes[0, 0].barh(y_expected, expected_in, height=bar_height, color=NEUTRAL_GRAY, alpha=1.0, zorder=0)
    axes[0, 0].barh(y_actual, p_in["citation_rows"], height=bar_height, color=AUX_SECONDARY, zorder=1)
    axes[0, 0].yaxis.grid(False)
    axes[0, 0].xaxis.grid(True)
    axes[0, 0].set_title("A. Policy sources citing Korea-authored research")
    axes[0, 0].set_xlabel("Citations to Korea-authored research")
    axes[0, 0].text(
        0.98,
        0.02,
        "Green and label: observed share · gray: domain-adjusted reference",
        transform=axes[0, 0].transAxes,
        ha="right",
        va="bottom",
        fontsize=8,
        color=REFERENCE_TEXT,
    )
    axes[0, 0].set_ylabel("Policy source")
    axes[0, 0].xaxis.set_major_formatter(FuncFormatter(_fmt_k))
    x_max_in = float(max(p_in["citation_rows"].max(), expected_in.max())) if len(p_in) else 1.0
    axes[0, 0].set_xlim(0, x_max_in * 1.14)
    max_in = float(p_in["citation_rows"].max()) if len(p_in) else 0.0
    for y, (val, share) in enumerate(zip(p_in["citation_rows"], p_in["share"])):
        label_text = f"{float(share):.1%}"
        if max_in > 0 and float(val) == max_in:
            label_x = max(float(val) - x_max_in * 0.02, 0.01)
            axes[0, 0].text(
                label_x,
                y_actual[y],
                label_text,
                va="center",
                ha="right",
                fontsize=9,
                color="white",
            )
        else:
            axes[0, 0].text(
                val,
                y_actual[y],
                f"  {label_text}",
                va="center",
                ha="left",
                fontsize=9,
                color=text_color,
            )
    axes[0, 0].set_yticks(np.arange(len(p_in), dtype=float))
    axes[0, 0].set_yticklabels([_display_country_label(c) for c in p_in["policy_country"].astype(str).tolist()])

    expected_out_scaled = p_out["expected_citations_scaled"].astype(float)
    expected_out_scaled = expected_out_scaled.where(np.isfinite(expected_out_scaled), 0.0)
    y = np.arange(len(p_out), dtype=float)
    y_expected = y - offset
    y_actual = y + offset
    axes[0, 1].barh(y_expected, expected_out_scaled, height=bar_height, color=NEUTRAL_GRAY, alpha=1.0, zorder=0)
    axes[0, 1].barh(y_actual, p_out["citation_rows"], height=bar_height, color=AUX_SECONDARY, zorder=1)
    axes[0, 1].yaxis.grid(False)
    axes[0, 1].xaxis.grid(True)
    axes[0, 1].set_title("B. Research countries cited by Korea policy documents")
    axes[0, 1].set_xlabel("Citations by Korea policy documents")
    axes[0, 1].text(
        0.98,
        0.02,
        "Assigned first-author country only\nGreen and label: observed share · gray: domain-adjusted reference",
        transform=axes[0, 1].transAxes,
        ha="right",
        va="bottom",
        fontsize=8,
        color=REFERENCE_TEXT,
    )
    axes[0, 1].set_ylabel("Research country (first author)")
    axes[0, 1].xaxis.set_major_formatter(FuncFormatter(_fmt_k))
    x_max_out = float(max(p_out["citation_rows"].max(), expected_out_scaled.max())) if len(p_out) else 1.0
    axes[0, 1].set_xlim(0, x_max_out * 1.14)
    max_out = float(p_out["citation_rows"].max()) if len(p_out) else 0.0
    for y, (val, share) in enumerate(zip(p_out["citation_rows"], p_out["share"])):
        label_text = f"{float(share):.1%}"
        if max_out > 0 and float(val) == max_out:
            label_x = max(float(val) - x_max_out * 0.02, 0.01)
            axes[0, 1].text(
                label_x,
                y_actual[y],
                label_text,
                va="center",
                ha="right",
                fontsize=9,
                color="white",
            )
        else:
            axes[0, 1].text(
                val,
                y_actual[y],
                f"  {label_text}",
                va="center",
                ha="left",
                fontsize=9,
                color=text_color,
            )
    axes[0, 1].set_yticks(np.arange(len(p_out), dtype=float))
    axes[0, 1].set_yticklabels(p_out["research_country_label"].astype(str).tolist())

    inbound_entities_display = [_display_country_label(c) for c in inbound_entities]
    rename_map_inbound = {c: _display_country_label(c) for c in inbound_entities}
    in_share_plot = in_share.rename(index=rename_map_inbound)
    in_non_share_plot = in_non_share.rename(index=rename_map_inbound)

    _stacked_barh_percent_grouped(
        axes[1, 0],
        in_share_plot,
        in_non_share_plot,
        order=inbound_entities_display,
        palette=DOMAIN_PALETTE,
        xlabel="Domain share within cited research (normalized)",
        group_labels=("Korea-authored", "Non-Korea-authored"),
        show_legend=False,
        top_alpha=1.0,
        bottom_alpha=0.5,
        annotate=True,
    )
    axes[1, 0].set_title("C. Domains of Korea vs non-Korea research cited by policy sources")
    axes[1, 0].set_ylabel("Policy source")

    _stacked_barh_percent_grouped(
        axes[1, 1],
        out_share,
        out_non_share,
        order=outbound_entities,
        palette=DOMAIN_PALETTE,
        xlabel="Domain share within cited research (normalized)",
        group_labels=("Korea policy docs", "Non-Korea policy docs"),
        show_legend=False,
        top_alpha=1.0,
        bottom_alpha=0.5,
        annotate=True,
    )
    axes[1, 1].set_title("D. Domains cited by Korea vs non-Korea policy documents")
    axes[1, 1].set_ylabel("Research country (first author)")

    from matplotlib.patches import Patch

    legend_handles = [
        Patch(facecolor=DOMAIN_PALETTE[d], label=DOMAIN_LEGEND_LABELS.get(d, d))
        for d in DOMAIN_ORDER
        if d in out_share.columns
    ]
    fig.legend(
        handles=legend_handles,
        loc="center",
        bbox_to_anchor=(0.53, 0.5),
        frameon=True,
        fancybox=True,
        framealpha=0.95,
        ncol=1,
        handlelength=1.2,
        fontsize=9,
    )

    fig.suptitle("Korea-related policy-research citation distributions (top 10)")
    _transparent(fig, [axes[0, 0], axes[0, 1], axes[1, 0], axes[1, 1]])

    out_png = out_dir / f"{run_tag}_korea_policy_research_flows_top10.png"
    save_report_figure(fig, out_png, dpi=200, transparent=True)
    plt.close(fig)
    return out_png, out_csv_path
