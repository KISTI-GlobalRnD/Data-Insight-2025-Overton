from __future__ import annotations

from pathlib import Path

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

from .common import (
    DOMAIN_ORDER,
    NEUTRAL_GRAY,
    REFERENCE_LINE,
    REFERENCE_TEXT,
    _add_edge_connectors,
    _adjust_text_with_keepout,
    _ellipsize,
    _fmt_short,
    _make_domain_palette,
    _set_theme,
    _transparent,
    save_report_figure,
)


def figure_3_topic_scatter(*, run_tag: str, in_dir: Path, out_dir: Path) -> tuple[Path, Path]:
    _doc_color, _core_primary, _text_color, _cmap = _set_theme()

    df = pd.read_csv(in_dir / f"{run_tag}_topic_metrics.csv")
    df = df.dropna(subset=["topic", "domain", "citation_rows", "unique_papers", "oa_share"]).copy()
    df = df[(df["citation_rows"] > 0) & (df["unique_papers"] > 0)].copy()
    df["oa_share"] = df["oa_share"].clip(0, 1)

    x_med = float(df["unique_papers"].median())
    y_med = float(df["citation_rows"].median())
    domain_order, domain_palette = _make_domain_palette(df["domain"])
    size_min, size_max = 20, 220

    fig, ax = plt.subplots(figsize=(9.2, 6.2))
    sns.scatterplot(
        data=df,
        x="unique_papers",
        y="citation_rows",
        hue="domain",
        size="oa_share",
        hue_order=domain_order or None,
        palette=domain_palette or None,
        sizes=(size_min, size_max),
        size_norm=(0, 1),
        alpha=0.75,
        linewidth=0,
        legend=False,
        zorder=2,
        ax=ax,
    )
    ax.xaxis.set_major_formatter(FuncFormatter(_fmt_short))
    ax.yaxis.set_major_formatter(FuncFormatter(_fmt_short))
    ax.axvline(x_med, ls="--", color=REFERENCE_LINE, alpha=0.7, zorder=1)
    ax.axhline(y_med, ls="--", color=REFERENCE_LINE, alpha=0.7, zorder=1)
    ax.set_title("Policy citations vs unique papers by topic")
    ax.set_xlabel("Unique papers")
    ax.set_ylabel("Policy citations")
    median_label_color = REFERENCE_TEXT
    ax.annotate(
        "Median unique papers",
        xy=(x_med, 0.02),
        xycoords=ax.get_xaxis_transform(),
        xytext=(0, -10),
        textcoords="offset points",
        ha="center",
        va="top",
        fontsize=8,
        color=median_label_color,
    )
    ax.annotate(
        "Median policy citations",
        xy=(0.02, y_med),
        xycoords=ax.get_yaxis_transform(),
        xytext=(0, -8),
        textcoords="offset points",
        ha="left",
        va="top",
        fontsize=8,
        color=median_label_color,
    )

    # Label: top-cited topics per domain (ensures non-Social Sciences domains are represented).
    label_parts: list[pd.DataFrame] = []
    for domain in [d for d in DOMAIN_ORDER if d in df["domain"].unique()]:
        label_parts.append(df[df["domain"] == domain].nlargest(5, "citation_rows"))
    label_df = pd.concat(label_parts, ignore_index=True).drop_duplicates(
        subset=["domain", "topic"], keep="first"
    ).copy()
    texts: list[plt.Text] = []
    points: list[tuple[float, float]] = []
    sizes: list[float] = []
    for _, row in label_df.iterrows():
        texts.append(
            ax.text(
                float(row["unique_papers"]),
                float(row["citation_rows"]),
                _ellipsize(row["topic"], 25),
                ha="right",
                va="center",
                fontsize=8,
                alpha=0.85,
            )
        )
        points.append((float(row["unique_papers"]), float(row["citation_rows"])))
        sizes.append(size_min + float(row["oa_share"]) * (size_max - size_min))

    _adjust_text_with_keepout(ax, texts, points, sizes=sizes, min_len_px=10)
    _add_edge_connectors(ax, texts, points, sizes=sizes)

    if domain_order:
        from matplotlib.lines import Line2D

        handles_domain = [
            Line2D(
                [0],
                [0],
                marker="o",
                linestyle="",
                markerfacecolor=domain_palette[d],
                markeredgecolor="none",
                markersize=8,
                label=d,
            )
            for d in domain_order
        ]
        legend_domain = ax.legend(handles=handles_domain, title="Domain", loc="upper left")
        ax.add_artist(legend_domain)

    size_levels = [0.2, 0.5, 0.8]
    handles_size = []
    for val in size_levels:
        size = size_min + val * (size_max - size_min)
        handles_size.append(ax.scatter([], [], s=size, color=NEUTRAL_GRAY, alpha=0.7, linewidth=0))
    ax.legend(
        handles=handles_size,
        labels=[f"{int(v * 100)}%" for v in size_levels],
        title="Open access share",
        loc="lower right",
        frameon=True,
    )

    _transparent(fig, [ax])
    fig.tight_layout()

    out_png = out_dir / f"{run_tag}_topic_scatter_citations_vs_papers.png"
    out_csv = out_dir / f"{run_tag}_topic_metrics.csv"
    df.to_csv(out_csv, index=False)
    save_report_figure(fig, out_png, dpi=200, transparent=True)
    plt.close(fig)
    return out_png, out_csv
