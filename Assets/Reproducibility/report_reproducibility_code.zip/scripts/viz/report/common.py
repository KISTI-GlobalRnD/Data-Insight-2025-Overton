from __future__ import annotations

import os
from pathlib import Path
from functools import lru_cache
from collections.abc import Sequence

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from matplotlib.colors import LinearSegmentedColormap, to_hex, to_rgb
from matplotlib.ticker import FuncFormatter

try:
    from country_domain_output_cache import openalex_output_shares_by_country_domain
except ModuleNotFoundError:  # imported as scripts.viz.report.common
    from scripts.country_domain_output_cache import openalex_output_shares_by_country_domain

try:
    import pycountry
except Exception:  # pragma: no cover - optional dependency in some envs
    pycountry = None


# Domain palette (reserved for domain-coded elements across the report).
NEUTRAL_GRAY = "#D6E3D8"
REFERENCE_LINE = "#B7CEC0"
REFERENCE_TEXT = "#6F8A7C"
SOFT_GRID = "#E4EFE8"
SOFT_SHADE = "#F2F7F3"
CORE_CATEG = ["#65CBA3", "#2CB1A6", "#F2B880", "#E07A5F", NEUTRAL_GRAY]

DOMAIN_ORDER = ["Social Sciences", "Health Sciences", "Physical Sciences", "Life Sciences"]
DOMAIN_PALETTE = {
    "Social Sciences": CORE_CATEG[0],
    "Health Sciences": CORE_CATEG[1],
    "Physical Sciences": CORE_CATEG[2],
    "Life Sciences": CORE_CATEG[3],
}
DOMAIN_LEGEND_LABELS = {
    "Social Sciences": "Social Sciences",
    "Health Sciences": "Health Sciences",
    "Physical Sciences": "Physical Sciences",
    "Life Sciences": "Life Sciences",
}

# Auxiliary palette (non-domain semantics). Keep distinct from DOMAIN_PALETTE to avoid meaning collisions.
AUX_CATEG = ["#2F7F6D", "#7FBF9F", "#D5B06A", "#C96C50", NEUTRAL_GRAY]
AUX_PRIMARY = AUX_CATEG[0]
AUX_SECONDARY = AUX_CATEG[1]
AUX_TERTIARY = AUX_CATEG[2]
AUX_HIGHLIGHT = AUX_CATEG[3]

SOURCE_TYPE_MAJOR_COLORS = {
    "government": AUX_PRIMARY,
    "igo": AUX_SECONDARY,
    "think tank": AUX_TERTIARY,
    "other": AUX_HIGHLIGHT,
}
SOURCE_TYPE_MAJOR_LABELS = {
    "government": "Government",
    "igo": "IGO",
    "think tank": "Think tank",
    "other": "Other",
}
SOURCE_TYPE_PART_LABELS = {
    "government": "Government",
    "igo": "IGO",
    "think tank": "Think tank",
    "other": "Other",
    "healthcare agency": "Healthcare agency",
    "development bank": "Development bank",
    "aggregator": "Aggregator",
    "agency": "Agency",
    "bank": "Bank",
    "research center": "Research center",
    "research centre": "Research centre",
    "university affiliated": "University affiliated",
    "city": "City government",
    "food and drug safety": "Food and drug safety agency",
    "legislative research": "Legislative research",
    "industry association": "Industry association",
    "consultancy": "Consultancy",
    "technology assessment": "Technology assessment",
    "legislation": "Legislation",
    "academy": "Academy",
    "transcripts": "Transcripts",
    "auditor": "Auditor",
    "armed forces": "Armed forces",
    "court": "Court",
    "professional association": "Professional association",
    "regional assembly": "Regional assembly",
}

KOREA_DISPLAY_LABEL = "Republic of Korea"
KOREA_LABEL_ALIASES = {"South Korea", "Korea", "Republic of Korea"}


@lru_cache(maxsize=1)
def _report_font_family() -> str:
    candidates = [
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Medium.ttc",
    ]
    for path_str in candidates:
        path = Path(path_str)
        if not path.exists():
            continue
        try:
            fm.fontManager.addfont(str(path))
            return fm.FontProperties(fname=str(path)).get_name()
        except Exception:
            continue
    return "DejaVu Sans"


def _set_theme() -> tuple[str, str, str, LinearSegmentedColormap]:
    report_font = _report_font_family()
    core_seq = AUX_CATEG
    core_primary = AUX_PRIMARY
    doc_color = AUX_SECONDARY
    grid_color = SOFT_GRID
    text_color = "#1F2933"

    cmap = LinearSegmentedColormap.from_list(
        "mint_yellow_white",
        ["#FFFFFF", "#FAF6EE", "#F3EBD2", "#E2EDE2", "#CFE5D8", "#9FD9BF", "#7DD4AF", "#3BB89D"],
    )

    sns.set_theme(
        style="whitegrid",
        rc={
            "font.family": report_font,
            "font.sans-serif": [report_font, "DejaVu Sans"],
            "axes.unicode_minus": False,
            "axes.edgecolor": grid_color,
            "grid.color": grid_color,
            "axes.labelcolor": text_color,
            "xtick.color": text_color,
            "ytick.color": text_color,
            "text.color": text_color,
            "legend.framealpha": 0.95,
            "legend.fancybox": True,
        },
    )
    sns.set_palette(core_seq)
    return doc_color, core_primary, text_color, cmap


def _transparent(fig: plt.Figure, axes: list[plt.Axes]) -> None:
    fig.patch.set_alpha(0)
    for ax in axes:
        ax.set_facecolor("none")


def _normalize_export_formats(export_formats: Sequence[str] | None = None) -> tuple[str, ...]:
    if export_formats is None:
        export_formats = os.environ.get("REPORT_FIGURE_EXPORT_FORMATS", "png").split(",")

    normalized: list[str] = []
    seen: set[str] = set()
    for fmt in export_formats:
        value = str(fmt).strip().lower().lstrip(".")
        if not value or value not in {"png", "svg", "pdf"} or value in seen:
            continue
        normalized.append(value)
        seen.add(value)
    return tuple(normalized or ["png"])


def save_report_figure(
    fig: plt.Figure,
    out_path: Path,
    *,
    dpi: int | None,
    transparent: bool = True,
    bbox_inches: str | None = None,
    pad_inches: float | None = None,
    export_formats: Sequence[str] | None = None,
) -> tuple[Path, ...]:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    savefig_kwargs: dict[str, object] = {"transparent": transparent}
    if bbox_inches is not None:
        savefig_kwargs["bbox_inches"] = bbox_inches
    if pad_inches is not None:
        savefig_kwargs["pad_inches"] = pad_inches
    if dpi is not None:
        savefig_kwargs["dpi"] = dpi

    saved_paths: list[Path] = []
    for fmt in _normalize_export_formats(export_formats):
        target = out_path.with_suffix(f".{fmt}")
        fig.savefig(target, **savefig_kwargs)
        saved_paths.append(target)
    return tuple(saved_paths)


def _fmt_short(x: float, _pos: int | None = None) -> str:
    if x >= 1_000_000:
        return f"{x/1_000_000:.1f}M"
    if x >= 1_000:
        return f"{x/1_000:.0f}K"
    return str(int(x))


def _tint(hex_color: str, amount: float) -> str:
    """Mix a color with white. amount=0 keeps original, amount=1 becomes white."""
    r, g, b = to_rgb(hex_color)
    amount = float(np.clip(amount, 0.0, 1.0))
    r2 = r + (1.0 - r) * amount
    g2 = g + (1.0 - g) * amount
    b2 = b + (1.0 - b) * amount
    return to_hex((r2, g2, b2))


def _make_domain_palette(domains: pd.Series) -> tuple[list[str], dict[str, str]]:
    domain_series = pd.Series(domains).dropna()
    domain_series = domain_series.astype(str).str.strip()
    domain_series = domain_series[domain_series.ne("")]
    unique = set(domain_series.unique())
    if not unique:
        return [], {}

    order = [d for d in DOMAIN_ORDER if d in unique]
    extras = sorted(unique.difference(set(DOMAIN_ORDER)))
    if "Unknown" in extras:
        extras = [d for d in extras if d != "Unknown"] + ["Unknown"]
    order.extend([d for d in extras if d])

    palette: dict[str, str] = {}
    for d in order:
        palette[d] = DOMAIN_PALETTE.get(d, NEUTRAL_GRAY)
    return order, palette


def _display_source_type_label(label: object, *, compact: bool = False) -> str:
    import re

    text = str(label).strip()
    if not text:
        return text
    parts = [p.strip() for p in re.split(r"(?:>|›|»|→|＞)", text) if p.strip()]
    translated = [SOURCE_TYPE_PART_LABELS.get(part.lower(), part) for part in parts]
    if compact and len(translated) >= 2:
        return translated[-1]
    return " > ".join(translated)


def _row_normalize(pivot: pd.DataFrame) -> pd.DataFrame:
    totals = pivot.sum(axis=1).replace(0, np.nan)
    return pivot.div(totals, axis=0).fillna(0)


def _ccdf_from_counts(counts: pd.Series) -> pd.DataFrame:
    counts = pd.to_numeric(counts, errors="coerce").dropna()
    counts = counts[counts > 0].astype(int)
    if counts.empty:
        return pd.DataFrame({"x": [], "ccdf": []})
    values, freq = np.unique(counts.to_numpy(), return_counts=True)
    order = np.argsort(values)
    values = values[order]
    freq = freq[order]
    total = freq.sum()
    ccdf = np.cumsum(freq[::-1])[::-1] / total
    return pd.DataFrame({"x": values, "ccdf": ccdf})


def _stacked_barh_percent(
    ax: plt.Axes,
    shares: pd.DataFrame,
    *,
    order: list[str],
    palette: dict[str, str],
    xlabel: str,
    show_legend: bool = True,
    legend_loc: str = "lower right",
    legend_alpha: float = 0.95,
    legend_ncol: int = 1,
    legend_handlelength: float = 1.8,
    legend_fontsize: float = 10,
) -> None:
    shares = shares.reindex(order).fillna(0)
    left = np.zeros(len(order), dtype=float)
    for col in shares.columns:
        vals = shares[col].to_numpy(dtype=float)
        if np.allclose(vals, 0):
            continue
        ax.barh(order, vals, left=left, color=palette.get(col, NEUTRAL_GRAY), label=col)
        left += vals

    ax.set_xlim(0, 1)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _pos=None: f"{x:.0%}"))
    ax.set_xlabel(xlabel)
    ax.xaxis.grid(True)
    ax.yaxis.grid(False)
    if show_legend:
        ax.legend(
            loc=legend_loc,
            frameon=True,
            fancybox=True,
            framealpha=legend_alpha,
            title="",
            ncol=legend_ncol,
            handlelength=legend_handlelength,
            fontsize=legend_fontsize,
        )


def _contrast_text_color(hex_color: str) -> str:
    r, g, b = to_rgb(hex_color)
    luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
    return "#FFFFFF" if luminance < 0.55 else "#1F2933"


def _annotate_stacked_barh_percent(
    ax: plt.Axes,
    shares: pd.DataFrame,
    *,
    order: list[str],
    palette: dict[str, str],
    inside_threshold: float = 0.08,
    outside_pad: float = 0.012,
) -> None:
    shares = shares.reindex(order).fillna(0)
    left = np.zeros(len(order), dtype=float)
    for col in shares.columns:
        vals = shares[col].to_numpy(dtype=float)
        if np.allclose(vals, 0):
            continue
        left_prev = left.copy()
        left += vals

        for i, (val, base_left) in enumerate(zip(vals, left_prev)):
            if not np.isfinite(val) or val <= 0:
                continue
            label = f"{val * 100:.1f}%" if val * 100 < 1 else f"{val * 100:.0f}%"
            x_center = float(base_left + val / 2.0)
            y_center = float(i)

            if val >= inside_threshold:
                ax.text(
                    x_center,
                    y_center,
                    label,
                    ha="center",
                    va="center",
                    fontsize=8,
                    color=_contrast_text_color(palette.get(col, NEUTRAL_GRAY)),
                    zorder=5,
                )
                continue

            seg_end = float(base_left + val)
            left_space = float(base_left)
            right_space = float(1.0 - seg_end)
            # Small segments at the far right are easiest to read when labeled outside the bar.
            if seg_end >= 0.85:
                place_right = True
            elif base_left <= 0.15:
                place_right = False
            else:
                place_right = right_space >= left_space
            if place_right:
                x_text = float(seg_end + outside_pad)
                ha = "left"
            else:
                x_text = float(base_left - outside_pad)
                ha = "right"

            ax.annotate(
                label,
                xy=(x_center, y_center),
                xytext=(x_text, y_center),
                textcoords="data",
                ha=ha,
                va="center",
                fontsize=8,
                color="#1F2933",
                arrowprops=dict(arrowstyle="-", color=REFERENCE_LINE, lw=0.8),
                clip_on=False,
                zorder=6,
            )


def _stacked_barh_percent_grouped(
    ax: plt.Axes,
    shares_top: pd.DataFrame,
    shares_bottom: pd.DataFrame,
    *,
    order: list[str],
    palette: dict[str, str],
    xlabel: str,
    group_labels: tuple[str, str],
    show_legend: bool = True,
    legend_loc: str = "lower right",
    legend_alpha: float = 0.95,
    legend_ncol: int = 1,
    legend_handlelength: float = 1.8,
    legend_fontsize: float = 10,
    top_alpha: float = 1.0,
    bottom_alpha: float = 0.7,
    bar_height: float = 0.34,
    gap: float = 0.08,
    annotate: bool = False,
    inside_threshold: float = 0.06,
) -> None:
    shares_top = shares_top.reindex(order).fillna(0)
    shares_bottom = shares_bottom.reindex(order).fillna(0)
    cols = list(shares_top.columns)

    y = np.arange(len(order), dtype=float)
    offset = (bar_height + gap) / 2.0
    y_top = y + offset
    y_bottom = y - offset

    left_top = np.zeros(len(order), dtype=float)
    left_bottom = np.zeros(len(order), dtype=float)
    for col in cols:
        vals_top = shares_top[col].to_numpy(dtype=float)
        vals_bottom = shares_bottom[col].to_numpy(dtype=float)
        color = palette.get(col, NEUTRAL_GRAY)

        ax.barh(
            y_top,
            vals_top,
            left=left_top,
            height=bar_height,
            color=color,
            alpha=top_alpha,
            label=col if show_legend else "_nolegend_",
        )
        ax.barh(
            y_bottom,
            vals_bottom,
            left=left_bottom,
            height=bar_height,
            color=color,
            alpha=bottom_alpha,
            label="_nolegend_",
        )
        left_top += vals_top
        left_bottom += vals_bottom

    if annotate:

        def _annotate(shares: pd.DataFrame, y_positions: np.ndarray) -> None:
            left = np.zeros(len(order), dtype=float)
            for col in cols:
                vals = shares[col].to_numpy(dtype=float)
                if np.allclose(vals, 0):
                    left += vals
                    continue
                left_prev = left.copy()
                left += vals
                for i, (val, base_left) in enumerate(zip(vals, left_prev)):
                    if not np.isfinite(val) or val <= 0:
                        continue
                    label = f"{val * 100:.1f}%" if val * 100 < 1 else f"{val * 100:.0f}%"
                    x_center = float(base_left + val / 2.0)
                    y_center = float(y_positions[i])
                    color = _contrast_text_color(palette.get(col, NEUTRAL_GRAY))
                    fontsize = 8 if val >= inside_threshold else 7
                    ax.text(
                        x_center,
                        y_center,
                        label,
                        ha="center",
                        va="center",
                        fontsize=fontsize,
                        color=color,
                        zorder=6,
                    )

        _annotate(shares_top, y_top)
        _annotate(shares_bottom, y_bottom)

    ax.set_xlim(0, 1)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _pos=None: f"{x:.0%}"))
    ax.set_xlabel(xlabel)
    ax.xaxis.grid(True)
    ax.yaxis.grid(False)

    ax.set_yticks(y)
    ax.set_yticklabels(order)

    ax.text(
        0.0,
        0.985,
        f"Upper: {group_labels[0]} · Lower: {group_labels[1]}",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=9,
        color=REFERENCE_TEXT,
    )

    if show_legend:
        ax.legend(
            loc=legend_loc,
            frameon=True,
            fancybox=True,
            framealpha=legend_alpha,
            title="",
            ncol=legend_ncol,
            handlelength=legend_handlelength,
            fontsize=legend_fontsize,
        )


def _sql_quote(value: object) -> str:
    text = "" if value is None else str(value)
    return "'" + text.replace("'", "''") + "'"


def _ellipsize(value: object, max_chars: int = 25) -> str:
    if value is None:
        return ""
    try:
        is_missing = pd.isna(value)
    except Exception:
        is_missing = False
    if isinstance(is_missing, bool) and is_missing:
        return ""
    text = str(value)
    if len(text) <= max_chars:
        return text
    if max_chars <= 3:
        return text[:max_chars]
    return text[: max_chars - 3].rstrip() + "..."


def _adjust_text_with_keepout(
    ax: plt.Axes,
    texts: list[plt.Text],
    points: list[tuple[float, float]],
    *,
    sizes: list[float] | None = None,
    min_len_px: float = 10,
    expand_points: tuple[float, float] = (1.2, 1.4),
    expand_text: tuple[float, float] = (1.1, 1.2),
    only_move: dict[str, str] | None = None,
    lim: int = 200,
) -> bool:
    try:
        from adjustText import adjust_text  # type: ignore
    except Exception:
        return False

    import matplotlib as mpl
    from matplotlib.patches import Ellipse

    fig = ax.figure
    fig.canvas.draw()
    dpi = fig.dpi

    if sizes is None:
        default_s = mpl.rcParams["lines.markersize"] ** 2
        sizes = [default_s] * len(points)

    keepouts: list[Ellipse] = []
    if min_len_px:
        for (x, y), s in zip(points, sizes):
            radius_px = (s**0.5) / 2 * dpi / 72
            keepout_px = radius_px + float(min_len_px)

            center_disp = ax.transData.transform((x, y))
            right_data = ax.transData.inverted().transform((center_disp[0] + keepout_px, center_disp[1]))
            up_data = ax.transData.inverted().transform((center_disp[0], center_disp[1] + keepout_px))

            dx = abs(right_data[0] - x)
            dy = abs(up_data[1] - y)
            if dx == 0 or dy == 0:
                continue

            e = Ellipse(
                (x, y),
                width=2 * dx,
                height=2 * dy,
                facecolor="none",
                edgecolor="none",
                lw=0,
                alpha=0.0,
            )
            ax.add_patch(e)
            keepouts.append(e)

    xs = [p[0] for p in points]
    ys = [p[1] for p in points]

    if only_move is None:
        only_move = {"points": "xy", "text": "xy"}

    adjust_text(
        texts,
        x=xs,
        y=ys,
        objects=keepouts,
        ax=ax,
        expand_points=expand_points,
        expand_text=expand_text,
        only_move=only_move,
        lim=lim,
    )

    for e in keepouts:
        e.remove()

    return True


def _add_edge_connectors(
    ax: plt.Axes,
    texts: list[plt.Text],
    points: list[tuple[float, float]],
    *,
    sizes: list[float] | None = None,
    color: str = REFERENCE_LINE,
    lw: float = 0.8,
    alpha: float = 0.9,
    pad_x_px: float = 8,
    pad_y_px: float = 2,
    side: str = "auto",
) -> None:
    import matplotlib as mpl
    from matplotlib.transforms import Bbox

    fig = ax.figure
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    dpi = fig.dpi

    if sizes is None:
        default_s = mpl.rcParams["lines.markersize"] ** 2
        sizes = [default_s] * len(points)

    for text, (x, y), s in zip(texts, points, sizes):
        radius_px = (s**0.5) / 2 * dpi / 72
        point_disp = ax.transData.transform((x, y))

        bbox = text.get_window_extent(renderer=renderer)
        x0, y0, x1, y1 = bbox.x0, bbox.y0, bbox.x1, bbox.y1
        if pad_x_px and (x1 - x0) > 2 * pad_x_px:
            x0 += pad_x_px
            x1 -= pad_x_px
        if pad_y_px and (y1 - y0) > 2 * pad_y_px:
            y0 += pad_y_px
            y1 -= pad_y_px
        bbox = Bbox.from_extents(x0, y0, x1, y1)

        if side == "left":
            anchor_x = bbox.x0
            anchor_y = min(max(point_disp[1], bbox.y0), bbox.y1)
        elif side == "right":
            anchor_x = bbox.x1
            anchor_y = min(max(point_disp[1], bbox.y0), bbox.y1)
        else:
            anchor_x = min(max(point_disp[0], bbox.x0), bbox.x1)
            anchor_y = min(max(point_disp[1], bbox.y0), bbox.y1)
            if bbox.x0 < point_disp[0] < bbox.x1 and bbox.y0 < point_disp[1] < bbox.y1:
                d_left = point_disp[0] - bbox.x0
                d_right = bbox.x1 - point_disp[0]
                d_bottom = point_disp[1] - bbox.y0
                d_top = bbox.y1 - point_disp[1]
                min_d = min(d_left, d_right, d_bottom, d_top)
                if min_d == d_left:
                    anchor_x = bbox.x0
                    anchor_y = point_disp[1]
                elif min_d == d_right:
                    anchor_x = bbox.x1
                    anchor_y = point_disp[1]
                elif min_d == d_bottom:
                    anchor_y = bbox.y0
                    anchor_x = point_disp[0]
                else:
                    anchor_y = bbox.y1
                    anchor_x = point_disp[0]

        anchor_disp = np.array([anchor_x, anchor_y])
        vec = anchor_disp - point_disp
        dist = float(np.hypot(vec[0], vec[1]))

        if dist > 0:
            edge_radius = min(radius_px, dist * 0.95)
            edge_disp = point_disp + (vec / dist) * edge_radius
        else:
            edge_disp = point_disp

        edge_data = ax.transData.inverted().transform(edge_disp)
        anchor_data = ax.transData.inverted().transform(anchor_disp)

        ax.plot(
            [edge_data[0], anchor_data[0]],
            [edge_data[1], anchor_data[1]],
            color=color,
            lw=lw,
            alpha=alpha,
            zorder=text.get_zorder() - 0.1,
            solid_capstyle="round",
            clip_on=False,
        )


def _iso2_to_label() -> dict[str, str]:
    mapping = {
        "US": "USA",
        "GB": "UK",
        "KR": KOREA_DISPLAY_LABEL,
        "TW": "Taiwan",
        "RU": "Russia",
        "IR": "Iran",
        "TR": "Turkey",
        "HK": "Hong Kong",
        "SY": "Syria",
        "LA": "Laos",
        "VN": "Vietnam",
        "MD": "Moldova",
    }
    if pycountry is not None:
        for country in pycountry.countries:
            alpha_2 = getattr(country, "alpha_2", None)
            name = getattr(country, "name", None)
            if alpha_2 and name and alpha_2 not in mapping:
                mapping[alpha_2] = name
    return mapping


def _policy_country_label(raw: str) -> str | None:
    raw = str(raw).strip()
    if not raw:
        return None
    if raw in KOREA_LABEL_ALIASES:
        return KOREA_DISPLAY_LABEL
    return raw


def _display_country_label(raw: str) -> str:
    raw = str(raw).strip()
    if not raw:
        return raw
    if raw in KOREA_LABEL_ALIASES:
        return KOREA_DISPLAY_LABEL
    overrides = {
        "United States": "USA",
        "United States of America": "USA",
        "United Kingdom": "UK",
        "Russian Federation": "Russia",
        "Iran, Islamic Republic of": "Iran",
        "Türkiye": "Turkey",
        "Taiwan, Province of China": "Taiwan",
        "Korea, Republic of": KOREA_DISPLAY_LABEL,
        "Hong Kong SAR China": "Hong Kong",
        "Syrian Arab Republic": "Syria",
        "Lao People's Democratic Republic": "Laos",
        "Viet Nam": "Vietnam",
        "Moldova, Republic of": "Moldova",
    }
    if raw in overrides:
        return overrides[raw]
    if raw == "United States":
        return "USA"
    if raw == "United Kingdom":
        return "UK"
    return raw


def _policy_to_iso2() -> dict[str, str]:
    return {
        "USA": "US",
        "UK": "GB",
        "Germany": "DE",
        "France": "FR",
        "Canada": "CA",
        "Australia": "AU",
        "Sweden": "SE",
        "Netherlands": "NL",
        "Finland": "FI",
        "Ireland": "IE",
        "Spain": "ES",
        "Italy": "IT",
        "Japan": "JP",
        "Brazil": "BR",
        "Switzerland": "CH",
        "Norway": "NO",
        "Denmark": "DK",
        "New Zealand": "NZ",
        "Austria": "AT",
        "Belgium": "BE",
        "Korea": "KR",
        "South Korea": "KR",
        "Republic of Korea": "KR",
        "China": "CN",
        "India": "IN",
    }


def _openalex_output_shares_by_country_domain(*, domains: list[str], cache_csv: Path) -> pd.DataFrame:
    """Country×domain shares within the DOI-linked article sample.

    Notes
    - Uses `Data/matched_openalex_with_oa_country_unique.parquet` (unique per work) joined with
      `Data/openalex_topics.parquet`.
    - Counts each work at most once per domain so results are not weighted by the number of topics
      assigned within the same domain.
    - This is a reference composition for the linked sample, not a measure of total OpenAlex output.
    """
    return openalex_output_shares_by_country_domain(domains=domains, cache_csv=cache_csv)
