#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import random
from pathlib import Path

import numpy as np
import pandas as pd
from matplotlib.colors import to_rgb

try:
    from country_domain_output_cache import openalex_output_shares_by_country_domain
except ModuleNotFoundError:  # imported as scripts.make_landing_figures
    from scripts.country_domain_output_cache import openalex_output_shares_by_country_domain


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Generate landing-page (dark theme) figure variants into "
            "Data_Insight/Assets/Landing/ from Output/Data_Insight inputs."
        )
    )
    parser.add_argument(
        "--run-tag",
        default=os.environ.get("RUN_TAG", "20251026"),
        help="Input filename prefix (default: env RUN_TAG or 20251026).",
    )
    parser.add_argument(
        "--in-dir",
        type=Path,
        default=Path("Output/Data_Insight"),
        help="Directory containing input CSVs (default: Output/Data_Insight).",
    )
    parser.add_argument(
        "--report-figures-dir",
        type=Path,
        default=Path("Output/Data_Insight/report_figures"),
        help="Directory containing report_figures CSVs (default: Output/Data_Insight/report_figures).",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("Data_Insight/Assets/Landing"),
        help="Directory to write landing PNG files (default: Data_Insight/Assets/Landing).",
    )
    parser.add_argument(
        "--network-layout-seed",
        type=int,
        default=int(os.environ.get("NETWORK_LAYOUT_SEED", "2026")),
        help="Seed for the network layout algorithms (default: env NETWORK_LAYOUT_SEED or 2026).",
    )
    return parser.parse_args()


TEXT = "#EEF7F2"
MUTED = (238 / 255, 247 / 255, 242 / 255, 0.72)
GRID = (183 / 255, 206 / 255, 192 / 255, 0.12)

CORE_PRIMARY = "#65CBA3"
POLICY_ONLY = "#2CB1A6"
RESEARCH_ONLY = "#F2B880"
KOREA = "#E07A5F"
NEUTRAL_GRAY = "#D6E3D8"
AUX_PRIMARY = "#2F7F6D"
AUX_SECONDARY = "#7FBF9F"
AUX_TERTIARY = "#D5B06A"
AUX_HIGHLIGHT = "#C96C50"

DOMAIN_ORDER = ["Social Sciences", "Health Sciences", "Physical Sciences", "Life Sciences"]
DOMAIN_PALETTE = {
    "Social Sciences": CORE_PRIMARY,
    "Health Sciences": POLICY_ONLY,
    "Physical Sciences": RESEARCH_ONLY,
    "Life Sciences": KOREA,
}
DOMAIN_LEGEND_LABELS = {
    "Social Sciences": "Social\nSciences",
    "Health Sciences": "Health\nSciences",
    "Physical Sciences": "Physical\nSciences",
    "Life Sciences": "Life\nSciences",
}


def _save(fig, out_path: Path, *, tight: bool = True) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    kwargs = {"dpi": 300, "transparent": True}
    if tight:
        kwargs.update({"bbox_inches": "tight", "pad_inches": 0.06})
    fig.savefig(out_path, **kwargs)


def _apply_dark_axes(ax, *, grid: bool = True, grid_axis: str = "both") -> None:
    ax.set_facecolor("none")
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(colors=TEXT, labelcolor=TEXT)
    ax.xaxis.label.set_color(TEXT)
    ax.yaxis.label.set_color(TEXT)
    ax.title.set_color(TEXT)
    if grid:
        ax.grid(True, color=GRID, linewidth=0.8, alpha=0.6, axis=grid_axis)
    else:
        ax.grid(False)


def _tick_compact(x, _pos=None) -> str:
    x = float(x)
    abs_x = abs(x)
    if abs_x >= 1_000_000:
        return f"{x/1_000_000:.1f}M"
    if abs_x >= 1_000:
        return f"{x/1_000:.0f}k"
    return f"{x:.0f}"


def _fmt_short(x: float, _pos: int | None = None) -> str:
    if x >= 1_000_000:
        return f"{x/1_000_000:.1f}M"
    if x >= 1_000:
        return f"{x/1_000:.0f}K"
    return f"{int(x)}"


def _tint(hex_color: str, amount: float) -> str:
    """Mix a color with white. amount=0 keeps original, amount=1 becomes white."""
    r, g, b = to_rgb(hex_color)
    amount = float(np.clip(amount, 0.0, 1.0))
    r2 = r + (1.0 - r) * amount
    g2 = g + (1.0 - g) * amount
    b2 = b + (1.0 - b) * amount
    return (r2, g2, b2)


def _iso2_to_label() -> dict[str, str]:
    return {
        "US": "USA",
        "GB": "UK",
        "DE": "Germany",
        "FR": "France",
        "CA": "Canada",
        "AU": "Australia",
        "NL": "Netherlands",
        "ES": "Spain",
        "IT": "Italy",
        "CN": "China",
        "SE": "Sweden",
        "CH": "Switzerland",
        "DK": "Denmark",
        "NO": "Norway",
        "FI": "Finland",
        "IE": "Ireland",
        "NZ": "New Zealand",
        "AT": "Austria",
        "IN": "India",
        "KR": "South Korea",
        "JP": "Japan",
        "BR": "Brazil",
        "BE": "Belgium",
        "ZA": "South Africa",
        "IL": "Israel",
        "TW": "Taiwan",
        "HK": "Hong Kong",
        "TR": "Turkey",
        "PT": "Portugal",
        "GR": "Greece",
        "MX": "Mexico",
        "AR": "Argentina",
        "IR": "Iran",
        "CL": "Chile",
        "SG": "Singapore",
        "PL": "Poland",
        "ID": "Indonesia",
        "RU": "Russia",
        "TH": "Thailand",
        "CZ": "Czech Republic",
        "KE": "Kenya",
        "PE": "Peru",
        "MY": "Malaysia",
        "CO": "Colombia",
        "PK": "Pakistan",
        "EG": "Egypt",
        "NG": "Nigeria",
        "HU": "Hungary",
    }


def _policy_country_label(raw: str) -> str | None:
    raw = str(raw)
    if ">" not in raw:
        return raw
    raw_norm = raw.strip()
    if raw_norm == "China > Hong Kong":
        return "Hong Kong"
    if raw_norm == "USA > Georgia":
        return "Georgia (USA)"
    return None


def _label_overrides() -> dict[str, str]:
    return {
        "USA": "United\nStates",
        "UK": "United\nKingdom",
        "EU": "European\nUnion",
        "IGO": "International\norganizations",
    }


def _ellipsize(text: str, max_chars: int) -> str:
    text = str(text)
    if max_chars <= 3 or len(text) <= max_chars:
        return text
    return text[: max_chars - 1].rstrip() + "…"


def _row_normalize(pivot: pd.DataFrame) -> pd.DataFrame:
    totals = pivot.sum(axis=1).replace(0, np.nan)
    return pivot.div(totals, axis=0).fillna(0)


def _contrast_text_color(hex_color: str) -> str:
    r, g, b = to_rgb(hex_color)
    luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
    return "#FFFFFF" if luminance < 0.55 else "#1F2933"


def _stacked_barh_percent(
    ax,
    shares: pd.DataFrame,
    *,
    order: list[str],
    palette: dict[str, str],
    xlabel: str,
    show_legend: bool = True,
    legend_loc: str = "lower right",
    legend_alpha: float = 0.12,
    legend_ncol: int = 1,
    legend_handlelength: float = 1.8,
    legend_fontsize: float = 10,
) -> None:
    from matplotlib.ticker import FuncFormatter

    shares = shares.reindex(order).fillna(0)
    left = np.zeros(len(order), dtype=float)
    for col in shares.columns:
        vals = shares[col].to_numpy(dtype=float)
        if np.allclose(vals, 0):
            continue
        ax.barh(order, vals, left=left, color=palette.get(col, NEUTRAL_GRAY), label=col if show_legend else "_nolegend_")
        left += vals

    ax.set_xlim(0, 1)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _pos=None: f"{x:.0%}"))
    ax.set_xlabel(xlabel)
    ax.xaxis.grid(True)
    ax.yaxis.grid(False)
    if show_legend:
        legend = ax.legend(
            loc=legend_loc,
            frameon=True,
            fancybox=True,
            framealpha=legend_alpha,
            title="",
            ncol=legend_ncol,
            handlelength=legend_handlelength,
            fontsize=legend_fontsize,
        )
        if legend:
            for text in legend.get_texts():
                text.set_color(TEXT)
            frame = legend.get_frame()
            frame.set_facecolor((0, 0, 0, 0.25))
            frame.set_edgecolor((1, 1, 1, 0.18))


def _annotate_stacked_barh_percent(
    ax,
    shares: pd.DataFrame,
    *,
    order: list[str],
    palette: dict[str, str],
    inside_threshold: float = 0.08,
    outside_pad: float = 0.012,
) -> None:
    shares = shares.reindex(order).fillna(0)
    left = np.zeros(len(order), dtype=float)
    for col in shares.columns:
        vals = shares[col].to_numpy(dtype=float)
        if np.allclose(vals, 0):
            continue
        left_prev = left.copy()
        left += vals

        for i, (val, base_left) in enumerate(zip(vals, left_prev)):
            if not np.isfinite(val) or val <= 0:
                continue
            label = f"{val * 100:.1f}%" if val * 100 < 1 else f"{val * 100:.0f}%"
            x_center = float(base_left + val / 2.0)
            y_center = float(i)

            if val >= inside_threshold:
                ax.text(
                    x_center,
                    y_center,
                    label,
                    ha="center",
                    va="center",
                    fontsize=8,
                    color=_contrast_text_color(palette.get(col, NEUTRAL_GRAY)),
                    zorder=5,
                )
                continue

            seg_end = float(base_left + val)
            left_space = float(base_left)
            right_space = float(1.0 - seg_end)
            if seg_end >= 0.85:
                place_right = True
            elif base_left <= 0.15:
                place_right = False
            else:
                place_right = right_space >= left_space
            if place_right:
                x_text = float(seg_end + outside_pad)
                ha = "left"
            else:
                x_text = float(base_left - outside_pad)
                ha = "right"

            ax.annotate(
                label,
                xy=(x_center, y_center),
                xytext=(x_text, y_center),
                textcoords="data",
                ha=ha,
                va="center",
                fontsize=8,
                color=TEXT,
                arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.8),
                clip_on=False,
                zorder=6,
            )


def _stacked_barh_percent_grouped(
    ax,
    shares_top: pd.DataFrame,
    shares_bottom: pd.DataFrame,
    *,
    order: list[str],
    palette: dict[str, str],
    xlabel: str,
    group_labels: tuple[str, str],
    show_legend: bool = True,
    legend_loc: str = "lower right",
    legend_alpha: float = 0.12,
    legend_ncol: int = 1,
    legend_handlelength: float = 1.8,
    legend_fontsize: float = 10,
    top_alpha: float = 1.0,
    bottom_alpha: float = 0.7,
    bar_height: float = 0.34,
    gap: float = 0.08,
    annotate: bool = False,
    inside_threshold: float = 0.06,
) -> None:
    from matplotlib.ticker import FuncFormatter

    shares_top = shares_top.reindex(order).fillna(0)
    shares_bottom = shares_bottom.reindex(order).fillna(0)
    cols = list(shares_top.columns)

    y = np.arange(len(order), dtype=float)
    offset = (bar_height + gap) / 2.0
    y_top = y + offset
    y_bottom = y - offset

    left_top = np.zeros(len(order), dtype=float)
    left_bottom = np.zeros(len(order), dtype=float)
    for col in cols:
        vals_top = shares_top[col].to_numpy(dtype=float)
        vals_bottom = shares_bottom[col].to_numpy(dtype=float)
        color = palette.get(col, NEUTRAL_GRAY)

        ax.barh(
            y_top,
            vals_top,
            left=left_top,
            height=bar_height,
            color=color,
            alpha=top_alpha,
            label=col if show_legend else "_nolegend_",
        )
        ax.barh(
            y_bottom,
            vals_bottom,
            left=left_bottom,
            height=bar_height,
            color=color,
            alpha=bottom_alpha,
            label="_nolegend_",
        )
        left_top += vals_top
        left_bottom += vals_bottom

    if annotate:

        def _annotate(shares: pd.DataFrame, y_positions: np.ndarray) -> None:
            left = np.zeros(len(order), dtype=float)
            for col in cols:
                vals = shares[col].to_numpy(dtype=float)
                if np.allclose(vals, 0):
                    left += vals
                    continue
                left_prev = left.copy()
                left += vals
                for i, (val, base_left) in enumerate(zip(vals, left_prev)):
                    if not np.isfinite(val) or val <= 0:
                        continue
                    label = f"{val * 100:.1f}%" if val * 100 < 1 else f"{val * 100:.0f}%"
                    x_center = float(base_left + val / 2.0)
                    y_center = float(y_positions[i])
                    color = _contrast_text_color(palette.get(col, NEUTRAL_GRAY))
                    fontsize = 8 if val >= inside_threshold else 7
                    ax.text(
                        x_center,
                        y_center,
                        label,
                        ha="center",
                        va="center",
                        fontsize=fontsize,
                        color=color,
                        zorder=6,
                    )

        _annotate(shares_top, y_top)
        _annotate(shares_bottom, y_bottom)

    ax.set_xlim(0, 1)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _pos=None: f"{x:.0%}"))
    ax.set_xlabel(xlabel)
    ax.xaxis.grid(True)
    ax.yaxis.grid(False)

    ax.set_yticks(y)
    ax.set_yticklabels(order)

    ax.text(
        0.0,
        0.985,
        f"Upper: {group_labels[0]} · Lower: {group_labels[1]}",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=9,
        color=MUTED,
    )

    if show_legend:
        legend = ax.legend(
            loc=legend_loc,
            frameon=True,
            fancybox=True,
            framealpha=legend_alpha,
            title="",
            ncol=legend_ncol,
            handlelength=legend_handlelength,
            fontsize=legend_fontsize,
        )
        if legend:
            for text in legend.get_texts():
                text.set_color(TEXT)
            frame = legend.get_frame()
            frame.set_facecolor((0, 0, 0, 0.22))
            frame.set_edgecolor((1, 1, 1, 0.18))


def _openalex_output_shares_by_country_domain(*, domains: list[str], cache_csv: Path) -> pd.DataFrame:
    """Country×domain reference shares within the DOI-linked article sample."""
    return openalex_output_shares_by_country_domain(domains=domains, cache_csv=cache_csv)


def fig_pubyear_trend(*, run_tag: str, in_dir: Path, out_dir: Path, report_figures_dir: Path | None = None) -> Path:
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FuncFormatter

    metrics_path = None
    if report_figures_dir is not None:
        candidate = report_figures_dir / f"{run_tag}_pubyear_trend_metrics.csv"
        if candidate.exists():
            metrics_path = candidate
    if metrics_path is None:
        metrics_path = in_dir / f"{run_tag}_pubyear_trend_metrics.csv"

    df = pd.read_csv(metrics_path)
    df = df.dropna(subset=["year"]).copy()

    plt.rcParams.update({"font.size": 11})
    fig, (ax_top, ax_bot) = plt.subplots(
        2,
        1,
        figsize=(10.6, 6.6),
        sharex=True,
        gridspec_kw={"height_ratios": [0.66, 0.34], "hspace": 0.22},
    )

    line_cit = ax_top.plot(
        df["year"],
        df["citations"],
        color=CORE_PRIMARY,
        linewidth=2.8,
        marker="o",
        markersize=3.8,
        label="Policy citations (count)",
    )
    ax_top.set_ylabel("Policy citations")
    ax_top.yaxis.set_major_formatter(FuncFormatter(_fmt_short))
    _apply_dark_axes(ax_top)

    ax_top2 = ax_top.twinx()
    line_docs = ax_top2.plot(
        df["year"],
        df["policy_docs"],
        color=AUX_PRIMARY,
        linewidth=2.4,
        marker="o",
        markersize=3.5,
        alpha=0.95,
        label="Policy documents (with DOI citations)",
    )
    ax_top2.set_ylabel("Policy documents")
    ax_top2.tick_params(colors=TEXT, labelcolor=TEXT)
    ax_top2.yaxis.label.set_color(TEXT)
    ax_top2.yaxis.set_major_formatter(FuncFormatter(_fmt_short))
    for spine in ax_top2.spines.values():
        spine.set_visible(False)

    legend = ax_top.legend(
        [line_cit[0], line_docs[0]],
        ["Policy citations (count)", "Policy documents (with DOI citations)"],
        loc="upper left",
        frameon=True,
        fancybox=True,
        framealpha=0.12,
    )
    if legend:
        for text in legend.get_texts():
            text.set_color(TEXT)
        legend.get_frame().set_facecolor((0, 0, 0, 0.22))
        legend.get_frame().set_edgecolor((1, 1, 1, 0.18))

    ax_bot.plot(df["year"], df["citations_per_doc"], color=RESEARCH_ONLY, linewidth=2.6, marker="o", markersize=3.6)
    ax_bot.set_ylabel("Avg citations / doc")
    ax_bot.set_xlabel("Publication year (policy documents)")
    _apply_dark_axes(ax_bot)

    years = df["year"].astype(int)
    max_year = int(years.max()) if len(years) else None
    cutoff_year = 2022 if max_year and max_year >= 2022 else max_year
    if cutoff_year:
        for ax in (ax_top, ax_bot):
            ax.axvspan(cutoff_year - 0.5, max_year + 0.5, color=(1, 1, 1, 0.06), zorder=0)
        ax_top.text(
            0.99,
            0.02,
            "Recent years (incomplete)",
            transform=ax_top.transAxes,
            ha="right",
            va="bottom",
            fontsize=8,
            color=MUTED,
        )

    fig.patch.set_alpha(0.0)
    out_path = out_dir / "pubyear_trend.png"
    _save(fig, out_path)
    plt.close(fig)
    return out_path


def fig_korea_flows(
    *, run_tag: str, in_dir: Path, out_dir: Path, report_figures_dir: Path | None = None
) -> Path:
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FuncFormatter

    flow = pd.read_csv(
        in_dir / f"{run_tag}_policy_country_research_country.csv",
        keep_default_na=False,
    )
    flow["research_country"] = flow["research_country"].fillna("").astype(str).str.strip()
    flow["policy_country"] = flow["policy_country"].astype(str).str.strip()

    def _fmt_k(x: float, _pos: int | None = None) -> str:
        x = float(x)
        if x >= 1_000_000:
            return f"{x/1_000_000:.1f}M"
        if x >= 1_000:
            return f"{x/1_000:.0f}K"
        return f"{x:.0f}"

    inbound = flow[flow["research_country"] == "KR"].copy()
    inbound = (
        inbound.groupby("policy_country", as_index=False)["citation_rows"]
        .sum()
        .sort_values("citation_rows", ascending=False)
    )
    inbound_total = float(inbound["citation_rows"].sum())
    inbound_top = inbound.head(10).copy()
    inbound_top["share"] = inbound_top["citation_rows"] / inbound_total if inbound_total else 0.0

    outbound = flow[flow["policy_country"] == "South Korea"].copy()
    outbound = outbound.dropna(subset=["research_country"]).copy()
    outbound = outbound[outbound["research_country"].astype(str).str.strip().ne("")].copy()
    outbound = (
        outbound.groupby("research_country", as_index=False)["citation_rows"]
        .sum()
        .sort_values("citation_rows", ascending=False)
    )
    outbound_total = float(outbound["citation_rows"].sum())
    outbound_top = outbound.head(10).copy()
    outbound_top["share"] = outbound_top["citation_rows"] / outbound_total if outbound_total else 0.0

    iso2_to_label = _iso2_to_label()
    outbound_top["research_country_label"] = outbound_top["research_country"].map(lambda c: iso2_to_label.get(c, c))

    cache_dir = report_figures_dir if report_figures_dir is not None else out_dir
    output_share_csv = cache_dir / f"{run_tag}_openalex_country_domain_output_share.csv"
    output_share_long = _openalex_output_shares_by_country_domain(domains=DOMAIN_ORDER, cache_csv=output_share_csv)
    output_share_pivot = (
        output_share_long.pivot_table(index="iso2", columns="domain", values="share", aggfunc="sum", fill_value=0)
        .reindex(columns=DOMAIN_ORDER, fill_value=0)
        .copy()
    )
    kr_output_share = (
        output_share_pivot.loc["KR"] if "KR" in output_share_pivot.index else pd.Series(index=DOMAIN_ORDER, dtype=float)
    )

    dom = pd.read_csv(in_dir / f"{run_tag}_country_domain_matrix.csv")
    dom = dom.dropna(subset=["country", "domain", "citation_rows"]).copy()
    dom = dom[dom["domain"].isin(DOMAIN_ORDER)].copy()
    dom_pivot_all = dom.pivot_table(index="country", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0)
    dom_pivot_all = dom_pivot_all.reindex(columns=DOMAIN_ORDER, fill_value=0)
    dom_share_all = _row_normalize(dom_pivot_all)

    known_totals = (
        flow[flow["research_country"].ne("")]
        .groupby("policy_country", as_index=False)["citation_rows"]
        .sum()
        .rename(columns={"citation_rows": "known_citations"})
    )
    expected_share_in_policy = (dom_share_all * kr_output_share).sum(axis=1).to_frame("expected_kr_share")
    expected_share_in_policy.index.name = "policy_country"
    expected_share_in_policy = expected_share_in_policy.reset_index()

    inbound_expected = known_totals.merge(expected_share_in_policy, on="policy_country", how="left")
    inbound_expected["expected_kr_citations"] = inbound_expected["known_citations"] * inbound_expected["expected_kr_share"]
    expected_total = float(inbound_expected["expected_kr_citations"].sum(skipna=True))
    inbound_expected["expected_share"] = (
        inbound_expected["expected_kr_citations"] / expected_total if expected_total else np.nan
    )
    inbound_expected = inbound_expected[["policy_country", "expected_share"]].copy()

    inbound_top = inbound_top.merge(inbound_expected, on="policy_country", how="left")
    inbound_top["expected_citations_scaled"] = inbound_top["expected_share"] * inbound_total if inbound_total else np.nan

    kr_policy_share = (
        dom_share_all.loc["South Korea"] if "South Korea" in dom_share_all.index else pd.Series(index=DOMAIN_ORDER, dtype=float)
    )
    expected_out = []
    for iso2 in outbound_top["research_country"].astype(str).tolist():
        if iso2 in output_share_pivot.index:
            expected_out.append(float((kr_policy_share * output_share_pivot.loc[iso2]).sum()))
        else:
            expected_out.append(np.nan)
    outbound_top["expected_share"] = expected_out
    outbound_top["expected_citations_scaled"] = outbound_top["expected_share"] * outbound_total if outbound_total else np.nan

    out_csv = pd.concat(
        [
            inbound_top.rename(columns={"policy_country": "entity"})
            .assign(direction="Inbound (KR research cited by...)")[
                ["direction", "entity", "citation_rows", "share", "expected_share"]
            ],
            outbound_top.rename(columns={"research_country_label": "entity"})
            .assign(direction="Outbound (South Korea policy cites...)")[
                ["direction", "entity", "citation_rows", "share", "expected_share"]
            ],
        ],
        ignore_index=True,
    )
    out_csv_path = cache_dir / f"{run_tag}_korea_policy_research_flows_top10.csv"
    out_csv_path.parent.mkdir(parents=True, exist_ok=True)
    out_csv.to_csv(out_csv_path, index=False)

    p_in = inbound_top.sort_values("citation_rows", ascending=True)
    p_out = outbound_top.sort_values("citation_rows", ascending=True)

    plt.rcParams.update({"font.size": 10})
    fig, (ax_a, ax_b) = plt.subplots(nrows=1, ncols=2, figsize=(13.2, 5.2), constrained_layout=True)

    expected_in = p_in["expected_citations_scaled"].astype(float)
    expected_in = expected_in.where(np.isfinite(expected_in), 0.0)
    y = np.arange(len(p_in), dtype=float)
    bar_height = 0.50
    offset = bar_height * 0.15
    y_expected = y - offset
    y_actual = y + offset
    ax_a.barh(y_expected, expected_in, height=bar_height, color=NEUTRAL_GRAY, alpha=0.85, zorder=0)
    ax_a.barh(y_actual, p_in["citation_rows"], height=bar_height, color=CORE_PRIMARY, zorder=1)
    ax_a.set_title("A. Policy sources citing KR first-author research")
    ax_a.set_xlabel("Citations to KR research")
    ax_a.set_ylabel("Policy source")
    ax_a.xaxis.set_major_formatter(FuncFormatter(_fmt_k))
    ax_a.text(
        0.98,
        0.02,
        "green and label: observed share · gray: domain-adjusted reference",
        transform=ax_a.transAxes,
        ha="right",
        va="bottom",
        fontsize=8,
        color=MUTED,
    )
    x_max_in = float(max(p_in["citation_rows"].max(), expected_in.max())) if len(p_in) else 1.0
    ax_a.set_xlim(0, x_max_in * 1.14)
    max_in = float(p_in["citation_rows"].max()) if len(p_in) else 0.0
    for i, (val, share) in enumerate(zip(p_in["citation_rows"], p_in["share"])):
        label_text = f"{float(share):.1%}"
        if max_in > 0 and float(val) == max_in:
            label_x = max(float(val) - x_max_in * 0.02, 0.01)
            ax_a.text(
                label_x,
                y_actual[i],
                label_text,
                va="center",
                ha="right",
                fontsize=9,
                color="white",
            )
        else:
            ax_a.text(
                float(val),
                y_actual[i],
                f"  {label_text}",
                va="center",
                ha="left",
                fontsize=9,
                color=TEXT,
            )
    ax_a.set_yticks(np.arange(len(p_in), dtype=float))
    ax_a.set_yticklabels(p_in["policy_country"].astype(str).tolist())

    expected_out_scaled = p_out["expected_citations_scaled"].astype(float)
    expected_out_scaled = expected_out_scaled.where(np.isfinite(expected_out_scaled), 0.0)
    y = np.arange(len(p_out), dtype=float)
    y_expected = y - offset
    y_actual = y + offset
    ax_b.barh(y_expected, expected_out_scaled, height=bar_height, color=NEUTRAL_GRAY, alpha=0.85, zorder=0)
    ax_b.barh(y_actual, p_out["citation_rows"], height=bar_height, color=CORE_PRIMARY, zorder=1)
    ax_b.set_title("B. Research countries cited by South Korea policy")
    ax_b.set_xlabel("Citations from KR policy")
    ax_b.set_ylabel("Research country (first-author)")
    ax_b.xaxis.set_major_formatter(FuncFormatter(_fmt_k))
    ax_b.text(
        0.98,
        0.02,
        "first-author country available only\ngreen and label: observed share · gray: domain-adjusted reference",
        transform=ax_b.transAxes,
        ha="right",
        va="bottom",
        fontsize=8,
        color=MUTED,
    )
    x_max_out = float(max(p_out["citation_rows"].max(), expected_out_scaled.max())) if len(p_out) else 1.0
    ax_b.set_xlim(0, x_max_out * 1.14)
    max_out = float(p_out["citation_rows"].max()) if len(p_out) else 0.0
    for i, (val, share) in enumerate(zip(p_out["citation_rows"], p_out["share"])):
        label_text = f"{float(share):.1%}"
        if max_out > 0 and float(val) == max_out:
            label_x = max(float(val) - x_max_out * 0.02, 0.01)
            ax_b.text(
                label_x,
                y_actual[i],
                label_text,
                va="center",
                ha="right",
                fontsize=9,
                color="white",
            )
        else:
            ax_b.text(
                float(val),
                y_actual[i],
                f"  {label_text}",
                va="center",
                ha="left",
                fontsize=9,
                color=TEXT,
            )
    ax_b.set_yticks(np.arange(len(p_out), dtype=float))
    ax_b.set_yticklabels(p_out["research_country_label"].astype(str).tolist())

    for ax in (ax_a, ax_b):
        _apply_dark_axes(ax, grid=True, grid_axis="x")
        ax.yaxis.grid(False)

    fig.suptitle(
        "Policy sources citing Korean research and research countries cited by Korean policy documents",
        color=TEXT,
    )

    fig.patch.set_alpha(0.0)
    out_path = out_dir / "korea_flows.png"
    _save(fig, out_path, tight=False)
    plt.close(fig)
    return out_path


def fig_country_citations_top10(*, run_tag: str, in_dir: Path, out_dir: Path) -> Path:
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FuncFormatter

    country_cit = pd.read_csv(in_dir / f"{run_tag}_country_citations.csv")
    country_cit = country_cit.dropna(subset=["country", "citation_rows"]).copy()

    top10 = country_cit.nlargest(10, "citation_rows").copy()
    korea = country_cit[country_cit["country"].isin(["South Korea", "Korea", "Republic of Korea"])].copy()
    if korea.empty:
        korea = country_cit[country_cit["country"].astype(str).str.contains("Korea", case=False, na=False)].copy()
    if korea.empty:
        raise ValueError("Korea row not found in country citations CSV.")
    korea = korea.nlargest(1, "citation_rows").copy()

    plot_df = pd.concat([top10, korea], ignore_index=True).drop_duplicates(subset=["country"], keep="first")
    plot_df = plot_df.sort_values("citation_rows", ascending=False).copy()
    order = plot_df["country"].tolist()

    plot_df["citing_policy_docs"] = plot_df["citing_policy_docs"].replace(0, np.nan)
    plot_df["citations_per_policy_doc"] = plot_df["citation_rows"] / plot_df["citing_policy_docs"]

    plt.rcParams.update({"font.size": 10})
    fig, (ax_a, ax_b) = plt.subplots(
        nrows=1,
        ncols=2,
        figsize=(10.8, 5.8),
        sharey=True,
        gridspec_kw={"width_ratios": [1.25, 1.05], "wspace": 0.10},
    )

    ax_a.barh(order, plot_df.set_index("country").loc[order, "citation_rows"], color=CORE_PRIMARY)
    ax_a.set_title("A. Scholarly-paper citations made (total)")
    ax_a.set_xlabel("DOI-linked scholarly-paper citations")
    ax_a.set_ylabel("Policy-document source")
    ax_a.xaxis.set_major_formatter(FuncFormatter(_fmt_short))
    ax_a.yaxis.grid(False)
    ax_a.xaxis.grid(True)

    x_max = float(plot_df["citation_rows"].max()) if len(plot_df) else 1.0
    ax_a.set_xlim(0, 10_000_000)
    inside_a = set(plot_df.nlargest(2, "citation_rows")["country"].tolist())
    for country in order:
        val = float(plot_df.set_index("country").loc[country, "citation_rows"])
        if country in inside_a:
            label_x = max(val - x_max * 0.02, val * 0.6)
            ax_a.text(
                label_x,
                country,
                _fmt_short(val),
                va="center",
                ha="right",
                fontsize=9,
                color="white",
                fontweight="bold",
            )
        else:
            ax_a.text(val, country, f"  {_fmt_short(val)}", va="center", ha="left", fontsize=9, color=TEXT)

    ticks_a = [t for t in ax_a.get_xticks() if _fmt_short(float(t)) != "10.0M"]
    if ticks_a:
        ax_a.set_xticks(ticks_a)

    vals_b = plot_df.set_index("country").loc[order, "citations_per_policy_doc"].astype(float).fillna(0.0)
    ax_b.barh(order, vals_b, color=POLICY_ONLY)
    ax_b.set_title("B. Scholarly-paper citations per citing policy doc (mean)")
    ax_b.set_xlabel("Mean citations per citing policy document")
    ax_b.set_ylabel("")
    ax_b.yaxis.grid(False)
    ax_b.xaxis.grid(True)
    ax_b.tick_params(axis="y", labelleft=False)
    ax_b.xaxis.set_major_formatter(FuncFormatter(lambda x, _pos=None: f"{x:.1f}"))

    x_max_b = float(vals_b.max()) if len(vals_b) else 1.0
    ax_b.set_xlim(0, x_max_b * 1.18 if x_max_b > 0 else 1.0)
    inside_b = {country for country in order if float(vals_b.loc[country]) > 17.0}
    for country in order:
        val = float(vals_b.loc[country])
        if country in inside_b:
            label_x = max(val - x_max_b * 0.05, val * 0.6)
            ax_b.text(
                label_x,
                country,
                f"{val:.1f}",
                va="center",
                ha="right",
                fontsize=9,
                color="white",
                fontweight="bold",
            )
        else:
            ax_b.text(val, country, f"  {val:.1f}", va="center", ha="left", fontsize=9, color=TEXT)

    for ax in (ax_a, ax_b):
        ax.invert_yaxis()
        _apply_dark_axes(ax, grid=True, grid_axis="x")
        ax.yaxis.grid(False)

    fig.suptitle(
        "Citation direction: policy documents issued by each source → scholarly papers",
        fontsize=14,
        fontweight="bold",
        y=1.01,
        color=TEXT,
    )
    fig.patch.set_alpha(0.0)
    out_path = out_dir / "country_citations_top10.png"
    _save(fig, out_path)
    plt.close(fig)
    return out_path


def fig_domain_top10(
    *, run_tag: str, in_dir: Path, out_dir: Path, report_figures_dir: Path | None = None
) -> Path:
    import matplotlib.pyplot as plt
    from matplotlib.ticker import EngFormatter
    from matplotlib.patches import Patch

    df = pd.read_csv(in_dir / f"{run_tag}_domain_counts.csv")
    df["domain"] = df["domain"].fillna("Unknown").replace({"": "Unknown"})
    df = df.sort_values("citation_rows", ascending=False).head(10).copy()
    df["citation_rows"] = df["citation_rows"].astype(float)

    top_domains = [d for d in DOMAIN_ORDER if d in df["domain"].tolist()]
    if not top_domains:
        top_domains = df[df["domain"].ne("Unknown")]["domain"].head(4).tolist()

    field_cache = None
    if report_figures_dir is not None:
        candidate = report_figures_dir / f"{run_tag}_domain_field_counts.csv"
        if candidate.exists():
            field_cache = candidate
    if field_cache is None:
        field_cache = out_dir / f"{run_tag}_domain_field_counts.csv"

    if field_cache.exists():
        field_df = pd.read_csv(field_cache)
    else:
        import duckdb

        con = duckdb.connect()
        domain_list = ",".join([f"'{d}'" for d in top_domains])
        field_df = con.execute(
            f"""
            WITH citations AS (
              SELECT oaid_w, COUNT(*) AS cite_count
              FROM read_parquet('Data/raw_df_citation_non_duplicated.parquet')
              WHERE oaid_w IS NOT NULL
              GROUP BY 1
            ),
            work_domain_field AS (
              SELECT DISTINCT oaid_w, domain, field
              FROM read_parquet('Data/openalex_topics.parquet')
              WHERE domain IN ({domain_list})
                AND field IS NOT NULL
                AND field != ''
            ),
            work_domain_field_nf AS (
              SELECT
                oaid_w,
                domain,
                field,
                COUNT(*) OVER (PARTITION BY oaid_w, domain) AS n_fields
              FROM work_domain_field
            )
            SELECT
              domain,
              field,
              SUM(c.cite_count / w.n_fields) AS citation_rows
            FROM citations c
            JOIN work_domain_field_nf w USING (oaid_w)
            GROUP BY 1, 2
            ORDER BY 1, citation_rows DESC
            """
        ).df()
        con.close()
        field_df.to_csv(field_cache, index=False)

    field_df = field_df.dropna(subset=["domain", "field", "citation_rows"]).copy()
    field_df["domain"] = field_df["domain"].astype(str).str.strip()
    field_df["field"] = field_df["field"].astype(str).str.strip()
    field_df = field_df[(field_df["domain"].isin(top_domains)) & (field_df["field"].ne(""))].copy()

    top_k = 3
    top_fields_by_domain: dict[str, list[str]] = {}
    for domain in top_domains:
        dom_fields = field_df[field_df["domain"] == domain].nlargest(top_k, "citation_rows")["field"].tolist()
        top_fields_by_domain[domain] = dom_fields

    domain_totals = df.set_index("domain")["citation_rows"].to_dict()

    field_totals = field_df.groupby(["domain", "field"], as_index=False)["citation_rows"].sum()
    domain_field_sum = field_totals.groupby("domain", as_index=False)["citation_rows"].sum().rename(
        columns={"citation_rows": "domain_total_raw"}
    )
    field_totals = field_totals.merge(domain_field_sum, on="domain", how="left")
    domain_total_raw_map = domain_field_sum.set_index("domain")["domain_total_raw"].to_dict()

    plot_domains = [d for d in df["domain"].tolist() if d in top_domains]
    if "Unknown" in domain_totals:
        plot_domains.append("Unknown")

    plt.rcParams.update({"font.size": 10.5})
    fig, ax = plt.subplots(figsize=(10.8, 5.6))
    y = np.arange(len(plot_domains))
    shade_levels = [0.0, 0.32, 0.58]
    seen_labels: set[str] = set()

    max_total = max((float(domain_totals.get(d, 0.0)) for d in plot_domains), default=0.0)
    label_offset = max_total * 0.012 if max_total else 0.05
    label_style = dict(fontsize=10, fontweight="bold", color=TEXT)
    segment_label_style = dict(fontsize=8.5, color=TEXT)
    min_segment_share = 0.05
    min_segment_share_inside = 0.08
    min_segment_share_inside_life = 0.10

    for i, domain in enumerate(plot_domains):
        total = float(domain_totals.get(domain, 0.0))
        if domain == "Unknown":
            ax.barh([i], [total], left=0, color=_tint(NEUTRAL_GRAY, 0.35), label=None)
            ax.text(total + label_offset, i, _fmt_short(total), va="center", ha="left", **label_style)
            continue

        dom_fields = top_fields_by_domain.get(domain, [])
        outside_labels: list[tuple[float, str]] = []
        allow_outside = domain == "Life Sciences"
        segments: list[tuple[str, float]] = []
        for field in dom_fields:
            val = float(
                field_totals[(field_totals["domain"] == domain) & (field_totals["field"] == field)][
                    "citation_rows"
                ]
                .fillna(0)
                .sum()
            )
            segments.append((field, val))
        segments = [(f, v) for f, v in segments if v > 0]
        segments.sort(key=lambda x: x[1], reverse=True)

        used = float(sum(v for _f, v in segments))
        domain_total_raw = float(domain_total_raw_map.get(domain, 0.0))
        other_val = max(domain_total_raw - used, 0.0)
        missing_val = max(total - domain_total_raw, 0.0)
        if missing_val < 0.5:
            missing_val = 0.0

        left = 0.0
        base = DOMAIN_PALETTE.get(domain, CORE_PRIMARY)
        inside_threshold = min_segment_share_inside_life if allow_outside else min_segment_share_inside
        for rank, (field, val) in enumerate(segments):
            tint = shade_levels[min(rank, len(shade_levels) - 1)]
            color = _tint(base, tint)
            label = _ellipsize(field, 28) if field not in seen_labels else None
            seen_labels.add(field)
            ax.barh([i], [val], left=left, color=color, label=label)
            if total > 0 and val / total >= min_segment_share:
                if (val / total >= inside_threshold) or not allow_outside:
                    ax.text(left + val * 0.5, i, _fmt_short(val), va="center", ha="center", **segment_label_style)
                else:
                    outside_labels.append((left + val * 0.5, _fmt_short(val)))
            left += val

        label_other = "Other" if "Other" not in seen_labels else None
        seen_labels.add("Other")
        ax.barh([i], [other_val], left=left, color=NEUTRAL_GRAY, label=label_other)
        if total > 0 and other_val / total >= min_segment_share:
            if (other_val / total >= inside_threshold) or not allow_outside:
                ax.text(
                    left + other_val * 0.5,
                    i,
                    _fmt_short(other_val),
                    va="center",
                    ha="center",
                    **segment_label_style,
                )
            else:
                outside_labels.append((left + other_val * 0.5, _fmt_short(other_val)))
        left += other_val

        if missing_val > 0:
            label_missing = "Field missing" if "Field missing" not in seen_labels else None
            seen_labels.add("Field missing")
            ax.barh(
                [i],
                [missing_val],
                left=left,
                color=_tint(NEUTRAL_GRAY, 0.35),
                alpha=0.4,
                label=label_missing,
            )
            if total > 0 and missing_val / total >= min_segment_share:
                if (missing_val / total >= inside_threshold) or not allow_outside:
                    ax.text(
                        left + missing_val * 0.5,
                        i,
                        _fmt_short(missing_val),
                        va="center",
                        ha="center",
                        **segment_label_style,
                    )
                else:
                    outside_labels.append((left + missing_val * 0.5, _fmt_short(missing_val)))

        if outside_labels:
            if allow_outside:
                offsets_x = np.linspace(-18, 18, len(outside_labels))
                offsets_y = np.linspace(-12, -22, len(outside_labels))
                for (x_anchor, label_text), dx, dy in zip(outside_labels, offsets_x, offsets_y):
                    ax.annotate(
                        label_text,
                        xy=(x_anchor, i),
                        xytext=(dx, dy),
                        textcoords="offset points",
                        ha="center",
                        va="top",
                        fontsize=segment_label_style["fontsize"],
                        color=segment_label_style["color"],
                        arrowprops=dict(arrowstyle="-", color=(1, 1, 1, 0.55), lw=0.8),
                    )
            else:
                offsets = np.linspace(-0.24, 0.24, len(outside_labels))
                label_x = total + label_offset * 0.2
                for (x_anchor, label_text), dy in zip(outside_labels, offsets):
                    ax.annotate(
                        label_text,
                        xy=(x_anchor, i),
                        xytext=(label_x, i + dy),
                        textcoords="data",
                        ha="left",
                        va="center",
                        fontsize=segment_label_style["fontsize"],
                        color=segment_label_style["color"],
                        arrowprops=dict(arrowstyle="-", color=(1, 1, 1, 0.55), lw=0.8),
                    )

        ax.text(total + label_offset, i, _fmt_short(total), va="center", ha="left", **label_style)

    ax.set_yticks(y, labels=plot_domains)
    ax.invert_yaxis()
    ax.yaxis.grid(False)
    ax.xaxis.grid(True, color=GRID, alpha=0.5)
    ax.set_title("Policy citations by domain (field composition)", loc="left", fontsize=13, color=TEXT)
    ax.set_xlabel("Citations")
    ax.set_ylabel("Domain")
    ax.xaxis.set_major_formatter(EngFormatter(sep=""))
    ax.set_xlim(0, max_total * 1.12 if max_total else 1.0)
    _apply_dark_axes(ax, grid=True, grid_axis="x")

    handles, labels = ax.get_legend_handles_labels()
    label_to_handle = {label: handle for label, handle in zip(labels, handles)}

    ncol = 3
    desired_row_major: list[str] = []
    for domain in top_domains:
        domain_labels: list[str] = []
        for field in top_fields_by_domain.get(domain, []):
            label = _ellipsize(field, 28)
            if label in label_to_handle and label not in domain_labels:
                domain_labels.append(label)
        while len(domain_labels) < ncol:
            domain_labels.append("")
        desired_row_major.extend(domain_labels[:ncol])

    extra_labels: list[str] = []
    for label in ["Other", "Field missing"]:
        if label in label_to_handle:
            extra_labels.append(label)
    if extra_labels:
        while len(extra_labels) < ncol:
            extra_labels.append("")
        desired_row_major.extend(extra_labels[:ncol])

    for label in labels:
        if label not in desired_row_major:
            desired_row_major.append(label)
    if desired_row_major and ncol > 1:
        remainder = len(desired_row_major) % ncol
        if remainder:
            desired_row_major.extend([""] * (ncol - remainder))
        n_rows = len(desired_row_major) // ncol
        order = []
        for col in range(ncol):
            for row in range(n_rows):
                order.append(row * ncol + col)
        labels = [desired_row_major[i] for i in order]
        handles = [
            (label_to_handle[label] if label else Patch(facecolor="none", edgecolor="none"))
            for label in labels
        ]

    legend = ax.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.16),
        frameon=True,
        fancybox=True,
        framealpha=0.12,
        ncol=ncol,
        columnspacing=1.6,
        handletextpad=0.6,
    )
    if legend:
        for text in legend.get_texts():
            text.set_color(TEXT)
        frame = legend.get_frame()
        frame.set_facecolor((0, 0, 0, 0.22))
        frame.set_edgecolor((1, 1, 1, 0.18))

    fig.patch.set_alpha(0.0)
    out_path = out_dir / "domain_top10.png"
    _save(fig, out_path)
    plt.close(fig)
    return out_path


def fig_country_flow_heatmap(*, run_tag: str, in_dir: Path, out_dir: Path) -> Path:
    import matplotlib.pyplot as plt
    import seaborn as sns

    mat = pd.read_csv(
        in_dir / f"{run_tag}_policy_country_research_country.csv",
        keep_default_na=False,
    )
    mat = mat.dropna(subset=["policy_country", "research_country", "citation_rows"]).copy()
    mat = mat[mat["citation_rows"] > 0].copy()

    iso2_to_label = _iso2_to_label()
    mat["policy_country_label"] = mat["policy_country"].astype(str)
    mat["research_country_label"] = mat["research_country"].map(iso2_to_label).fillna(mat["research_country"].astype(str))

    korea_label = "South Korea"
    top_n = 14
    policy_rank = mat.groupby("policy_country_label", as_index=True)["citation_rows"].sum().sort_values(ascending=False)
    research_rank = (
        mat.groupby("research_country_label", as_index=True)["citation_rows"].sum().sort_values(ascending=False)
    )
    policy = policy_rank.head(top_n).index.tolist()
    research = research_rank.head(top_n).index.tolist()
    if korea_label in policy_rank.index and korea_label not in policy:
        policy.append(korea_label)
    if korea_label in research_rank.index and korea_label not in research:
        research.append(korea_label)

    sub = mat[mat["policy_country_label"].isin(policy) & mat["research_country_label"].isin(research)].copy()
    pivot = (
        sub.pivot_table(
            index="policy_country_label",
            columns="research_country_label",
            values="citation_rows",
            aggfunc="sum",
            fill_value=0.0,
        )
        .reindex(index=policy, columns=research, fill_value=0.0)
        .astype(float)
    )
    values = np.log10(1.0 + pivot.to_numpy(dtype=float))

    plt.rcParams.update({"font.size": 10})
    fig, ax = plt.subplots(figsize=(11.2, 6.4))
    cmap = sns.color_palette("crest", as_cmap=True)
    sns.heatmap(
        values,
        ax=ax,
        cmap=cmap,
        cbar=True,
        linewidths=0.6,
        linecolor=(1, 1, 1, 0.06),
        xticklabels=pivot.columns.tolist(),
        yticklabels=pivot.index.tolist(),
        cbar_kws={"label": "log10(1 + citations)"},
    )

    ax.set_xlabel("Research country (first author)")
    ax.set_ylabel("Policy source")
    title = ax.set_title("Policy-source to research-country citations (top countries)", loc="left", fontsize=12)
    title.set_color(TEXT)

    ax.set_facecolor("none")
    ax.tick_params(colors=TEXT, labelcolor=TEXT)
    ax.xaxis.label.set_color(TEXT)
    ax.yaxis.label.set_color(TEXT)

    cbar = ax.collections[0].colorbar
    cbar.ax.yaxis.label.set_color(TEXT)
    cbar.ax.tick_params(colors=TEXT, labelcolor=TEXT)
    for spine in ax.spines.values():
        spine.set_visible(False)

    fig.patch.set_alpha(0.0)
    out_path = out_dir / "country_flow.png"
    _save(fig, out_path)
    plt.close(fig)
    return out_path


def fig_source_type_domain_heatmap(*, run_tag: str, in_dir: Path, out_dir: Path) -> Path:
    import matplotlib.pyplot as plt
    import seaborn as sns

    df = pd.read_csv(in_dir / f"{run_tag}_source_type_domain_matrix.csv")
    df = df.dropna(subset=["source_type", "domain", "citation_rows"]).copy()
    df = df[df["citation_rows"] > 0].copy()

    top_types = df.groupby("source_type", as_index=True)["citation_rows"].sum().sort_values(ascending=False).head(14).index
    top_domains = df.groupby("domain", as_index=True)["citation_rows"].sum().sort_values(ascending=False).head(6).index
    sub = df[df["source_type"].isin(top_types) & df["domain"].isin(top_domains)].copy()

    pivot = (
        sub.pivot_table(index="source_type", columns="domain", values="citation_rows", aggfunc="sum", fill_value=0.0)
        .reindex(index=top_types, columns=top_domains, fill_value=0.0)
        .astype(float)
    )
    values = np.log10(1.0 + pivot.to_numpy(dtype=float))

    plt.rcParams.update({"font.size": 10})
    fig, ax = plt.subplots(figsize=(11.2, 6.4))
    cmap = sns.color_palette("crest", as_cmap=True)
    sns.heatmap(
        values,
        ax=ax,
        cmap=cmap,
        cbar=True,
        linewidths=0.6,
        linecolor=(1, 1, 1, 0.06),
        xticklabels=pivot.columns.tolist(),
        yticklabels=pivot.index.tolist(),
        cbar_kws={"label": "log10(1 + citations)"},
    )

    ax.set_xlabel("Domain")
    ax.set_ylabel("Policy source type")
    title = ax.set_title("Source type × domain (top types/domains)", loc="left", fontsize=12)
    title.set_color(TEXT)

    ax.set_facecolor("none")
    ax.tick_params(colors=TEXT, labelcolor=TEXT)
    ax.xaxis.label.set_color(TEXT)
    ax.yaxis.label.set_color(TEXT)

    cbar = ax.collections[0].colorbar
    cbar.ax.yaxis.label.set_color(TEXT)
    cbar.ax.tick_params(colors=TEXT, labelcolor=TEXT)
    for spine in ax.spines.values():
        spine.set_visible(False)

    fig.patch.set_alpha(0.0)
    out_path = out_dir / "source_type_domain.png"
    _save(fig, out_path)
    plt.close(fig)
    return out_path


def fig_source_type_density_scatter(*, run_tag: str, report_figures_dir: Path, out_dir: Path) -> Path:
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch

    df = pd.read_csv(report_figures_dir / f"{run_tag}_source_type_citations_per_policy_doc.csv")
    df = df.dropna(
        subset=[
            "source_type",
            "major_type",
            "citation_rows",
            "policy_docs",
            "citing_policy_docs",
            "citations_per_policy_doc",
        ]
    ).copy()
    df = df[df["citation_rows"] > 0].copy()

    major_colors = {
        "government": AUX_PRIMARY,
        "igo": AUX_SECONDARY,
        "other": AUX_HIGHLIGHT,
        "think tank": AUX_TERTIARY,
    }

    docs = df["citing_policy_docs"].astype(float).clip(lower=1)
    docs_log = np.log10(docs)
    if docs_log.nunique() > 1:
        docs_norm = (docs_log - docs_log.min()) / (docs_log.max() - docs_log.min())
        marker_sizes = 55 + docs_norm * 520
    else:
        marker_sizes = pd.Series([220.0] * len(df), index=df.index)
    df["marker_size"] = marker_sizes.astype(float)

    fig, ax = plt.subplots(figsize=(10.8, 6.4))
    _apply_dark_axes(ax)
    ax.grid(True, axis="both", alpha=0.5)

    citations = df["citation_rows"].astype(float).replace([np.inf, -np.inf], np.nan).dropna()
    if len(citations):
        citations_mean = float(np.exp(np.log(citations).mean()))
        ax.axvline(citations_mean, color=(1, 1, 1, 0.35), linestyle="--", linewidth=1.2, zorder=1)
    docs_total = float(df["citing_policy_docs"].sum())
    citations_total = float(df["citation_rows"].sum())
    if docs_total > 0:
        overall_density = citations_total / docs_total
        ax.axhline(overall_density, color=(1, 1, 1, 0.35), linestyle="--", linewidth=1.2, zorder=1)

    colors = df["major_type"].astype(str).map(lambda m: major_colors.get(m.strip(), CORE_PRIMARY))
    sub_mask = df["source_type"].astype(str).str.contains(">")
    ax.scatter(
        df.loc[sub_mask, "citation_rows"],
        df.loc[sub_mask, "citations_per_policy_doc"],
        s=df.loc[sub_mask, "marker_size"],
        c=colors.loc[sub_mask],
        alpha=0.62,
        linewidth=0,
        zorder=2,
    )
    major_mask = ~sub_mask
    ax.scatter(
        df.loc[major_mask, "citation_rows"],
        df.loc[major_mask, "citations_per_policy_doc"],
        s=df.loc[major_mask, "marker_size"] * 1.08,
        c=colors.loc[major_mask],
        alpha=0.9,
        linewidth=1.25,
        edgecolor=(1, 1, 1, 0.65),
        zorder=3,
    )
    ax.set_xscale("log")
    ax.set_title(
        "Source types: total citations vs average citations per citing policy document",
        loc="left",
        fontsize=13,
        color=TEXT,
    )
    ax.set_xlabel("Total citations (log)")
    ax.set_ylabel("Citations per citing policy document")

    label_df = pd.concat([df.nlargest(5, "citation_rows"), df.nlargest(5, "citations_per_policy_doc")], ignore_index=True)
    label_df = label_df.drop_duplicates(subset=["source_type"]).copy()
    for _, row in label_df.iterrows():
        x = float(row["citation_rows"])
        y = float(row["citations_per_policy_doc"])
        ax.text(
            x,
            y,
            str(row["source_type"])[:34],
            ha="left",
            va="center",
            fontsize=9,
            color=TEXT,
            alpha=0.92,
        )

    majors = sorted(df["major_type"].dropna().astype(str).unique().tolist())
    color_legend_handles = [
        Patch(facecolor=major_colors.get(m, CORE_PRIMARY), label=m, alpha=0.78) for m in majors
    ]
    legend1 = ax.legend(
        handles=color_legend_handles,
        title="Source type (major)",
        loc="upper left",
        frameon=True,
        fancybox=True,
        framealpha=0.12,
        labelcolor=TEXT,
    )
    legend1.get_title().set_color(TEXT)
    ax.add_artist(legend1)

    quantiles = np.quantile(docs, [0.25, 0.5, 0.75]).astype(int).tolist()
    size_values = sorted({int(v) for v in quantiles if v > 0})
    if len(size_values) < 3:
        size_values = sorted({int(v) for v in np.quantile(docs, [0.1, 0.5, 0.9]).astype(int).tolist() if v > 0})
    if len(size_values) > 3:
        size_values = [size_values[0], size_values[len(size_values) // 2], size_values[-1]]

    def _size_for_docs(v: float) -> float:
        v = float(max(v, 1.0))
        v_log = np.log10(v)
        if docs_log.nunique() <= 1:
            return 220.0
        v_norm = (v_log - float(docs_log.min())) / (float(docs_log.max()) - float(docs_log.min()))
        return 55 + float(np.clip(v_norm, 0.0, 1.0)) * 520

    size_legend_handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            color="w",
            markerfacecolor=NEUTRAL_GRAY,
            markersize=np.sqrt(_size_for_docs(float(v))),
            alpha=0.7,
            label=_tick_compact(float(v)),
        )
        for v in size_values
    ]
    legend2 = ax.legend(
        handles=size_legend_handles,
        title="Policy documents with DOI citations",
        loc="center left",
        bbox_to_anchor=(0.02, 0.35),
        frameon=True,
        fancybox=True,
        framealpha=0.12,
        labelcolor=TEXT,
    )
    legend2.get_title().set_color(TEXT)

    fig.patch.set_alpha(0.0)
    out_path = out_dir / "source_type_scatter.png"
    _save(fig, out_path)
    plt.close(fig)
    return out_path


def fig_topic_intensity_vs_recency(
    *, run_tag: str, in_dir: Path, out_dir: Path, report_figures_dir: Path | None = None
) -> Path:
    import matplotlib.pyplot as plt
    import seaborn as sns
    from matplotlib.ticker import PercentFormatter
    from adjustText import adjust_text

    csv_path = in_dir / f"{run_tag}_topic_intensity_recency.csv"
    if report_figures_dir is not None:
        candidate = report_figures_dir / f"{run_tag}_topic_intensity_recency.csv"
        if candidate.exists():
            csv_path = candidate

    df = pd.read_csv(csv_path)
    required = {"topic", "domain", "intensity", "recent_paper_share"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(
            "Topic metric input uses the legacy citation-row recency definition. "
            "Run scripts/make_topic_intensity_recency.py first. "
            f"Missing columns: {sorted(missing)}"
        )
    df = df.dropna(subset=list(required)).copy()
    df = df[df["intensity"] > 0].copy()

    domain_palette = {**DOMAIN_PALETTE, "Unknown": NEUTRAL_GRAY}

    plt.rcParams.update({"font.size": 11})
    fig, ax = plt.subplots(figsize=(10.6, 7.0))
    _apply_dark_axes(ax)

    sns.scatterplot(
        data=df,
        x="intensity",
        y="recent_paper_share",
        hue="domain",
        palette=domain_palette,
        alpha=0.78,
        linewidth=0,
        ax=ax,
        zorder=2,
    )

    recent_max = float(df["recent_paper_share"].max())
    ax.set_ylim(0, min(1.0, max(0.15, recent_max * 1.12)))
    ax.set_title(
        "Policy citations per paper and 2022-2024 unique-paper share by topic",
        loc="left",
        fontsize=13,
        color=TEXT,
    )
    ax.set_xlabel("Policy citations per paper")
    ax.set_ylabel("Share of unique papers published in 2022-2024 (%)")

    intensity = df["intensity"].astype(float).replace([np.inf, -np.inf], np.nan).dropna()
    if len(intensity):
        intensity_mean = float(intensity.mean())
        ax.axvline(intensity_mean, color=(1, 1, 1, 0.35), linestyle="--", linewidth=1.2, zorder=1)
    recent_mean = float(df["recent_paper_share"].astype(float).mean())
    ax.axhline(recent_mean, color=(1, 1, 1, 0.35), linestyle="--", linewidth=1.2, zorder=1)
    ax.yaxis.set_major_formatter(PercentFormatter(1.0))

    if len(intensity):
        ax.annotate(
            "Mean citations per paper",
            xy=(intensity_mean, 0.02),
            xycoords=ax.get_xaxis_transform(),
            xytext=(0, -10),
            textcoords="offset points",
            ha="center",
            va="top",
            fontsize=8,
            color=MUTED,
        )
    ax.annotate(
        "Mean recent unique-paper share",
        xy=(0.02, recent_mean),
        xycoords=ax.get_yaxis_transform(),
        xytext=(0, -8),
        textcoords="offset points",
        ha="left",
        va="top",
        fontsize=8,
        color=MUTED,
    )

    label_df = df.sort_values("recent_paper_share", ascending=False).head(10)
    texts = []
    for _, row in label_df.iterrows():
        texts.append(
            ax.text(
                float(row["intensity"]),
                float(row["recent_paper_share"]),
                _ellipsize(str(row["topic"]), 28),
                ha="right",
                va="center",
                fontsize=9,
                color=TEXT,
                alpha=0.95,
                zorder=3,
            )
        )

    if texts:
        adjust_text(
            texts,
            ax=ax,
            expand_text=(1.08, 1.12),
            expand_points=(1.10, 1.25),
            arrowprops=dict(arrowstyle="-", color=(1, 1, 1, 0.55), lw=0.8),
            force_text=(0.18, 0.30),
            force_points=(0.10, 0.18),
            lim=200,
        )

    legend = ax.legend(
        title="Domain",
        loc="upper right",
        frameon=True,
        fancybox=True,
        framealpha=0.12,
        labelcolor=TEXT,
    )
    if legend:
        legend.get_title().set_color(TEXT)
        frame = legend.get_frame()
        frame.set_facecolor((0, 0, 0, 0.22))
        frame.set_edgecolor((1, 1, 1, 0.18))

    fig.patch.set_alpha(0.0)
    out_path = out_dir / "topic_intensity_vs_recency.png"
    _save(fig, out_path)
    plt.close(fig)
    return out_path


def _igraph_positions_drl(*, edges: pd.DataFrame, nodes: list[str], seed: int = 42) -> dict[str, tuple[float, float]]:
    import igraph as ig  # type: ignore

    if not nodes:
        return {}

    random.seed(int(seed))
    np.random.seed(int(seed))

    idx = {node: i for i, node in enumerate(nodes)}
    pair_weight: dict[tuple[int, int], float] = {}
    for row in edges.itertuples(index=False):
        u = idx.get(str(row.exporter))
        v = idx.get(str(row.importer))
        if u is None or v is None or u == v:
            continue
        a, b = (u, v) if u < v else (v, u)
        pair_weight[(a, b)] = pair_weight.get((a, b), 0.0) + float(row.weight)

    g = ig.Graph(n=len(nodes), directed=False)
    g.vs["name"] = nodes
    if pair_weight:
        edge_list = list(pair_weight.keys())
        weights = [float(np.log1p(pair_weight[e])) for e in edge_list]
        g.add_edges(edge_list)
        g.es["weight"] = weights

    n = len(nodes)
    angles = np.linspace(0.0, 2 * np.pi, num=n, endpoint=False)
    seed_coords = np.column_stack([np.cos(angles), np.sin(angles)]).tolist()
    coords = np.asarray(g.layout_drl(weights="weight", seed=seed_coords, options="default").coords, dtype=float)
    coords -= coords.mean(axis=0, keepdims=True)
    max_abs = float(np.max(np.abs(coords))) if coords.size else 1.0
    if max_abs > 0:
        coords /= max_abs
    return {nodes[i]: (float(coords[i, 0]), float(coords[i, 1])) for i in range(n)}


def _fa2_positions(
    *, edges: pd.DataFrame, nodes: list[str], seed: int = 7, seed_pos: dict[str, tuple[float, float]] | None = None
) -> dict[str, tuple[float, float]]:
    try:
        import forceatlas2  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("forceatlas2 is required for the flow network; install forceatlas2.") from exc

    if not nodes:
        return {}

    idx = {node: i for i, node in enumerate(nodes)}
    n = len(nodes)
    a = np.zeros((n, n), dtype=float)

    for row in edges.itertuples(index=False):
        u = idx.get(str(row.exporter))
        v = idx.get(str(row.importer))
        if u is None or v is None or u == v:
            continue
        w = float(row.weight)
        w = float(np.log1p(max(w, 0.0)))
        a[u, v] += w
        a[v, u] += w

    np.fill_diagonal(a, 0.0)

    init = None
    if seed_pos is not None:
        init = np.asarray([seed_pos[node] for node in nodes], dtype=float)
    else:
        rng = np.random.default_rng(seed)
        init = rng.normal(size=(n, 2))
    coords = forceatlas2.forceatlas2(
        a,
        pos=init,
        niter=450,
        edgeWeightInfluence=1.0,
        jitterTolerance=1.0,
        scalingRatio=2.8,
        gravity=1.0,
        strongGravityMode=True,
    )
    coords = np.asarray(coords, dtype=float)
    mins = coords.min(axis=0)
    maxs = coords.max(axis=0)
    span = np.where((maxs - mins) == 0, 1.0, (maxs - mins))
    coords = (coords - mins) / span
    coords = coords * 2.0 - 1.0
    return {node: (float(coords[idx[node], 0]), float(coords[idx[node], 1])) for node in nodes}


def fig_flow_network(
    *,
    run_tag: str,
    in_dir: Path,
    out_dir: Path,
    node_count: int = 50,
    top_k: int = 3,
    layout_seed: int = 2026,
    text_color: str = TEXT,
) -> tuple[Path, Path]:
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import FancyArrowPatch, Patch

    mat = pd.read_csv(
        in_dir / f"{run_tag}_policy_country_research_country.csv",
        keep_default_na=False,
    )
    mat = mat.dropna(subset=["policy_country", "research_country", "citation_rows"]).copy()
    mat = mat[mat["citation_rows"] > 0].copy()

    iso2_to_label = _iso2_to_label()
    mat["policy_country_label"] = mat["policy_country"].map(_policy_country_label)
    mat["research_country_label"] = mat["research_country"].map(iso2_to_label).fillna(mat["research_country"].astype(str))
    mat = mat.dropna(subset=["policy_country_label"]).copy()
    mat = mat[mat["policy_country_label"].ne("") & mat["policy_country_label"].ne("Unknown")].copy()
    mat = mat[mat["research_country_label"].ne("") & mat["research_country_label"].ne("Unknown")].copy()

    korea_label = "South Korea"
    label_overrides = _label_overrides()

    flows = mat.rename(
        columns={
            "research_country_label": "exporter",
            "policy_country_label": "importer",
            "citation_rows": "weight",
        }
    )[["exporter", "importer", "weight"]].copy()
    flows = flows[flows["exporter"].ne(flows["importer"])].copy()
    if flows.empty:
        raise ValueError("No cross-entity flows found after removing self-links.")

    out_sum = flows.groupby("exporter", as_index=True)["weight"].sum()
    in_sum = flows.groupby("importer", as_index=True)["weight"].sum()
    node_total_all = out_sum.add(in_sum, fill_value=0).sort_values(ascending=False)

    nodes = node_total_all.head(max(1, int(node_count))).index.tolist()
    if korea_label in node_total_all.index and korea_label not in nodes:
        nodes.append(korea_label)

    flows = flows[flows["exporter"].isin(nodes) & flows["importer"].isin(nodes)].copy()
    if flows.empty:
        raise ValueError("No flows remaining after filtering to selected nodes.")

    # Node size should reflect "total flow" in the induced subgraph of selected nodes.
    # This is computed *before* top-k edge pruning so node size is not an artifact of
    # the visualization filtering step.
    node_tot_out_full = flows.groupby("exporter", as_index=True)["weight"].sum()
    node_tot_in_full = flows.groupby("importer", as_index=True)["weight"].sum()
    node_total_full = node_tot_out_full.add(node_tot_in_full, fill_value=0).reindex(nodes).fillna(0)

    top_exports = flows.sort_values("weight", ascending=False).groupby("exporter", as_index=False).head(int(top_k))
    top_imports = flows.sort_values("weight", ascending=False).groupby("importer", as_index=False).head(int(top_k))
    edges = pd.concat([top_exports, top_imports], ignore_index=True).drop_duplicates(subset=["exporter", "importer"])
    if edges.empty:
        raise ValueError("No flows found after top-k filtering.")

    exporters = set(edges["exporter"].astype(str).tolist())
    importers = set(edges["importer"].astype(str).tolist())
    exporters_full = set(flows["exporter"].astype(str).tolist())
    importers_full = set(flows["importer"].astype(str).tolist())
    nodes = sorted(set(nodes).intersection(exporters.union(importers)))

    node_total = node_total_full.reindex(nodes).fillna(0)
    nodes_sorted = node_total.sort_values(ascending=False).index.tolist()

    vol = node_total.clip(lower=1).astype(float)
    vol_log = np.log10(vol)
    if vol_log.nunique() > 1:
        vol_norm = (vol_log - vol_log.min()) / (vol_log.max() - vol_log.min())
        node_sizes = 90 + vol_norm * 430
    else:
        node_sizes = pd.Series([240.0] * len(nodes_sorted), index=nodes_sorted)

    policy_only_color = POLICY_ONLY
    research_only_color = RESEARCH_ONLY
    korea_color = KOREA
    both_color = CORE_PRIMARY

    node_colors: dict[str, str] = {}
    for node in nodes_sorted:
        if node == korea_label:
            node_colors[node] = korea_color
            continue
        is_policy = node in importers_full
        is_research = node in exporters_full
        if is_policy and is_research:
            node_colors[node] = both_color
        elif is_policy:
            node_colors[node] = policy_only_color
        elif is_research:
            node_colors[node] = research_only_color
        else:
            node_colors[node] = both_color

    max_w = float(edges["weight"].max()) if not edges.empty else 1.0

    def _edge_lw(w: float) -> float:
        if max_w <= 0:
            return 1.0
        w_norm = (float(w) / float(max_w)) ** 0.55
        return 0.6 + 6.0 * w_norm

    pos = _igraph_positions_drl(edges=edges, nodes=nodes_sorted, seed=layout_seed)

    def _style_legend(legend) -> None:
        if legend is None:
            return
        for text in legend.get_texts():
            text.set_color(text_color)
        legend.get_title().set_color(text_color)
        frame = legend.get_frame()
        frame.set_facecolor((0, 0, 0, 0.22))
        frame.set_edgecolor((1, 1, 1, 0.18))
        frame.set_linewidth(1.0)
        frame.set_alpha(1.0)

    # A) Labeled network for step panel
    plt.rcParams.update({"font.size": 11})
    fig, ax = plt.subplots(figsize=(11.4, 7.8))
    ax.set_facecolor("none")
    ax.axis("off")

    coords = np.array([pos[n] for n in nodes_sorted if n in pos], dtype=float)
    if coords.size:
        x_min, y_min = coords.min(axis=0)
        x_max, y_max = coords.max(axis=0)
    else:
        x_min = y_min = -1.0
        x_max = y_max = 1.0
    pad = 0.35
    ax.set_xlim(float(x_min - pad), float(x_max + pad))
    ax.set_ylim(float(y_min - pad), float(y_max + pad))

    edges_draw = edges.copy()
    edges_draw["is_korea"] = edges_draw["exporter"].eq(korea_label) | edges_draw["importer"].eq(korea_label)
    edges_draw = edges_draw.sort_values(["is_korea", "weight"], ascending=[True, True])

    for row in edges_draw.itertuples(index=False):
        src = str(row.exporter)
        dst = str(row.importer)
        if src not in pos or dst not in pos:
            continue
        x0, y0 = pos[src]
        x1, y1 = pos[dst]
        w = float(row.weight)
        is_korea = bool(row.is_korea)
        ax.add_patch(
            FancyArrowPatch(
                (x0, y0),
                (x1, y1),
                arrowstyle="-|>",
                mutation_scale=9,
                shrinkA=14,
                shrinkB=14,
                linewidth=_edge_lw(w),
                color=korea_color if is_korea else both_color,
                alpha=0.62 if is_korea else 0.22,
                connectionstyle="arc3,rad=0.12",
                zorder=2 if is_korea else 1,
            )
        )

    for node in nodes_sorted:
        if node not in pos:
            continue
        x, y = pos[node]
        size = float(node_sizes.get(node, 240.0))
        ax.scatter([x], [y], s=size, color=node_colors.get(node, both_color), edgecolor="white", linewidth=0.9, zorder=3)

        ang = float(np.arctan2(y, x)) if (x != 0 or y != 0) else 0.0
        dx = 0.08 * np.cos(ang)
        dy = 0.08 * np.sin(ang)
        ha = "left" if np.cos(ang) >= 0 else "right"
        fs = 10 if len(nodes_sorted) <= 25 else 8
        label = label_overrides.get(node, node)
        ax.text(x + dx, y + dy, label, ha=ha, va="center", fontsize=fs, color=text_color, alpha=0.95, zorder=4)

    ax.text(
        0.985,
        0.02,
        "Node size = total citation count within selected nodes (before top-k filtering).\n"
        "Arrows run from cited research countries to citing policy sources;\n"
        "edges keep the top 3 research countries per policy source and\n"
        "the top 3 policy sources per research country;\n"
        "node types reflect roles in the selected-node graph.",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=10,
        color=text_color,
        alpha=0.9,
    )
    ax.set_title(
        "Policy source and research country citation network",
        fontsize=14,
        pad=8,
        color=text_color,
    )

    color_legend_handles = [
        Patch(facecolor=both_color, label="Policy source & research country", alpha=0.9),
        Patch(facecolor=policy_only_color, label="Policy source only", alpha=0.9),
        Patch(facecolor=research_only_color, label="Research country only", alpha=0.9),
        Patch(facecolor=korea_color, label="South Korea (highlight)", alpha=0.9),
    ]

    def _size_for_total(v: float) -> float:
        v = float(max(v, 1.0))
        v_log = float(np.log10(v))
        if vol_log.nunique() <= 1:
            return 240.0
        v_norm = (v_log - float(vol_log.min())) / (float(vol_log.max()) - float(vol_log.min()))
        return 90.0 + float(np.clip(v_norm, 0.0, 1.0)) * 430.0

    size_values = np.quantile(vol.to_numpy(dtype=float), [0.25, 0.5, 0.75]).astype(float).tolist() if len(vol) else []
    size_values = sorted({float(v) for v in size_values if v > 0})
    if len(size_values) < 3 and len(vol):
        size_values = np.quantile(vol.to_numpy(dtype=float), [0.1, 0.5, 0.9]).astype(float).tolist()
        size_values = sorted({float(v) for v in size_values if v > 0})
    if len(size_values) > 3:
        size_values = [size_values[0], size_values[len(size_values) // 2], size_values[-1]]

    size_legend_handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            color="w",
            markerfacecolor=NEUTRAL_GRAY,
            markersize=np.sqrt(_size_for_total(v)),
            alpha=0.7,
            label=_tick_compact(float(v)),
        )
        for v in size_values
    ]

    leg1 = ax.legend(
        handles=color_legend_handles,
        title="Node type",
        loc="upper left",
        bbox_to_anchor=(0.02, 0.82),
        frameon=True,
        fancybox=True,
        framealpha=1.0,
    )
    _style_legend(leg1)
    ax.add_artist(leg1)
    if size_legend_handles:
        leg2 = ax.legend(
            handles=size_legend_handles,
            title="Total citation count (selected nodes)",
            loc="lower left",
            frameon=True,
            fancybox=True,
            framealpha=1.0,
        )
        _style_legend(leg2)

    fig.patch.set_alpha(0.0)
    out_labeled = out_dir / "flow_network.png"
    _save(fig, out_labeled)
    plt.close(fig)

    # B) Background network (no labels) for hero
    fig2, ax2 = plt.subplots(figsize=(13.5, 8.6))
    ax2.set_facecolor("none")
    ax2.axis("off")

    for row in edges_draw.itertuples(index=False):
        src = str(row.exporter)
        dst = str(row.importer)
        if src not in pos or dst not in pos:
            continue
        x0, y0 = pos[src]
        x1, y1 = pos[dst]
        w = float(row.weight)
        is_korea = bool(row.is_korea)
        color = korea_color if is_korea else both_color
        alpha = 0.28 if is_korea else 0.10
        lw = _edge_lw(w) * (1.25 if is_korea else 1.0)
        ax2.plot([x0, x1], [y0, y1], color=color, alpha=alpha, linewidth=lw, solid_capstyle="round")

    for node in nodes_sorted:
        if node not in pos:
            continue
        x, y = pos[node]
        size = float(node_sizes.get(node, 240.0))
        ax2.scatter([x], [y], s=size * 0.92, color=node_colors.get(node, both_color), alpha=0.85, linewidth=0, zorder=3)

    fig2.patch.set_alpha(0.0)
    out_bg = out_dir / "hero_network.png"
    _save(fig2, out_bg, tight=False)
    plt.close(fig2)

    return out_labeled, out_bg


def main() -> int:
    args = _parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    generated: list[Path | tuple[Path, Path]] = []

    flow_network_paths = fig_flow_network(
        run_tag=args.run_tag,
        in_dir=args.in_dir,
        out_dir=args.out_dir,
        layout_seed=args.network_layout_seed,
    )
    generated.append(flow_network_paths)

    fig_country_citations_top10(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    generated.append(args.out_dir / "country_citations_top10.png")

    fig_source_type_domain_heatmap(
        run_tag=args.run_tag,
        in_dir=args.in_dir,
        out_dir=args.out_dir,
    )
    generated.append(args.out_dir / "source_type_domain.png")

    fig_korea_flows(
        run_tag=args.run_tag,
        in_dir=args.in_dir,
        out_dir=args.out_dir,
        report_figures_dir=args.report_figures_dir,
    )
    generated.append(args.out_dir / "korea_flows.png")

    fig_topic_intensity_vs_recency(
        run_tag=args.run_tag,
        in_dir=args.in_dir,
        out_dir=args.out_dir,
        report_figures_dir=args.report_figures_dir,
    )
    generated.append(args.out_dir / "topic_intensity_vs_recency.png")

    print(f"Wrote landing figures to: {args.out_dir}")
    for item in generated:
        if isinstance(item, tuple):
            for path in item:
                print(f" - {path.name}")
        else:
            print(f" - {item.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
