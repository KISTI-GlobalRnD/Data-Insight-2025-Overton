"""Build and validate the country-by-domain reference-composition cache.

The cache is valid only for the canonical sequential first-author-country
assignment and the exact local parquet inputs recorded in the CSV.  This keeps
an older cache from being reused after the country-assignment table changes.
"""

from __future__ import annotations

from pathlib import Path
from collections.abc import Sequence

import pandas as pd


CACHE_SCHEMA_VERSION = "2"
COUNTRY_ASSIGNMENT_RULE = "sequential_first_author_country_v1"
AGGREGATION_UNIT = "unique_work_domain"


def _sql_quote(value: object) -> str:
    text = "" if value is None else str(value)
    return "'" + text.replace("'", "''") + "'"


def _source_metadata(*, domains: Sequence[str], topics_path: Path, works_path: Path) -> dict[str, str]:
    topics_stat = topics_path.stat()
    works_stat = works_path.stat()
    return {
        "cache_schema_version": CACHE_SCHEMA_VERSION,
        "country_assignment_rule": COUNTRY_ASSIGNMENT_RULE,
        "aggregation_unit": AGGREGATION_UNIT,
        "domain_set": "|".join(sorted(set(domains))),
        "works_source_name": works_path.name,
        "works_source_bytes": str(works_stat.st_size),
        "works_source_mtime_ns": str(works_stat.st_mtime_ns),
        "topics_source_name": topics_path.name,
        "topics_source_bytes": str(topics_stat.st_size),
        "topics_source_mtime_ns": str(topics_stat.st_mtime_ns),
    }


def _cache_mismatch(df: pd.DataFrame, expected: dict[str, str]) -> str | None:
    for column, expected_value in expected.items():
        if column not in df.columns:
            return f"missing provenance column {column}"
        if not df[column].astype(str).eq(expected_value).all():
            return f"provenance mismatch in {column}"
    return None


def openalex_output_shares_by_country_domain(
    *,
    domains: Sequence[str],
    cache_csv: Path,
    topics_path: Path = Path("Data/openalex_topics.parquet"),
    works_path: Path = Path("Data/matched_openalex_with_oa_country_unique.parquet"),
) -> pd.DataFrame:
    """Return country-domain shares for the exact canonical input state."""
    if not topics_path.exists():
        raise FileNotFoundError(f"Missing OpenAlex topics parquet: {topics_path}")
    if not works_path.exists():
        raise FileNotFoundError(f"Missing matched OpenAlex works parquet: {works_path}")

    expected = _source_metadata(domains=domains, topics_path=topics_path, works_path=works_path)
    if cache_csv.exists():
        cached = pd.read_csv(cache_csv, dtype={column: "string" for column in expected})
        mismatch = _cache_mismatch(cached, expected)
        if mismatch is None:
            for column in ("n", "share"):
                cached[column] = pd.to_numeric(cached[column], errors="raise")
            return cached.dropna(subset=["iso2", "domain", "share"]).copy()
        print(f"[country-domain cache] rebuilding {cache_csv}: {mismatch}")

    import duckdb

    domain_list = ", ".join(_sql_quote(domain) for domain in domains)
    query = f"""
    WITH work_domains AS (
      SELECT DISTINCT
        oaid_w,
        domain
      FROM {_sql_quote(str(topics_path))}
      WHERE domain IN ({domain_list})
    ),
    agg AS (
      SELECT
        d.domain AS domain,
        w.first_author_country AS iso2,
        COUNT(*)::BIGINT AS n
      FROM work_domains d
      JOIN {_sql_quote(str(works_path))} w
        USING (oaid_w)
      WHERE
        w.first_author_country IS NOT NULL
        AND w.first_author_country <> ''
      GROUP BY d.domain, w.first_author_country
    ),
    tot AS (
      SELECT domain, SUM(n)::DOUBLE AS total
      FROM agg
      GROUP BY domain
    )
    SELECT
      agg.domain,
      agg.iso2,
      agg.n,
      CASE WHEN tot.total > 0 THEN agg.n::DOUBLE / tot.total ELSE NULL END AS share
    FROM agg
    JOIN tot USING (domain)
    """
    con = duckdb.connect()
    try:
        result = con.execute(query).df()
    finally:
        con.close()

    for column, value in expected.items():
        result[column] = value
    cache_csv.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(cache_csv, index=False)
    return result.dropna(subset=["iso2", "domain", "share"]).copy()
