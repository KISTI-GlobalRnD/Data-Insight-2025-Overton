#!/usr/bin/env python3
"""Verify headline report values from the public aggregate CSV package."""

from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from pathlib import Path


EXPECTED_CACHE_SCHEMA_VERSION = "2"
EXPECTED_COUNTRY_ASSIGNMENT_RULE = "sequential_first_author_country_v1"
EXPECTED_AGGREGATION_UNIT = "unique_work_domain"
EXPECTED_DOMAINS = {
    "Social Sciences",
    "Health Sciences",
    "Physical Sciences",
    "Life Sciences",
}
PROVENANCE_FIELDS = (
    "cache_schema_version",
    "country_assignment_rule",
    "aggregation_unit",
    "domain_set",
    "works_source_name",
    "works_source_bytes",
    "works_source_mtime_ns",
    "topics_source_name",
    "topics_source_bytes",
    "topics_source_mtime_ns",
)


def _read_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(f"Missing public aggregate: {path}")
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _float(row: dict[str, str], key: str) -> float:
    return float(row[key])


def _assert_close(label: str, actual: float, expected: float, tolerance: float = 5e-7) -> None:
    if not math.isclose(actual, expected, rel_tol=0.0, abs_tol=tolerance):
        raise AssertionError(f"{label}: expected {expected}, found {actual}")
    print(f"PASS {label}: {actual:.6f}")


def _one(rows: list[dict[str, str]], **criteria: str) -> dict[str, str]:
    matches = [row for row in rows if all(row.get(key) == value for key, value in criteria.items())]
    if len(matches) != 1:
        raise AssertionError(f"Expected one row for {criteria}, found {len(matches)}")
    return matches[0]


def _uniform_value(rows: list[dict[str, str]], field: str) -> str:
    if not rows:
        raise AssertionError("Country-domain cache is empty")
    values = {row.get(field, "") for row in rows}
    if len(values) != 1 or "" in values:
        raise AssertionError(f"Cache provenance field {field} is missing or non-uniform: {sorted(values)}")
    return next(iter(values))


def _verify_cache_provenance(root: Path, rows: list[dict[str, str]]) -> None:
    actual = {field: _uniform_value(rows, field) for field in PROVENANCE_FIELDS}
    expected_fixed = {
        "cache_schema_version": EXPECTED_CACHE_SCHEMA_VERSION,
        "country_assignment_rule": EXPECTED_COUNTRY_ASSIGNMENT_RULE,
        "aggregation_unit": EXPECTED_AGGREGATION_UNIT,
        "domain_set": "|".join(sorted(EXPECTED_DOMAINS)),
    }
    for field, expected in expected_fixed.items():
        if actual[field] != expected:
            raise AssertionError(f"Cache provenance {field}: expected {expected}, found {actual[field]}")

    for field in ("works_source_bytes", "works_source_mtime_ns", "topics_source_bytes", "topics_source_mtime_ns"):
        if int(actual[field]) <= 0:
            raise AssertionError(f"Cache provenance {field} must be a positive integer")

    manifest_path = root / "REPRODUCIBILITY_MANIFEST.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"Missing reproducibility manifest: {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    declared = manifest.get("analysis_provenance", {}).get("country_domain_output_share_cache")
    if declared != actual:
        raise AssertionError("Country-domain cache provenance does not match REPRODUCIBILITY_MANIFEST.json")
    print(f"PASS country-domain cache provenance: {actual['country_assignment_rule']} schema={actual['cache_schema_version']}")


def _verify_cache_shape(rows: list[dict[str, str]]) -> None:
    if len(rows) != 922:
        raise AssertionError(f"Country-domain cache row count: expected 922, found {len(rows)}")
    keys = [(row["domain"], row["iso2"]) for row in rows]
    if len(keys) != len(set(keys)):
        raise AssertionError("Country-domain cache contains duplicate domain-country rows")
    domains = {row["domain"] for row in rows}
    if domains != EXPECTED_DOMAINS:
        raise AssertionError(f"Country-domain cache domains: expected {sorted(EXPECTED_DOMAINS)}, found {sorted(domains)}")
    for domain in sorted(domains):
        total = sum(_float(row, "share") for row in rows if row["domain"] == domain)
        _assert_close(f"{domain} country-share sum", total, 1.0, 1e-10)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("."), help="Directory containing extracted archive paths.")
    parser.add_argument("--run-tag", default="20251026")
    args = parser.parse_args()

    root = args.root.resolve()
    report_dir = root / "Output" / "Data_Insight" / "report_figures"

    flows = _read_rows(report_dir / f"{args.run_tag}_korea_policy_research_flows_top10.csv")
    inbound_entities = ["USA", "IGO", "UK"]
    inbound_top3 = sum(
        _float(_one(flows, direction="Inbound (KR research cited by...)", entity=entity), "share")
        for entity in inbound_entities
    )
    _assert_close("Korean-research inbound top-three policy-source share", inbound_top3, 0.5490009821)

    outbound_usa_matches = [
        row
        for row in flows
        if row.get("direction", "").startswith("Outbound (") and row.get("entity") == "USA"
    ]
    if len(outbound_usa_matches) != 1:
        raise AssertionError(f"Expected one outbound USA row, found {len(outbound_usa_matches)}")
    outbound_usa = outbound_usa_matches[0]
    _assert_close("U.S. research share cited by Korean policy documents", _float(outbound_usa, "share"), 0.5519776135)
    _assert_close("U.S. linked-sample composition expected share", _float(outbound_usa, "expected_share"), 0.3610330577)

    domain_rows = _read_rows(report_dir / f"{args.run_tag}_country_domain_demand_supply_scatter.csv")
    kr_country = "Republic of Korea"
    kr_social = _one(domain_rows, country=kr_country, domain="Social Sciences")
    kr_health = _one(domain_rows, country=kr_country, domain="Health Sciences")
    _assert_close("Social-science share cited by Korean policy documents", _float(kr_social, "demand_share"), 0.7789435318)
    _assert_close("Social-science share of policy-cited Korean research", _float(kr_social, "supply_share"), 0.2313207327)
    _assert_close("Health-science share cited by Korean policy documents", _float(kr_health, "demand_share"), 0.0942178022)
    _assert_close("Health-science share of policy-cited Korean research", _float(kr_health, "supply_share"), 0.3728945665)

    decomposition_rows = _read_rows(
        report_dir / f"{args.run_tag}_korea_social_science_gap_decomposition.csv"
    )
    decomposition = {row["metric"]: _float(row, "value") for row in decomposition_rows}
    _assert_close("Observed Korea social-science share gap (pp)", decomposition["observed_social_science_gap"], 54.7622961562)
    _assert_close(
        "Korea source-type composition component (pp)",
        decomposition["source_group_composition_component"],
        38.1574743992,
    )
    _assert_close(
        "Korea within-source-type field component (pp)",
        decomposition["within_source_group_component"],
        16.6048217569,
    )
    _assert_close(
        "Korea decomposition component sum (pp)",
        decomposition["source_group_composition_component"]
        + decomposition["within_source_group_component"],
        decomposition["observed_social_science_gap"],
        1e-10,
    )

    institution_rows = _read_rows(
        report_dir / f"{args.run_tag}_korea_policy_source_concentration.csv"
    )
    kdi_row = _one(institution_rows, source_slug="kdi")
    kiep_row = _one(institution_rows, source_slug="kiep")
    kdi_kiep_share = _float(kdi_row, "citation_share") + _float(kiep_row, "citation_share")
    _assert_close("KDI and KIEP combined citation share", kdi_kiep_share, 0.9352360710)
    _assert_close("KDI social-science share", _float(kdi_row, "social_science_share"), 0.8207224089)
    _assert_close("KIEP social-science share", _float(kiep_row, "social_science_share"), 0.8600497400)

    source_type_rows = _read_rows(
        report_dir / f"{args.run_tag}_korea_policy_source_type_composition.csv"
    )
    korea_policy_think_tank = _one(
        source_type_rows,
        direction="Korea policy documents citing research",
        source_group="Think tank",
    )
    korea_research_think_tank = _one(
        source_type_rows,
        direction="Policy documents citing Korea-authored research",
        source_group="Think tank",
    )
    _assert_close(
        "Think-tank share for citations from Korea policy documents",
        _float(korea_policy_think_tank, "citation_share"),
        0.9357826021,
    )
    _assert_close(
        "Think-tank share for policy citations to Korea-authored research",
        _float(korea_research_think_tank, "citation_share"),
        0.1208212347,
    )

    peer_gap_rows = _read_rows(report_dir / f"{args.run_tag}_country_field_gap_comparison.csv")
    korea_peer_gap = _one(peer_gap_rows, country=kr_country)
    _assert_close(
        "Korea rank by absolute four-field citation-direction gap",
        _float(korea_peer_gap, "rank_by_absolute_field_gap"),
        1.0,
        0.01,
    )
    _assert_close(
        "Korea absolute four-field citation-direction gap (pp)",
        _float(korea_peer_gap, "absolute_field_gap_pp"),
        109.5245923123,
    )

    think_tank_country_rows = _read_rows(
        report_dir / f"{args.run_tag}_country_think_tank_concentration.csv"
    )
    if len(think_tank_country_rows) != 11:
        raise AssertionError(
            f"Think-tank country comparison: expected 11 rows, found {len(think_tank_country_rows)}"
        )
    korea_think_tank = _one(think_tank_country_rows, display_country=kr_country)
    brazil_think_tank = _one(think_tank_country_rows, display_country="Brazil")
    germany_think_tank = _one(think_tank_country_rows, display_country="Germany")
    _assert_close(
        "Korea think-tank citation share among 11 countries",
        _float(korea_think_tank, "think_tank_citation_share"),
        0.9357826021,
    )
    _assert_close(
        "KDI and KIEP share within Korea think-tank citations",
        _float(korea_think_tank, "top2_share_within_think_tanks"),
        0.9994159637,
    )
    _assert_close(
        "Brazil think-tank citation share among 11 countries",
        _float(brazil_think_tank, "think_tank_citation_share"),
        0.7475096774,
    )
    _assert_close(
        "Germany think-tank citation share among 11 countries",
        _float(germany_think_tank, "think_tank_citation_share"),
        0.7002273846,
    )
    if max(_float(row, "think_tank_citation_share") for row in think_tank_country_rows) != _float(
        korea_think_tank, "think_tank_citation_share"
    ):
        raise AssertionError("Korea is not the highest think-tank citation share in the 11-country table")
    print("PASS Korea has the highest think-tank citation share in the 11-country comparison")

    peer_institution_rows = _read_rows(
        report_dir / f"{args.run_tag}_kdi_kiep_topic_similar_think_tanks.csv"
    )
    if len(peer_institution_rows) != 25:
        raise AssertionError(
            f"KDI/KIEP citation-profile matches: expected 25 rows, found {len(peer_institution_rows)}"
        )
    if len({row["country"] for row in peer_institution_rows}) != 17:
        raise AssertionError("KDI/KIEP citation-profile matches must span 17 countries")
    if min(_float(row, "topic_assignments") for row in peer_institution_rows) < 500:
        raise AssertionError("KDI/KIEP citation-profile match falls below 500 topic assignments")
    if sorted(int(float(row["similarity_rank"])) for row in peer_institution_rows) != list(range(1, 26)):
        raise AssertionError("KDI/KIEP citation-profile ranks are not exactly 1 through 25")
    print("PASS KDI/KIEP citation-profile comparison: 25 institutions across 17 countries")

    eligible_think_tank_rows = _read_rows(
        report_dir / f"{args.run_tag}_foreign_think_tank_field_distribution.csv"
    )
    if len(eligible_think_tank_rows) != 748:
        raise AssertionError(
            f"Eligible foreign think tanks: expected 748 rows, found {len(eligible_think_tank_rows)}"
        )
    if len({row["country"] for row in eligible_think_tank_rows}) != 74:
        raise AssertionError("Eligible foreign think tanks must span 74 countries")
    if min(_float(row, "topic_assignments") for row in eligible_think_tank_rows) < 500:
        raise AssertionError("Eligible foreign think tank falls below 500 topic assignments")
    eligible_social = [_float(row, "Social Sciences") for row in eligible_think_tank_rows]
    _assert_close(
        "Eligible foreign think-tank median social-science share",
        statistics.median(eligible_social),
        0.6259925149,
    )
    _assert_close(
        "Eligible foreign think-tank minimum social-science share",
        min(eligible_social),
        0.0120930783,
    )
    _assert_close(
        "Eligible foreign think-tank maximum social-science share",
        max(eligible_social),
        0.9598976109,
    )
    print("PASS eligible foreign think-tank comparison: 748 institutions across 74 countries")

    peer_summary_rows = _read_rows(
        report_dir / f"{args.run_tag}_kdi_kiep_peer_institution_summary.csv"
    )
    peer_summary = {row["metric"]: _float(row, "value") for row in peer_summary_rows}
    _assert_close(
        "Eligible foreign think-tank count in summary",
        peer_summary["foreign_eligible_think_tank_count"],
        748.0,
        0.01,
    )
    _assert_close(
        "Eligible foreign think-tank country count in summary",
        peer_summary["foreign_eligible_think_tank_country_count"],
        74.0,
        0.01,
    )
    _assert_close(
        "Foreign profile-match median social-science share",
        peer_summary["foreign_profile_match_social_science_median"],
        0.7851650837,
    )
    _assert_close(
        "Foreign profile-match minimum social-science share",
        peer_summary["foreign_profile_match_social_science_min"],
        0.6706874052,
    )
    _assert_close(
        "Foreign profile-match maximum social-science share",
        peer_summary["foreign_profile_match_social_science_max"],
        0.8734120594,
    )
    _assert_close("KDI social-science share in peer comparison", peer_summary["kdi_social_science_share"], 0.8207224089)
    _assert_close("KIEP social-science share in peer comparison", peer_summary["kiep_social_science_share"], 0.8600497400)
    if sum(value > peer_summary["kdi_social_science_share"] for value in eligible_social) != 65:
        raise AssertionError("Expected 65 eligible foreign think tanks above KDI's social-science share")
    if sum(value > peer_summary["kiep_social_science_share"] for value in eligible_social) != 27:
        raise AssertionError("Expected 27 eligible foreign think tanks above KIEP's social-science share")
    print("PASS KDI and KIEP are high but within the eligible foreign think-tank distribution")
    if not (
        peer_summary["foreign_profile_match_social_science_min"]
        <= peer_summary["kdi_social_science_share"]
        <= peer_summary["foreign_profile_match_social_science_max"]
        and peer_summary["foreign_profile_match_social_science_min"]
        <= peer_summary["kiep_social_science_share"]
        <= peer_summary["foreign_profile_match_social_science_max"]
    ):
        raise AssertionError("KDI or KIEP social-science share falls outside the selected foreign comparison range")
    print("PASS KDI and KIEP social-science shares fall within the foreign profile-match range")

    output_rows = _read_rows(report_dir / f"{args.run_tag}_openalex_country_domain_output_share.csv")
    _verify_cache_provenance(root, output_rows)
    _verify_cache_shape(output_rows)
    kr_domain_shares = {
        row["domain"]: _float(row, "demand_share")
        for row in domain_rows
        if row["country"] == kr_country
    }
    us_output_shares = {
        row["domain"]: _float(row, "share")
        for row in output_rows
        if row["iso2"] == "US"
    }
    weighted_us = sum(kr_domain_shares[domain] * us_output_shares[domain] for domain in kr_domain_shares)
    _assert_close("Recomputed U.S. linked-sample composition expected share", weighted_us, 0.3610330577)

    field_sensitivity = _read_rows(
        report_dir / f"{args.run_tag}_korea_field_gap_weighting_sensitivity.csv"
    )
    expected_gaps = {
        "citation_rows_full_domain": 54.7622961562,
        "unique_works_full_domain": 58.3673300576,
        "policy_documents_equal_weight": 32.1904130834,
        "citation_rows_fractional_domain": 59.9018597851,
    }
    for weighting, expected_gap in expected_gaps.items():
        row = _one(field_sensitivity, weighting=weighting)
        _assert_close(f"Korea field-gap sensitivity {weighting} (pp)", _float(row, "gap_pp"), expected_gap)

    domain_counts = _read_rows(report_dir / f"{args.run_tag}_domain_counts.csv")
    four_domain_rows = [row for row in domain_counts if row.get("domain") in EXPECTED_DOMAINS]
    world_domain_total = sum(_float(row, "citation_rows") for row in four_domain_rows)
    world_social = _float(_one(four_domain_rows, domain="Social Sciences"), "citation_rows")
    _assert_close(
        "Full Overton policy-document social-science share",
        world_social / world_domain_total,
        0.3757656940,
    )

    missingness = _read_rows(report_dir / f"{args.run_tag}_korea_research_country_missingness.csv")
    overall_missing = _one(
        missingness,
        dimension="overall",
        stratum="All Korea policy-document citations",
    )
    _assert_close("Korea-policy citation country-missing share", _float(overall_missing, "missing_share"), 0.2730226203)
    _assert_close(
        "KDI citation country-missing share",
        _float(_one(missingness, dimension="institution", stratum="KDI"), "missing_share"),
        0.2870663636,
    )
    _assert_close(
        "KIEP citation country-missing share",
        _float(_one(missingness, dimension="institution", stratum="KIEP"), "missing_share"),
        0.2421185372,
    )

    missing_bounds = _read_rows(report_dir / f"{args.run_tag}_korea_us_share_missingness_bounds.csv")
    _assert_close(
        "U.S. share lower bound if all unassigned citations are non-U.S.",
        _float(_one(missing_bounds, scenario="all_unassigned_are_non_us"), "us_share"),
        0.4012752391,
    )
    _assert_close(
        "U.S. share upper bound if all unassigned citations are U.S.",
        _float(_one(missing_bounds, scenario="all_unassigned_are_us"), "us_share"),
        0.6742978594,
    )

    institution_summary = _read_rows(
        report_dir / f"{args.run_tag}_korea_institution_concentration_summary.csv"
    )
    kdi_kiep_summary = _one(institution_summary, source_group="KDI + KIEP")
    other_summary = _one(institution_summary, source_group="other_institutions")
    _assert_close(
        "KDI and KIEP share of all Korea policy documents",
        _float(kdi_kiep_summary, "share_of_all_policy_documents"),
        0.7140773158,
    )
    _assert_close(
        "KDI and KIEP citations per DOI-citing policy document",
        _float(kdi_kiep_summary, "citations_per_doi_citing_policy_document"),
        15.7958974359,
    )
    _assert_close(
        "Other institutions citations per DOI-citing policy document",
        _float(other_summary, "citations_per_doi_citing_policy_document"),
        2.7487113402,
    )

    sensitivity = _read_rows(report_dir / f"{args.run_tag}_s2_author_country_sensitivity_summary.csv")
    metrics = {row["metric"]: _float(row, "value") for row in sensitivity}
    _assert_close("Assigned outbound first-author citations", metrics["outbound_first_author_assigned"], 23943.0, 0.01)
    _assert_close("Inbound Korean first-author citations", metrics["inbound_first_author_kr_citations"], 92641.0, 0.01)

    print("PUBLIC_AGGREGATE_VERIFICATION=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
