#!/usr/bin/env python3
"""Verify headline report values from the public aggregate CSV package."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path


EXPECTED_CACHE_SCHEMA_VERSION = "2"
EXPECTED_COUNTRY_ASSIGNMENT_RULE = "sequential_first_author_country_v1"
EXPECTED_AGGREGATION_UNIT = "unique_work_domain"
EXPECTED_DOMAINS = {
    "Social Sciences",
    "Health Sciences",
    "Physical Sciences",
    "Life Sciences",
}
PROVENANCE_FIELDS = (
    "cache_schema_version",
    "country_assignment_rule",
    "aggregation_unit",
    "domain_set",
    "works_source_name",
    "works_source_bytes",
    "works_source_mtime_ns",
    "topics_source_name",
    "topics_source_bytes",
    "topics_source_mtime_ns",
)


def _read_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(f"Missing public aggregate: {path}")
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _float(row: dict[str, str], key: str) -> float:
    return float(row[key])


def _assert_close(label: str, actual: float, expected: float, tolerance: float = 5e-7) -> None:
    if not math.isclose(actual, expected, rel_tol=0.0, abs_tol=tolerance):
        raise AssertionError(f"{label}: expected {expected}, found {actual}")
    print(f"PASS {label}: {actual:.6f}")


def _one(rows: list[dict[str, str]], **criteria: str) -> dict[str, str]:
    matches = [row for row in rows if all(row.get(key) == value for key, value in criteria.items())]
    if len(matches) != 1:
        raise AssertionError(f"Expected one row for {criteria}, found {len(matches)}")
    return matches[0]


def _uniform_value(rows: list[dict[str, str]], field: str) -> str:
    if not rows:
        raise AssertionError("Country-domain cache is empty")
    values = {row.get(field, "") for row in rows}
    if len(values) != 1 or "" in values:
        raise AssertionError(f"Cache provenance field {field} is missing or non-uniform: {sorted(values)}")
    return next(iter(values))


def _verify_cache_provenance(root: Path, rows: list[dict[str, str]]) -> None:
    actual = {field: _uniform_value(rows, field) for field in PROVENANCE_FIELDS}
    expected_fixed = {
        "cache_schema_version": EXPECTED_CACHE_SCHEMA_VERSION,
        "country_assignment_rule": EXPECTED_COUNTRY_ASSIGNMENT_RULE,
        "aggregation_unit": EXPECTED_AGGREGATION_UNIT,
        "domain_set": "|".join(sorted(EXPECTED_DOMAINS)),
    }
    for field, expected in expected_fixed.items():
        if actual[field] != expected:
            raise AssertionError(f"Cache provenance {field}: expected {expected}, found {actual[field]}")

    for field in ("works_source_bytes", "works_source_mtime_ns", "topics_source_bytes", "topics_source_mtime_ns"):
        if int(actual[field]) <= 0:
            raise AssertionError(f"Cache provenance {field} must be a positive integer")

    manifest_path = root / "REPRODUCIBILITY_MANIFEST.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"Missing reproducibility manifest: {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    declared = manifest.get("analysis_provenance", {}).get("country_domain_output_share_cache")
    if declared != actual:
        raise AssertionError("Country-domain cache provenance does not match REPRODUCIBILITY_MANIFEST.json")
    print(f"PASS country-domain cache provenance: {actual['country_assignment_rule']} schema={actual['cache_schema_version']}")


def _verify_cache_shape(rows: list[dict[str, str]]) -> None:
    if len(rows) != 922:
        raise AssertionError(f"Country-domain cache row count: expected 922, found {len(rows)}")
    keys = [(row["domain"], row["iso2"]) for row in rows]
    if len(keys) != len(set(keys)):
        raise AssertionError("Country-domain cache contains duplicate domain-country rows")
    domains = {row["domain"] for row in rows}
    if domains != EXPECTED_DOMAINS:
        raise AssertionError(f"Country-domain cache domains: expected {sorted(EXPECTED_DOMAINS)}, found {sorted(domains)}")
    for domain in sorted(domains):
        total = sum(_float(row, "share") for row in rows if row["domain"] == domain)
        _assert_close(f"{domain} country-share sum", total, 1.0, 1e-10)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("."), help="Directory containing extracted archive paths.")
    parser.add_argument("--run-tag", default="20251026")
    args = parser.parse_args()

    root = args.root.resolve()
    report_dir = root / "Output" / "Data_Insight" / "report_figures"

    flows = _read_rows(report_dir / f"{args.run_tag}_korea_policy_research_flows_top10.csv")
    inbound_entities = ["USA", "IGO", "UK"]
    inbound_top3 = sum(
        _float(_one(flows, direction="Inbound (KR research cited by...)", entity=entity), "share")
        for entity in inbound_entities
    )
    _assert_close("Korean-research inbound top-three policy-source share", inbound_top3, 0.5490009821)

    outbound_usa = _one(flows, direction="Outbound (South Korea policy cites...)", entity="USA")
    _assert_close("U.S. research share cited by Korean policy documents", _float(outbound_usa, "share"), 0.5519776135)
    _assert_close("U.S. domain-adjusted reference share", _float(outbound_usa, "expected_share"), 0.3610330577)

    domain_rows = _read_rows(report_dir / f"{args.run_tag}_country_domain_demand_supply_scatter.csv")
    kr_country = "Republic of Korea"
    kr_social = _one(domain_rows, country=kr_country, domain="Social Sciences")
    kr_health = _one(domain_rows, country=kr_country, domain="Health Sciences")
    _assert_close("Social-science share cited by Korean policy documents", _float(kr_social, "demand_share"), 0.7789435318)
    _assert_close("Social-science share of policy-cited Korean research", _float(kr_social, "supply_share"), 0.2313207327)
    _assert_close("Health-science share cited by Korean policy documents", _float(kr_health, "demand_share"), 0.0942178022)
    _assert_close("Health-science share of policy-cited Korean research", _float(kr_health, "supply_share"), 0.3728945665)

    output_rows = _read_rows(report_dir / f"{args.run_tag}_openalex_country_domain_output_share.csv")
    _verify_cache_provenance(root, output_rows)
    _verify_cache_shape(output_rows)
    kr_domain_shares = {
        row["domain"]: _float(row, "demand_share")
        for row in domain_rows
        if row["country"] == kr_country
    }
    us_output_shares = {
        row["domain"]: _float(row, "share")
        for row in output_rows
        if row["iso2"] == "US"
    }
    weighted_us = sum(kr_domain_shares[domain] * us_output_shares[domain] for domain in kr_domain_shares)
    _assert_close("Recomputed U.S. domain-adjusted reference share", weighted_us, 0.3610330577)

    sensitivity = _read_rows(report_dir / f"{args.run_tag}_s2_author_country_sensitivity_summary.csv")
    metrics = {row["metric"]: _float(row, "value") for row in sensitivity}
    _assert_close("Assigned outbound first-author citations", metrics["outbound_first_author_assigned"], 23943.0, 0.01)
    _assert_close("Inbound Korean first-author citations", metrics["inbound_first_author_kr_citations"], 92641.0, 0.01)

    print("PUBLIC_AGGREGATE_VERIFICATION=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
