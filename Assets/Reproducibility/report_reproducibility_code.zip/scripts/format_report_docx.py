#!/usr/bin/env python3
"""Apply stable A4 report styling and page-number fields to the Pandoc DOCX."""

from __future__ import annotations

import argparse
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


FONT_NAME = "Noto Sans CJK KR"
HEADING_COLOR = RGBColor(23, 79, 115)
TEXT_COLOR = RGBColor(31, 41, 51)


def _set_run_font(run, *, size: float | None = None, color: RGBColor | None = None) -> None:
    run.font.name = FONT_NAME
    run._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_NAME)
    if size is not None:
        run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = color


def _page_field(paragraph) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    _set_run_font(run, size=8.5, color=RGBColor(95, 107, 118))
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = "1"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    for node in (begin, instr, separate, text, end):
        run._r.append(node)


def _pageref_field(paragraph, bookmark: str) -> None:
    """Insert a clickable page-reference field for a Pandoc heading bookmark."""

    paragraph.clear()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    _set_run_font(run, size=8.5, color=HEADING_COLOR)
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = f" PAGEREF {bookmark} \\h "
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = "—"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    for node in (begin, instr, separate, text, end):
        run._r.append(node)


def _set_cell_fill(cell, color: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shading = tc_pr.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        tc_pr.append(shading)
    shading.set(qn("w:fill"), color)


def _set_cell_margins(cell, *, top: int = 80, start: int = 100, bottom: int = 80, end: int = 100) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.find(qn("w:tcMar"))
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{name}"))
        if node is None:
            node = OxmlElement(f"w:{name}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def _style_block_text(paragraph) -> None:
    p_pr = paragraph._p.get_or_add_pPr()
    shading = p_pr.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        p_pr.append(shading)
    shading.set(qn("w:fill"), "EEF5F8")
    borders = p_pr.find(qn("w:pBdr"))
    if borders is None:
        borders = OxmlElement("w:pBdr")
        p_pr.append(borders)
    left = borders.find(qn("w:left"))
    if left is None:
        left = OxmlElement("w:left")
        borders.append(left)
    left.set(qn("w:val"), "single")
    left.set(qn("w:sz"), "18")
    left.set(qn("w:space"), "8")
    left.set(qn("w:color"), "2D668F")
    paragraph.paragraph_format.left_indent = Cm(0.35)
    paragraph.paragraph_format.right_indent = Cm(0.2)
    paragraph.paragraph_format.space_before = Pt(5)
    paragraph.paragraph_format.space_after = Pt(7)


def _set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    repeat = OxmlElement("w:tblHeader")
    repeat.set(qn("w:val"), "true")
    tr_pr.append(repeat)


def _prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)


def _attach_manual_page_breaks_to_following_paragraph(document: Document) -> None:
    """Replace page-break-only paragraphs with page-break-before formatting.

    A standalone break paragraph can spill onto a nearly full page in Word or
    LibreOffice, creating an otherwise blank page before the intended heading.
    Attaching the break to the following paragraph preserves the same section
    boundary without introducing that layout-dependent blank page.
    """

    paragraphs = list(document.paragraphs)
    for index, paragraph in enumerate(paragraphs):
        breaks = paragraph._p.findall(".//" + qn("w:br"))
        has_page_break = any(node.get(qn("w:type")) == "page" for node in breaks)
        if paragraph.text.strip() or not has_page_break:
            continue
        for following in paragraphs[index + 1 :]:
            if following._p.getparent() is not None:
                following.paragraph_format.page_break_before = True
                break
        parent = paragraph._p.getparent()
        if parent is not None:
            parent.remove(paragraph._p)


def format_docx(path: Path) -> None:
    document = Document(path)
    _attach_manual_page_breaks_to_following_paragraph(document)

    for section in document.sections:
        section.start_type = WD_SECTION.NEW_PAGE
        section.page_width = Cm(21.0)
        section.page_height = Cm(29.7)
        section.top_margin = Cm(2.1)
        # Keep body text and figure captions visibly clear of the page-number field.
        section.bottom_margin = Cm(3.0)
        section.left_margin = Cm(2.1)
        section.right_margin = Cm(2.1)
        section.header_distance = Cm(0.8)
        section.footer_distance = Cm(1.0)
        footer = section.footer
        paragraph = footer.paragraphs[0]
        paragraph.clear()
        _page_field(paragraph)

    style_specs = {
        "Normal": (11.0, TEXT_COLOR, 0, 4),
        "Body Text": (11.0, TEXT_COLOR, 0, 4),
        "First Paragraph": (11.0, TEXT_COLOR, 0, 4),
        "Compact": (10.5, TEXT_COLOR, 0, 2),
        "Block Text": (10.3, TEXT_COLOR, 5, 7),
        "Title": (23.0, HEADING_COLOR, 0, 8),
        "Subtitle": (12.5, RGBColor(73, 99, 114), 0, 5),
        "Author": (9.5, RGBColor(75, 85, 99), 0, 6),
        "Heading 1": (18.0, HEADING_COLOR, 14, 7),
        "Heading 2": (13.5, HEADING_COLOR, 11, 5),
        "Heading 3": (11.5, HEADING_COLOR, 8, 4),
    }
    for name, (size, color, before, after) in style_specs.items():
        if name not in document.styles:
            continue
        style = document.styles[name]
        style.font.name = FONT_NAME
        style._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_NAME)
        style.font.size = Pt(size)
        style.font.color.rgb = color
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        if name in {"Normal", "Body Text", "First Paragraph"}:
            style.paragraph_format.line_spacing = 1.35
        elif name in {"Compact", "Block Text"}:
            style.paragraph_format.line_spacing = 1.22
        elif name.startswith("Heading"):
            style.paragraph_format.keep_with_next = True

    for paragraph in document.paragraphs:
        if paragraph.style and paragraph.style.name == "Block Text":
            _style_block_text(paragraph)
        for run in paragraph.runs:
            if run.font.name is None:
                run.font.name = FONT_NAME
                run._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_NAME)

    toc_bookmarks = {
        "Data Insight": "data-insight",
        "1. 정책문헌": "chapter-1",
        "2. 한국의": "chapter-2",
        "3. 전체 자료": "chapter-3",
        "4. 결과의": "chapter-4",
        "웹 보조자료": "web-materials",
        "부록 A-E": "appendix-a",
        "참고문헌": "references",
    }

    for table in document.tables:
        table.autofit = True
        if table.rows:
            _set_repeat_table_header(table.rows[0])
        header_text = [cell.text.strip() for cell in table.rows[0].cells] if table.rows else []
        is_contents = bool(header_text and header_text[0] == "구성")
        is_core_metrics = header_text[:2] == ["지표", "직접 측정하는 것"]
        keep_table_together = len(table.rows) <= 7
        for row_index, row in enumerate(table.rows):
            _prevent_row_split(row)
            for cell in row.cells:
                _set_cell_margins(cell)
                if row_index == 0:
                    _set_cell_fill(cell, "2D668F")
                elif row_index % 2 == 0:
                    _set_cell_fill(cell, "F2F6F8")
                for paragraph in cell.paragraphs:
                    paragraph.paragraph_format.space_after = Pt(2)
                    paragraph.paragraph_format.line_spacing = 1.12
                    if keep_table_together and (row_index < len(table.rows) - 1 or is_core_metrics):
                        paragraph.paragraph_format.keep_with_next = True
                    for run in paragraph.runs:
                        _set_run_font(
                            run,
                            size=8.5,
                            color=RGBColor(255, 255, 255) if row_index == 0 else TEXT_COLOR,
                        )
                        if row_index == 0:
                            run.bold = True
        if is_contents and len(table.columns) >= 3:
            for row in table.rows[1:]:
                label = row.cells[0].text.strip()
                bookmark = next((target for prefix, target in toc_bookmarks.items() if label.startswith(prefix)), None)
                if bookmark:
                    _pageref_field(row.cells[2].paragraphs[0], bookmark)

    settings = document.settings._element
    update_fields = settings.find(qn("w:updateFields"))
    if update_fields is None:
        update_fields = OxmlElement("w:updateFields")
        settings.append(update_fields)
    update_fields.set(qn("w:val"), "true")

    document.save(path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path)
    args = parser.parse_args()
    format_docx(args.docx)
    print(f"Formatted: {args.docx}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
