#!/usr/bin/env python3
"""Apply stable A4 report styling and page-number fields to the Pandoc DOCX."""

from __future__ import annotations

import argparse
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


FONT_NAME = "Noto Sans CJK KR"
HEADING_COLOR = RGBColor(23, 79, 115)
TEXT_COLOR = RGBColor(31, 41, 51)


def _set_run_font(run, *, size: float | None = None, color: RGBColor | None = None) -> None:
    run.font.name = FONT_NAME
    run._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_NAME)
    if size is not None:
        run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = color


def _page_field(paragraph) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    _set_run_font(run, size=8.5, color=RGBColor(95, 107, 118))
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = "1"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    for node in (begin, instr, separate, text, end):
        run._r.append(node)


def _set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    repeat = OxmlElement("w:tblHeader")
    repeat.set(qn("w:val"), "true")
    tr_pr.append(repeat)


def _prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)


def format_docx(path: Path) -> None:
    document = Document(path)

    for section in document.sections:
        section.start_type = WD_SECTION.NEW_PAGE
        section.page_width = Cm(21.0)
        section.page_height = Cm(29.7)
        section.top_margin = Cm(2.1)
        # Keep body text and figure captions visibly clear of the page-number field.
        section.bottom_margin = Cm(3.0)
        section.left_margin = Cm(2.1)
        section.right_margin = Cm(2.1)
        section.header_distance = Cm(0.8)
        section.footer_distance = Cm(1.0)
        footer = section.footer
        paragraph = footer.paragraphs[0]
        paragraph.clear()
        _page_field(paragraph)

    style_specs = {
        "Normal": (11.0, TEXT_COLOR, 0, 4),
        "Title": (23.0, HEADING_COLOR, 0, 8),
        "Subtitle": (12.5, RGBColor(73, 99, 114), 0, 5),
        "Author": (9.5, RGBColor(75, 85, 99), 0, 6),
        "Heading 1": (18.0, HEADING_COLOR, 14, 7),
        "Heading 2": (13.5, HEADING_COLOR, 11, 5),
        "Heading 3": (11.5, HEADING_COLOR, 8, 4),
    }
    for name, (size, color, before, after) in style_specs.items():
        if name not in document.styles:
            continue
        style = document.styles[name]
        style.font.name = FONT_NAME
        style._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_NAME)
        style.font.size = Pt(size)
        style.font.color.rgb = color
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        if name == "Normal":
            style.paragraph_format.line_spacing = 1.35
        elif name.startswith("Heading"):
            style.paragraph_format.keep_with_next = True

    for paragraph in document.paragraphs:
        for run in paragraph.runs:
            if run.font.name is None:
                run.font.name = FONT_NAME
                run._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_NAME)

    for table in document.tables:
        table.autofit = True
        if table.rows:
            _set_repeat_table_header(table.rows[0])
        keep_table_together = len(table.rows) <= 7
        for row_index, row in enumerate(table.rows):
            _prevent_row_split(row)
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    paragraph.paragraph_format.space_after = Pt(2)
                    paragraph.paragraph_format.line_spacing = 1.12
                    if keep_table_together and row_index < len(table.rows) - 1:
                        paragraph.paragraph_format.keep_with_next = True
                    for run in paragraph.runs:
                        _set_run_font(run, size=8.5)

    settings = document.settings._element
    update_fields = settings.find(qn("w:updateFields"))
    if update_fields is None:
        update_fields = OxmlElement("w:updateFields")
        settings.append(update_fields)
    update_fields.set(qn("w:val"), "true")

    document.save(path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path)
    args = parser.parse_args()
    format_docx(args.docx)
    print(f"Formatted: {args.docx}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
