#!/usr/bin/env python3
from __future__ import annotations

"""Legacy visualization helpers (stable import path).

We keep `viz_style.py` as a thin compatibility layer so that older scripts can
import a small, stable API even as figure generators are refactored into
modules under `scripts/viz/`.

New code should prefer `viz.report.common` directly.
"""

from viz.report.common import (  # noqa: F401
    AUX_CATEG,
    AUX_HIGHLIGHT,
    AUX_PRIMARY,
    AUX_SECONDARY,
    AUX_TERTIARY,
    CORE_CATEG,
    NEUTRAL_GRAY,
    _add_edge_connectors as add_edge_connectors,
    _adjust_text_with_keepout as adjust_text_with_keepout,
    _fmt_short as fmt_short,
    _set_theme as set_theme,
    _transparent as transparent,
)

