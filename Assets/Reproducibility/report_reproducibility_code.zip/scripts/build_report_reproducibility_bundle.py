#!/usr/bin/env python3
"""Build deterministic public code and aggregate archives for the report."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import subprocess
import zipfile
from pathlib import Path

try:
    from country_domain_output_cache import CACHE_SCHEMA_VERSION, COUNTRY_ASSIGNMENT_RULE
except ModuleNotFoundError:  # imported as scripts.build_report_reproducibility_bundle
    from scripts.country_domain_output_cache import CACHE_SCHEMA_VERSION, COUNTRY_ASSIGNMENT_RULE


ROOT = Path(__file__).resolve().parents[1]
SOURCE_DIR = ROOT / "Data_Insight" / "Reproducibility"
OUTPUT_DIR = ROOT / "Data_Insight" / "Assets" / "Reproducibility"
ZIP_TIMESTAMP = (2026, 8, 4, 0, 0, 0)

CODE_FILES = (
    "scripts/country_domain_output_cache.py",
    "scripts/build_dedup_inputs.py",
    "scripts/rebuild_overton_join_outputs_dedup.py",
    "scripts/rebuild_domain_counts_unique_domain.py",
    "scripts/make_s2_author_country_sensitivity_tables.py",
    "scripts/make_report_figures_extended.py",
    "scripts/make_report_figure_panels.py",
    "scripts/sync_data_insight_assets.py",
    "scripts/make_report_interactive_plots.py",
    "scripts/make_landing_figures.py",
    "scripts/build_data_insight_site.py",
    "scripts/postprocess_data_insight_english_html.py",
    "scripts/build_report_outputs.py",
    "scripts/format_report_docx.py",
    "scripts/build_report_reproducibility_bundle.py",
    "scripts/verify_public_report_aggregates.py",
    "scripts/viz_style.py",
    "Data_Insight/Report/Report_final.md",
    "Data_Insight/Report/report_print.css",
    "Data_Insight/Report/Report_Runbook.md",
    "Data_Insight/_quarto.yml",
    "Data_Insight/SI/methods.qmd",
    "Data_Insight/SI/appendix.qmd",
    "Data_Insight/SI/reproducibility.qmd",
    "Data_Insight/SI/reproducibility_en.qmd",
    "Data_Insight/Reproducibility/README_KO.md",
    "Data_Insight/Reproducibility/README_EN.md",
    "Data_Insight/Reproducibility/requirements-report.txt",
)


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _tool_version(command: list[str]) -> str:
    try:
        completed = subprocess.run(command, cwd=ROOT, check=True, text=True, capture_output=True)
    except (FileNotFoundError, subprocess.CalledProcessError):
        return "not available"
    return (completed.stdout or completed.stderr).splitlines()[0].strip()


def _environment() -> dict[str, object]:
    packages = [
        "adjustText",
        "duckdb",
        "matplotlib",
        "numpy",
        "pandas",
        "Pillow",
        "plotly",
        "pycountry",
        "python-docx",
        "scipy",
        "seaborn",
    ]
    versions: dict[str, str] = {}
    for package in packages:
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = "not installed"
    return {
        "python": _tool_version([str(ROOT / ".venv" / "bin" / "python"), "--version"]),
        "packages": versions,
        "quarto": _tool_version(["quarto", "--version"]),
        "pandoc": _tool_version(["pandoc", "--version"]),
        "chrome": _tool_version(["google-chrome", "--version"]),
    }


def _code_paths() -> list[Path]:
    paths = [ROOT / relative for relative in CODE_FILES]
    paths.extend(sorted((ROOT / "scripts" / "viz" / "report").glob("*.py")))
    missing = [path for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing code files: " + ", ".join(str(path) for path in missing))
    return sorted(set(paths), key=lambda path: path.relative_to(ROOT).as_posix())


def _aggregate_paths(run_tag: str) -> list[Path]:
    root_csvs = sorted((ROOT / "Output" / "Data_Insight").glob(f"{run_tag}_*.csv"))
    root_csvs = [path for path in root_csvs if path.name not in {f"{run_tag}_top_policy_docs.csv", f"{run_tag}_top_openalex_papers.csv"}]
    figure_csvs = sorted((ROOT / "Output" / "Data_Insight" / "report_figures").glob(f"{run_tag}_*.csv"))
    figure_csvs = [path for path in figure_csvs if "openalex_works_" not in path.name]
    audit_csvs = sorted((ROOT / "Output" / "Data_Insight" / "dedup_audit").glob(f"{run_tag}_*.csv"))
    si_csvs = sorted((ROOT / "Data_Insight" / "Assets" / "Figures" / "si").glob("*.csv"))
    paths = root_csvs + figure_csvs + audit_csvs + si_csvs
    if not paths:
        raise FileNotFoundError(f"No aggregate CSV files found for run tag {run_tag}")
    return sorted(set(paths), key=lambda path: path.relative_to(ROOT).as_posix())


def _records(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "path": path.relative_to(ROOT).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": _sha256_path(path),
        }
        for path in paths
    ]


def _country_domain_cache_provenance(run_tag: str) -> dict[str, str]:
    cache_path = ROOT / "Output" / "Data_Insight" / "report_figures" / f"{run_tag}_openalex_country_domain_output_share.csv"
    if not cache_path.exists():
        raise FileNotFoundError(f"Missing country-domain cache: {cache_path}")
    with cache_path.open(encoding="utf-8", newline="") as handle:
        row = next(csv.DictReader(handle), None)
    if row is None:
        raise ValueError(f"Country-domain cache is empty: {cache_path}")
    fields = (
        "cache_schema_version",
        "country_assignment_rule",
        "aggregation_unit",
        "domain_set",
        "works_source_name",
        "works_source_bytes",
        "works_source_mtime_ns",
        "topics_source_name",
        "topics_source_bytes",
        "topics_source_mtime_ns",
    )
    provenance = {field: row.get(field, "") for field in fields}
    missing = [field for field, value in provenance.items() if not value]
    if missing:
        raise ValueError(f"Country-domain cache lacks provenance fields: {', '.join(missing)}")
    if provenance["cache_schema_version"] != CACHE_SCHEMA_VERSION:
        raise ValueError("Country-domain cache schema version does not match the current code")
    if provenance["country_assignment_rule"] != COUNTRY_ASSIGNMENT_RULE:
        raise ValueError("Country-domain cache assignment rule does not match the current code")
    return provenance


def _write_zip(target: Path, paths: list[Path], manifest_bytes: bytes) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in paths:
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, date_time=ZIP_TIMESTAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
        info = zipfile.ZipInfo("REPRODUCIBILITY_MANIFEST.json", date_time=ZIP_TIMESTAMP)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        archive.writestr(info, manifest_bytes)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-tag", default="20251026")
    args = parser.parse_args()

    code_paths = _code_paths()
    aggregate_paths = _aggregate_paths(args.run_tag)
    country_domain_cache_provenance = _country_domain_cache_provenance(args.run_tag)
    manifest = {
        "report_publication_date": "2025-12-31",
        "run_tag": args.run_tag,
        "data_snapshots": {"Overton": "2025.02", "OpenAlex": "2025.06"},
        "analysis_provenance": {
            "country_domain_output_share_cache": country_domain_cache_provenance,
        },
        "public_repository": "https://github.com/KISTI-GlobalRnD/Data-Insight-2025-Overton",
        "scope": {
            "included": "public aggregate tables, verification code, report and figure-generation code",
            "excluded": "licensed Overton source data and derived record-level data",
            "version_identifier": "SHA-256 values in SHA256SUMS.txt",
        },
        "environment": _environment(),
        "code_files": _records(code_paths),
        "aggregate_files": _records(aggregate_paths),
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    manifest_path = OUTPUT_DIR / "REPRODUCIBILITY_MANIFEST.json"
    manifest_path.write_bytes(manifest_bytes)
    requirements_path = OUTPUT_DIR / "requirements-report.txt"
    requirements_path.write_bytes((SOURCE_DIR / "requirements-report.txt").read_bytes())
    readme_ko = OUTPUT_DIR / "README_KO.md"
    readme_en = OUTPUT_DIR / "README_EN.md"
    readme_ko.write_bytes((SOURCE_DIR / "README_KO.md").read_bytes())
    readme_en.write_bytes((SOURCE_DIR / "README_EN.md").read_bytes())

    code_zip = OUTPUT_DIR / "report_reproducibility_code.zip"
    aggregate_zip = OUTPUT_DIR / "report_public_aggregates.zip"
    _write_zip(code_zip, code_paths, manifest_bytes)
    _write_zip(aggregate_zip, aggregate_paths, manifest_bytes)

    checksum_targets = [code_zip, aggregate_zip, manifest_path, requirements_path, readme_ko, readme_en]
    checksum_lines = [f"{_sha256_path(path)}  {path.name}" for path in checksum_targets]
    checksum_path = OUTPUT_DIR / "SHA256SUMS.txt"
    checksum_path.write_text("\n".join(checksum_lines) + "\n", encoding="utf-8")

    print(f"Built reproducibility assets in {OUTPUT_DIR}")
    print(f"code_files={len(code_paths)} aggregate_files={len(aggregate_paths)}")
    print(f"manifest_sha256={_sha256_bytes(manifest_bytes)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
