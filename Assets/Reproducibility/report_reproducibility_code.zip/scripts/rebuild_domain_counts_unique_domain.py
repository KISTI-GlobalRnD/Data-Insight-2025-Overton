#!/usr/bin/env python3
"""Rebuild domain citation counts with one row per citation and domain.

OpenAlex assigns up to three topics to a work. Multiple topics may belong to the
same domain, so joining citation rows directly to topic rows can count a single
citation more than once within that domain. This script removes that
multiplicity before creating the report's domain totals.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import duckdb


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-tag", default="20251026")
    parser.add_argument("--out-dir", type=Path, default=Path("Output/Data_Insight"))
    parser.add_argument(
        "--citations",
        type=Path,
        default=Path("Data/raw_df_citation_non_duplicated.parquet"),
    )
    parser.add_argument(
        "--topics",
        type=Path,
        default=Path("Data/openalex_topics.parquet"),
    )
    args = parser.parse_args()

    missing = [path for path in [args.citations, args.topics] if not path.exists()]
    if missing:
        raise SystemExit("Missing required inputs:\n" + "\n".join(f"- {path}" for path in missing))

    args.out_dir.mkdir(parents=True, exist_ok=True)
    out_path = args.out_dir / f"{args.run_tag}_domain_counts.csv"

    con = duckdb.connect()
    query = f"""
    WITH work_domains AS (
      SELECT DISTINCT
        oaid_w,
        NULLIF(domain, '') AS domain
      FROM read_parquet('{str(args.topics)}')
    )
    SELECT
      d.domain,
      COUNT(*)::BIGINT AS citation_rows,
      COUNT(DISTINCT c.oaid_w)::BIGINT AS unique_papers
    FROM read_parquet('{str(args.citations)}') c
    LEFT JOIN work_domains d USING (oaid_w)
    GROUP BY 1
    ORDER BY citation_rows DESC
    """
    con.execute(
        f"COPY ({query}) TO '{str(out_path)}' (FORMAT CSV, HEADER, DELIMITER ',');"
    )
    con.close()
    print(f"[ok] wrote {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
