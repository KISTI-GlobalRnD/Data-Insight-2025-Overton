#!/usr/bin/env python3
"""Create print-readable single-panel crops from dense report figures."""

from __future__ import annotations

import argparse
import os
from pathlib import Path

from PIL import Image, ImageOps


def _crop_with_padding(source: Path, target: Path, box: tuple[int, int, int, int]) -> None:
    with Image.open(source) as image:
        panel = image.crop(box)
        panel = ImageOps.expand(panel, border=24, fill=(255, 255, 255, 0))
        target.parent.mkdir(parents=True, exist_ok=True)
        panel.save(target, optimize=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-tag", default=os.environ.get("RUN_TAG", "20251026"))
    parser.add_argument(
        "--report-figures-dir",
        type=Path,
        default=Path("Output/Data_Insight/report_figures"),
    )
    args = parser.parse_args()

    figures = args.report_figures_dir
    korea = figures / f"{args.run_tag}_korea_policy_research_flows_top10.png"
    heatmap = figures / f"{args.run_tag}_policy_to_research_country_heatmap.png"

    if not korea.exists() or not heatmap.exists():
        missing = [str(path) for path in (korea, heatmap) if not path.exists()]
        raise FileNotFoundError(f"Missing source figure(s): {', '.join(missing)}")

    # Figure 2: retain the two headline country panels; the domain comparison is
    # presented separately as Figure 3 in the report.
    _crop_with_padding(
        korea,
        figures / f"{args.run_tag}_korea_policy_research_flows_inbound_top10.png",
        (0, 50, 1280, 980),
    )
    _crop_with_padding(
        korea,
        figures / f"{args.run_tag}_korea_policy_research_flows_outbound_top10.png",
        (1300, 50, 2680, 980),
    )

    # Figure 10: split the count and within-source-share heatmaps so each panel
    # can use the full portrait-page width.
    _crop_with_padding(
        heatmap,
        figures / f"{args.run_tag}_policy_to_research_country_heatmap_counts.png",
        (180, 220, 2390, 2040),
    )
    _crop_with_padding(
        heatmap,
        figures / f"{args.run_tag}_policy_to_research_country_heatmap_shares.png",
        (2350, 220, 4740, 2040),
    )

    print("Wrote four print-readable report figure panels.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
