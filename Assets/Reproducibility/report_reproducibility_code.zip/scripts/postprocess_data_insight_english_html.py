#!/usr/bin/env python3
from __future__ import annotations

import html
import json
import re
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parent.parent
DOCS_DIR = REPO_ROOT / "Data_Insight" / "docs"
LANDING_SOURCE = DOCS_DIR / "index.html"
LANDING_EN = DOCS_DIR / "index_en.html"
PROMO_JS = REPO_ROOT / "Data_Insight" / "Assets" / "Site" / "promo.js"
SEARCH_INDEX = DOCS_DIR / "search.json"
SEARCH_EN_INDEX = DOCS_DIR / "search_en.json"
QUARTO_SEARCH_JS = DOCS_DIR / "site_libs" / "quarto-search" / "quarto-search.js"
ENGLISH_SI_GLOB = "SI/*_en.html"
HANGUL_RE = re.compile(r"[가-힣]")


def _sub_required(
    text: str,
    pattern: str,
    replacement: str,
    *,
    path: Path,
    label: str,
    already_pattern: str,
) -> str:
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.S)
    if count == 1:
        return updated
    if count == 0 and re.search(already_pattern, text, flags=re.S):
        return text
    if count == 0:
        raise RuntimeError(f"{path}: navbar replacement target not found for {label}")
    raise RuntimeError(f"{path}: expected one navbar replacement for {label}, got {count}")


def _rewrite_navbar(raw: str, *, path: Path) -> str:
    text = raw
    text = _sub_required(
        text,
        r'(<a class="navbar-brand" href=")\.\./index\.html(?:\?lang=en)?(">)',
        r"\g<1>../index_en.html\g<2>",
        path=path,
        label="brand href",
        already_pattern=r'<a class="navbar-brand" href="\.\./index_en\.html">',
    )
    text = _sub_required(
        text,
        r'(<a class="nav-link" href=")\.\./index\.html(?:\?lang=en)?("[^>]*>\s*<span class="menu-text">)(?:메인|Main)(</span></a>)',
        r"\g<1>../index_en.html\g<2>Main\g<3>",
        path=path,
        label="main nav",
        already_pattern=r'<a class="nav-link" href="\.\./index_en\.html"[^>]*>\s*<span class="menu-text">Main</span></a>',
    )
    text = _sub_required(
        text,
        r'(<a class="nav-link" href=")\.\./Report/Report_final\.pdf("[^>]*>\s*<span class="menu-text">)보고서 원고\(PDF\)(</span></a>)',
        r"\g<1>../Report/Report_final.pdf\g<2>Korean Report Manuscript (PDF)\g<3>",
        path=path,
        label="report nav",
        already_pattern=r'<a class="nav-link" href="\.\./Report/Report_final\.pdf"[^>]*>\s*<span class="menu-text">(?:Main Report \(Korean PDF\)|Korean PDF|Korean Report \(PDF\)|Korean Report Manuscript \(PDF\))</span></a>',
    )
    text = _sub_required(
        text,
        r'(<a class="nav-link dropdown-toggle" href="#" id="nav-menu-"[^>]*>\s*<span class="menu-text">)확장 자료(</span>)',
        r"\g<1>English Summary\g<2>",
        path=path,
        label="SI dropdown label",
        already_pattern=r'<a class="nav-link dropdown-toggle" href="#" id="nav-menu-"[^>]*>\s*<span class="menu-text">(?:Supplementary Information|English Summary)</span>',
    )

    dropdown_items = [
        ("../SI/index.html", "확장 자료", "../SI/index_en.html", "English Summary", "Overview"),
        ("../SI/update_202603.html", "2026 데이터 업데이트", "../SI/update_202603_en.html", "2026 Update Summary", "2026 Data Update"),
        ("../SI/methods.html", "방법론·데이터 정합성", "../SI/methods_en.html", "Methods Summary", "Methods & Data Validity"),
        ("../SI/interactive.html", "인터랙티브", "../SI/interactive_en.html", "Selected Figures", "Interactive"),
        ("../SI/appendix.html", "부록", "../SI/appendix_en.html", "Definitions Summary", "Appendix"),
        ("../SI/reproducibility.html", "공개 재현성", "../SI/reproducibility_en.html", "Public Reproducibility", "Reproducibility"),
        ("../SI/next_questions.html", "다음 질문", "../SI/next_questions_en.html", "Next Questions Summary", "Next Questions"),
    ]
    for old_href, old_text, new_href, new_text, previous_text in dropdown_items:
        text = _sub_required(
            text,
            rf'(<a class="dropdown-item" href="){re.escape(old_href)}("[^>]*>\s*<span class="dropdown-text">){re.escape(old_text)}(</span></a>)',
            rf"\g<1>{new_href}\g<2>{new_text}\g<3>",
            path=path,
            label=f"dropdown {new_text}",
            already_pattern=rf'<a class="dropdown-item" href="{re.escape(new_href)}"[^>]*>\s*<span class="dropdown-text">(?:{re.escape(new_text)}|{re.escape(previous_text)})</span></a>',
        )
    return text


def _extract_js_object(source: str, const_name: str) -> dict[str, str]:
    marker = f"const {const_name} ="
    marker_pos = source.find(marker)
    if marker_pos < 0:
        raise RuntimeError(f"{PROMO_JS}: const {const_name} not found")
    start = source.find("{", marker_pos)
    if start < 0:
        raise RuntimeError(f"{PROMO_JS}: object start not found for const {const_name}")

    depth = 0
    quote = ""
    escaped = False
    end = None
    for idx in range(start, len(source)):
        ch = source[idx]
        if quote:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = ""
            continue
        if ch in ("'", '"'):
            quote = ch
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                end = idx + 1
                break

    if end is None:
        raise RuntimeError(f"{PROMO_JS}: object end not found for const {const_name}")

    raw_object = source[start:end]
    jsonish = re.sub(r",\s*([}\]])", r"\1", raw_object)
    try:
        loaded = json.loads(jsonish)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"{PROMO_JS}: could not parse const {const_name}: {exc}") from exc
    if not isinstance(loaded, dict):
        raise RuntimeError(f"{PROMO_JS}: const {const_name} is not an object")
    return {str(k): str(v) for k, v in loaded.items()}


def _landing_translations() -> dict[str, str]:
    return _extract_js_object(PROMO_JS.read_text(encoding="utf-8"), "en")


def _replace_data_i18n_text(text: str, translations: dict[str, str]) -> str:
    pattern = re.compile(
        r'(<(?P<tag>[A-Za-z0-9:-]+)\b(?=[^>]*\sdata-i18n="(?P<key>[^"]+)")[^>]*>)'
        r"(?P<body>.*?)"
        r"(</(?P=tag)>)",
        flags=re.S,
    )

    def repl(match: re.Match[str]) -> str:
        key = match.group("key")
        if key not in translations:
            return match.group(0)
        body = match.group("body")
        anchor_match = re.search(r'(\s*<a class="anchorjs-link".*?</a>\s*)$', body, flags=re.S)
        anchor = anchor_match.group(1) if anchor_match else ""
        return f"{match.group(1)}{html.escape(translations[key])}{anchor}{match.group(5)}"

    return pattern.sub(repl, text)


def _replace_data_i18n_html(text: str, translations: dict[str, str]) -> str:
    pattern = re.compile(
        r'(<(?P<tag>[A-Za-z0-9:-]+)\b(?=[^>]*\sdata-i18n-html="(?P<key>[^"]+)")[^>]*>)'
        r"(?P<body>.*?)"
        r"(</(?P=tag)>)",
        flags=re.S,
    )

    def repl(match: re.Match[str]) -> str:
        key = match.group("key")
        if key not in translations:
            return match.group(0)
        return f"{match.group(1)}{translations[key]}{match.group(5)}"

    return pattern.sub(repl, text)


def _replace_data_i18n_attrs(text: str, translations: dict[str, str]) -> str:
    tag_pattern = re.compile(r'(<[^>]+\sdata-i18n-attr="(?P<pairs>[^"]+)"[^>]*>)', flags=re.S)

    def repl(match: re.Match[str]) -> str:
        tag = match.group(1)
        pairs = match.group("pairs")
        updated = tag
        for pair in pairs.split(","):
            if ":" not in pair:
                continue
            attr, key = [part.strip() for part in pair.split(":", 1)]
            if not attr or key not in translations:
                continue
            value = html.escape(translations[key], quote=True)
            attr_pattern = re.compile(rf'(\s{re.escape(attr)}=")[^"]*(")')
            updated, count = attr_pattern.subn(rf"\g<1>{value}\g<2>", updated, count=1)
            if count == 0:
                raise RuntimeError(f"{LANDING_EN}: attribute {attr!r} missing for translation key {key!r}")
        return updated

    return tag_pattern.sub(repl, text)


def _rewrite_landing_language_switch(text: str) -> str:
    static_switch = """<div class="promo-lang-switch" role="group" aria-label="Language" data-static-lang-switch="true">
    <a class="promo-lang-btn" href="./index.html" lang="ko" hreflang="ko">KOR</a>
    <a class="promo-lang-btn is-active" href="./index_en.html" lang="en" hreflang="en" aria-current="page">ENG</a>
  </div>"""
    updated, count = re.subn(
        r'<div class="promo-lang-switch"[^>]*>\s*<button class="promo-lang-btn" type="button" data-lang="ko">KOR</button>\s*<button class="promo-lang-btn" type="button" data-lang="en">ENG</button>\s*</div>',
        static_switch,
        text,
        count=1,
        flags=re.S,
    )
    if count != 1:
        raise RuntimeError(f"{LANDING_SOURCE}: landing language switch not found")
    return updated


def _remove_landing_title_block(path: Path) -> bool:
    if not path.exists():
        raise RuntimeError(f"{path}: landing HTML not found")
    raw = path.read_text(encoding="utf-8")
    updated, count = re.subn(
        r"\n<header id=\"title-block-header\" class=\"quarto-title-block default\">.*?</header>\n",
        "\n",
        raw,
        count=1,
        flags=re.S,
    )
    if count == 0:
        return False
    path.write_text(updated, encoding="utf-8")
    return True


def _write_static_english_landing() -> bool:
    if not LANDING_SOURCE.exists():
        raise RuntimeError(f"{LANDING_SOURCE}: landing source HTML not found")

    translations = _landing_translations()
    raw = LANDING_SOURCE.read_text(encoding="utf-8")
    text = raw
    text = text.replace('lang="ko"', 'lang="en"', 1)
    text = text.replace('xml:lang="ko"', 'xml:lang="en"', 1)
    text = re.sub(
        r"<title>.*?</title>",
        f"<title>{html.escape(translations['meta.title'])}</title>",
        text,
        count=1,
        flags=re.S,
    )
    text, meta_count = re.subn(
        r'(<meta name="description" content=")[^"]*(")',
        rf"\g<1>{html.escape(translations['meta.description'], quote=True)}\g<2>",
        text,
        count=1,
    )
    if meta_count != 1:
        raise RuntimeError(f"{LANDING_SOURCE}: meta description not found")

    text = re.sub(
        r'(<h1 class="title">).*?(</h1>)',
        rf"\g<1>{html.escape(translations['meta.title'])}\g<2>",
        text,
        count=1,
        flags=re.S,
    )
    text = re.sub(
        r'(<p class="subtitle lead">).*?(</p>)',
        r"\g<1>Policy-citation analysis\g<2>",
        text,
        count=1,
        flags=re.S,
    )
    text = re.sub(
        r'(<div class="description">\s*).*?(\s*</div>)',
        rf"\g<1>{html.escape(translations['meta.description'])}\g<2>",
        text,
        count=1,
        flags=re.S,
    )

    text = _rewrite_landing_language_switch(text)
    text = _replace_data_i18n_attrs(text, translations)
    text = _replace_data_i18n_html(text, translations)
    text = _replace_data_i18n_text(text, translations)
    text = text.replace(
        '<a class="promo-btn promo-btn--primary" href="./Report/Report_final.pdf" data-i18n="hero.cta.report">Open Korean Report Manuscript (PDF)</a>',
        '<a class="promo-btn promo-btn--ghost" href="./Report/Report_final.pdf" data-i18n="hero.cta.report">Open Korean Report Manuscript (PDF)</a>',
    )
    text = text.replace(
        '<a class="promo-btn promo-btn--ghost" href="./SI/index_en.html" data-i18n="hero.cta.si" data-i18n-attr="href:hero.cta.si.href">Read English Summary</a>',
        '<a class="promo-btn promo-btn--primary" href="./SI/index_en.html" data-i18n="hero.cta.si" data-i18n-attr="href:hero.cta.si.href">Read English Summary</a>',
    )
    text = text.replace('"복사완료!"', '"Copied!"')
    text, _ = re.subn(
        r"\n<header id=\"title-block-header\" class=\"quarto-title-block default\">.*?</header>\n",
        "\n",
        text,
        count=1,
        flags=re.S,
    )

    leftover = HANGUL_RE.search(text)
    if leftover:
        line = text.count("\n", 0, leftover.start()) + 1
        snippet = text[leftover.start() : leftover.start() + 60]
        raise RuntimeError(f"{LANDING_EN}: Korean text remains at line {line}: {snippet!r}")

    previous = LANDING_EN.read_text(encoding="utf-8") if LANDING_EN.exists() else None
    if previous != text:
        LANDING_EN.write_text(text, encoding="utf-8")
        return True
    return False


def _write_english_search_index() -> tuple[int, bool]:
    if not SEARCH_INDEX.exists():
        raise RuntimeError(f"{SEARCH_INDEX}: search index not found")
    records = json.loads(SEARCH_INDEX.read_text(encoding="utf-8"))
    if not isinstance(records, list):
        raise RuntimeError(f"{SEARCH_INDEX}: search index is not a list")

    english_records = [
        record
        for record in records
        if isinstance(record, dict)
        and isinstance(record.get("href"), str)
        and (record["href"] == "index_en.html" or "_en.html" in record["href"])
    ]
    text = json.dumps(english_records, ensure_ascii=False, indent=2) + "\n"
    previous = SEARCH_EN_INDEX.read_text(encoding="utf-8") if SEARCH_EN_INDEX.exists() else None
    if previous != text:
        SEARCH_EN_INDEX.write_text(text, encoding="utf-8")
        return len(english_records), True
    return len(english_records), False


def _patch_quarto_search_js() -> bool:
    if not QUARTO_SEARCH_JS.exists():
        raise RuntimeError(f"{QUARTO_SEARCH_JS}: Quarto search script not found")
    raw = QUARTO_SEARCH_JS.read_text(encoding="utf-8")
    marker = 'const searchIndexFile = document.documentElement.lang === "en"'
    if marker in raw:
        return False

    old = '    const response = await fetch(offsetURL("search.json"));'
    new = (
        '    const searchIndexFile = document.documentElement.lang === "en" || '
        'document.documentElement.dataset.siLang === "en" ? "search_en.json" : "search.json";\n'
        "    const response = await fetch(offsetURL(searchIndexFile));"
    )
    if old not in raw:
        raise RuntimeError(f"{QUARTO_SEARCH_JS}: expected search.json fetch line not found")
    updated = raw.replace(old, new, 1)
    QUARTO_SEARCH_JS.write_text(updated, encoding="utf-8")
    return True


def _strip_trailing_whitespace(path: Path) -> bool:
    raw = path.read_text(encoding="utf-8")
    updated = "\n".join(line.rstrip() for line in raw.splitlines())
    if raw.endswith("\n"):
        updated += "\n"
    if updated == raw:
        return False
    path.write_text(updated, encoding="utf-8")
    return True


def main() -> int:
    files = sorted(DOCS_DIR.glob(ENGLISH_SI_GLOB))
    if not files:
        raise SystemExit(f"No English SI HTML files found under {DOCS_DIR / ENGLISH_SI_GLOB}")

    changed = 0
    for path in files:
        raw = path.read_text(encoding="utf-8")
        updated = _rewrite_navbar(raw, path=path)
        leftover = HANGUL_RE.search(updated)
        if leftover:
            line = updated.count("\n", 0, leftover.start()) + 1
            snippet = updated[leftover.start() : leftover.start() + 40]
            raise RuntimeError(f"{path}: Korean text remains in English HTML at line {line}: {snippet!r}")
        if updated != raw:
            path.write_text(updated, encoding="utf-8")
            changed += 1

    landing_source_title_removed = _remove_landing_title_block(LANDING_SOURCE)
    landing_changed = _write_static_english_landing()
    english_search_records, search_changed = _write_english_search_index()
    search_js_changed = _patch_quarto_search_js()
    normalized_pages = sum(
        _strip_trailing_whitespace(path)
        for path in sorted((DOCS_DIR / "SI").glob("*.html"))
    )

    print(
        "[postprocess_data_insight_english_html] "
        f"si_processed={len(files)} si_changed={changed} "
        f"landing_title_removed={int(landing_source_title_removed)} "
        f"landing_changed={int(landing_changed)} "
        f"search_en_records={english_search_records} search_changed={int(search_changed)} "
        f"search_js_changed={int(search_js_changed)} normalized_pages={normalized_pages}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
