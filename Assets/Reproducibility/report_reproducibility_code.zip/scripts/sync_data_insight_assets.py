#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import re
import shutil
from dataclasses import dataclass
from pathlib import Path


_RUN_TAG_RE = re.compile(r"^(?P<tag>\\d{8})_")


@dataclass(frozen=True)
class FigureSpec:
    src_dir_rel: str
    tagged_filename_template: str
    dest_rel: str


FIGURES: tuple[FigureSpec, ...] = (
    # report (policy-friendly summary: Data_Insight/Report/Report_final.md)
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_pubyear_trend.png",
        dest_rel="Data_Insight/Assets/Figures/pubyear_trend.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_domain_top10.png",
        dest_rel="Data_Insight/Assets/Figures/domain_top10.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_topic_scatter_citations_vs_papers.png",
        dest_rel="Data_Insight/Assets/Figures/topic_scatter_citations_vs_papers.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_topic_intensity_vs_recency.png",
        dest_rel="Data_Insight/Assets/Figures/topic_intensity_vs_recency.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_country_citations_top10.png",
        dest_rel="Data_Insight/Assets/Figures/country_citations_top10.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_country_domain_heatmap.png",
        dest_rel="Data_Insight/Assets/Figures/country_domain_heatmap.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_source_type_citations_top10.png",
        dest_rel="Data_Insight/Assets/Figures/source_type_citations_top10.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_source_type_citations_per_policy_doc.png",
        dest_rel="Data_Insight/Assets/Figures/source_type_citations_per_policy_doc.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_source_type_domain_heatmap.png",
        dest_rel="Data_Insight/Assets/Figures/source_type_domain_heatmap.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_to_research_country_heatmap.png",
        dest_rel="Data_Insight/Assets/Figures/policy_to_research_country_heatmap.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_to_research_country_heatmap_counts.png",
        dest_rel="Data_Insight/Assets/Figures/policy_to_research_country_heatmap_counts.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_to_research_country_heatmap_shares.png",
        dest_rel="Data_Insight/Assets/Figures/policy_to_research_country_heatmap_shares.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_country_self_share_selected.png",
        dest_rel="Data_Insight/Assets/Figures/policy_country_self_share_selected.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_korea_policy_research_flows_top10.png",
        dest_rel="Data_Insight/Assets/Figures/korea_policy_research_flows_top10.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_korea_policy_research_flows_inbound_top10.png",
        dest_rel="Data_Insight/Assets/Figures/korea_policy_research_flows_inbound_top10.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_korea_policy_research_flows_outbound_top10.png",
        dest_rel="Data_Insight/Assets/Figures/korea_policy_research_flows_outbound_top10.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_country_domain_demand_supply_scatter.png",
        dest_rel="Data_Insight/Assets/Figures/country_domain_demand_supply_scatter.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_research_flow_network.png",
        dest_rel="Data_Insight/Assets/Figures/variants/policy_research_flow_network.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_research_flow_network_drl.png",
        dest_rel="Data_Insight/Assets/Figures/policy_research_flow_network_drl.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_research_flow_network_fa2.png",
        dest_rel="Data_Insight/Assets/Figures/variants/policy_research_flow_network_fa2.png",
    ),
    # supplementary-only figures (SI)
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_overton_domain_subfield_network_n100_k3_drl_seed2026.png",
        dest_rel="Data_Insight/Assets/Figures/si/overton_domain_subfield_network_n100.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_pubyear_citations_per_doc_diagnostics.png",
        dest_rel="Data_Insight/Assets/Figures/si/pubyear_citations_per_doc_diagnostics.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_pubyear_citations_per_doc_diagnostics.csv",
        dest_rel="Data_Insight/Assets/Figures/si/pubyear_citations_per_doc_diagnostics.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_pubyear_2012_top1_source_type.csv",
        dest_rel="Data_Insight/Assets/Figures/si/pubyear_2012_top1_source_type.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_pubyear_citations_per_doc_by_source_type_primary.csv",
        dest_rel="Data_Insight/Assets/Figures/si/pubyear_citations_per_doc_by_source_type_primary.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_citation_distribution_ccdf.png",
        dest_rel="Data_Insight/Assets/Figures/si/citation_distribution_ccdf.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_country_domain_demand_supply_delta_heatmap.png",
        dest_rel="Data_Insight/Assets/Figures/si/country_domain_demand_supply_delta_heatmap.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_topic_top15.png",
        dest_rel="Data_Insight/Assets/Figures/si/topic_top15.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_subfield_top15.png",
        dest_rel="Data_Insight/Assets/Figures/si/subfield_top15.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_source_type_topic_heatmap.png",
        dest_rel="Data_Insight/Assets/Figures/si/source_type_topic_heatmap.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_domain_oa_share.png",
        dest_rel="Data_Insight/Assets/Figures/si/domain_oa_share.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_source_type_oa_share.png",
        dest_rel="Data_Insight/Assets/Figures/si/source_type_oa_share.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_country_self_share_top10.png",
        dest_rel="Data_Insight/Assets/Figures/si/policy_country_self_share_top10.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_research_flow_network_backbone_k3_drl.png",
        dest_rel="Data_Insight/Assets/Figures/si/policy_research_flow_network_backbone_k3_drl.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_research_flow_network_backbone_k5_drl.png",
        dest_rel="Data_Insight/Assets/Figures/si/policy_research_flow_network_backbone_k5_drl.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_research_flow_network_backbone_all_drl.png",
        dest_rel="Data_Insight/Assets/Figures/si/policy_research_flow_network_backbone_all_drl.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_source_country_density_robust.png",
        dest_rel="Data_Insight/Assets/Figures/si/policy_source_country_density_robust.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_source_country_density_robust.csv",
        dest_rel="Data_Insight/Assets/Figures/si/policy_source_country_density_robust.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_source_type_density_robust.png",
        dest_rel="Data_Insight/Assets/Figures/si/policy_source_type_density_robust.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_policy_source_type_density_robust.csv",
        dest_rel="Data_Insight/Assets/Figures/si/policy_source_type_density_robust.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_repeat_citation_sensitivity.png",
        dest_rel="Data_Insight/Assets/Figures/si/repeat_citation_sensitivity.png",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_repeat_citation_thresholds.csv",
        dest_rel="Data_Insight/Assets/Figures/si/repeat_citation_thresholds.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_repeat_citation_by_cohort.csv",
        dest_rel="Data_Insight/Assets/Figures/si/repeat_citation_by_cohort.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_korea_peer_group_by_policy_docs.csv",
        dest_rel="Data_Insight/Assets/Figures/si/korea_peer_group_by_policy_docs.csv",
    ),
    # S2: Korea author-country rule sensitivity (first-author vs any-author fractional vs corresponding)
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_s2_outbound_research_country_first_author.csv",
        dest_rel="Data_Insight/Assets/Figures/si/korea_author_country_outbound_first_author.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_s2_outbound_research_country_any_author_fractional.csv",
        dest_rel="Data_Insight/Assets/Figures/si/korea_author_country_outbound_any_author_fractional.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_s2_outbound_research_country_corresponding_fractional.csv",
        dest_rel="Data_Insight/Assets/Figures/si/korea_author_country_outbound_corresponding_fractional.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_s2_inbound_policy_source_country_shares.csv",
        dest_rel="Data_Insight/Assets/Figures/si/korea_author_country_inbound_policy_source_country.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_s2_inbound_policy_source_type_shares.csv",
        dest_rel="Data_Insight/Assets/Figures/si/korea_author_country_inbound_policy_source_type.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_s2_author_country_sensitivity_summary.csv",
        dest_rel="Data_Insight/Assets/Figures/si/korea_author_country_sensitivity_summary.csv",
    ),
    FigureSpec(
        src_dir_rel="Output/Data_Insight/report_figures",
        tagged_filename_template="{tag}_korea_inbound_flow_vs_dedup.csv",
        dest_rel="Data_Insight/Assets/Figures/si/korea_inbound_flow_vs_dedup.csv",
    ),
)


def _tags_for_template(*, output_dir: Path, tagged_filename_template: str) -> set[str]:
    if not output_dir.exists():
        return set()

    if "{tag}" not in tagged_filename_template:
        raise ValueError(f"Expected {{tag}} in template: {tagged_filename_template}")

    file_re = (
        "^"
        + re.escape(tagged_filename_template)
        .replace(re.escape("{tag}"), r"(?P<tag>\d{8})")
        + "$"
    )
    pattern = re.compile(file_re)

    tags: set[str] = set()
    for p in output_dir.iterdir():
        match = pattern.match(p.name)
        if match:
            tags.add(match.group("tag"))
    return tags


def _detect_latest_complete_run_tag(*, output_dir: Path, specs: list[FigureSpec]) -> str | None:
    if not specs:
        return None

    tag_sets: list[set[str]] = []
    for spec in specs:
        tag_sets.append(
            _tags_for_template(
                output_dir=output_dir, tagged_filename_template=spec.tagged_filename_template
            )
        )

    candidates = set.intersection(*tag_sets) if tag_sets else set()
    return max(candidates) if candidates else None


def _symlink_or_copy(*, src: Path, dst: Path, copy: bool) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.is_symlink() or dst.exists():
        if dst.is_dir() and not dst.is_symlink():
            raise ValueError(f"Refusing to overwrite directory destination: {dst}")
        dst.unlink()
    if copy:
        shutil.copy2(src, dst)
        return
    rel_src = os.path.relpath(src, start=dst.parent)
    dst.symlink_to(rel_src)


def _sync_optional_vector_siblings(*, src: Path, dst: Path, copy: bool) -> None:
    if src.suffix.lower() != ".png":
        return

    for ext in ("svg", "pdf"):
        src_sibling = src.with_suffix(f".{ext}")
        dst_sibling = dst.with_suffix(f".{ext}")
        if src_sibling.exists():
            _symlink_or_copy(src=src_sibling, dst=dst_sibling, copy=copy)
            continue
        if dst_sibling.is_symlink() or dst_sibling.exists():
            if dst_sibling.is_dir() and not dst_sibling.is_symlink():
                raise ValueError(f"Refusing to overwrite directory destination: {dst_sibling}")
            dst_sibling.unlink()


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Sync Data_Insight figure assets to the current RUN_TAG outputs "
            "(copies files by default; use --symlink for lightweight links)."
        )
    )
    parser.add_argument("--run-tag", default=os.getenv("RUN_TAG"))
    parser.add_argument("--run-tag-v1", default=os.getenv("RUN_TAG_V1"))
    parser.add_argument("--run-tag-report", default=os.getenv("RUN_TAG_REPORT"))
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--copy", action="store_true", help="Copy assets into Data_Insight (default).")
    mode.add_argument("--symlink", action="store_true", help="Symlink assets instead of copying.")
    args = parser.parse_args()

    repo_root = Path(__file__).resolve().parent.parent
    out_v1 = repo_root / "Output" / "Data_Insight"
    out_report = repo_root / "Output" / "Data_Insight" / "report_figures"

    copy_mode = not args.symlink

    run_tag_v1 = args.run_tag_v1 or args.run_tag
    run_tag_report = args.run_tag_report or args.run_tag
    if not run_tag_v1:
        run_tag_v1 = _detect_latest_complete_run_tag(
            output_dir=out_v1,
            specs=[s for s in FIGURES if s.src_dir_rel == "Output/Data_Insight"],
        )
    if not run_tag_report:
        run_tag_report = _detect_latest_complete_run_tag(
            output_dir=out_report,
            specs=[s for s in FIGURES if s.src_dir_rel == "Output/Data_Insight/report_figures"],
        )

    if not run_tag_v1:
        raise SystemExit("Could not infer RUN_TAG for v1; set RUN_TAG or RUN_TAG_V1.")
    if not run_tag_report:
        raise SystemExit("Could not infer RUN_TAG for report figures; set RUN_TAG or RUN_TAG_REPORT.")

    missing: list[str] = []
    synced = 0
    for spec in FIGURES:
        tag = run_tag_v1 if spec.src_dir_rel == "Output/Data_Insight" else run_tag_report
        src = repo_root / spec.src_dir_rel / spec.tagged_filename_template.format(tag=tag)
        dst = repo_root / spec.dest_rel
        if not src.exists():
            missing.append(str(src))
            continue
        _symlink_or_copy(src=src, dst=dst, copy=copy_mode)
        _sync_optional_vector_siblings(src=src, dst=dst, copy=copy_mode)
        synced += 1

    if missing:
        missing_list = "\n".join(f"- {p}" for p in missing)
        raise SystemExit(f"Missing source assets ({len(missing)}):\n{missing_list}")

    mode_label = "copy" if copy_mode else "symlink"
    print(
        f"[sync_data_insight_assets] mode={mode_label} v1={run_tag_v1} report={run_tag_report} synced={synced}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
