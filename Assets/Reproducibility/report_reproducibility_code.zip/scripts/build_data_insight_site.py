#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
from pathlib import Path


_RUN_TAG_RE = re.compile(r"^(?P<tag>\d{8})_")
_SYNC_REPORT_RE = re.compile(r"\breport=(?P<tag>\d{8})\b")


def _infer_latest_run_tag(*, output_dir: Path) -> str | None:
    if not output_dir.exists():
        return None
    tags: list[str] = []
    for p in output_dir.iterdir():
        match = _RUN_TAG_RE.match(p.name)
        if match:
            tags.append(match.group("tag"))
    return max(tags) if tags else None


def _run(
    cmd: list[str],
    *,
    cwd: Path,
    env: dict[str, str],
    dry_run: bool,
    capture_stdout: bool = False,
) -> subprocess.CompletedProcess[str]:
    rendered = " ".join(subprocess.list2cmdline([c]) if " " in c else c for c in cmd)
    print(f"+ {rendered}")
    if dry_run:
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    return subprocess.run(
        cmd,
        cwd=cwd,
        env=env,
        text=True,
        check=True,
        capture_output=capture_stdout,
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Build the Data_Insight GitHub Pages site (landing + Quarto SI).\n\n"
            "Runs:\n"
            "  1) scripts/sync_data_insight_assets.py\n"
            "  2) scripts/make_landing_figures.py\n"
            "  3) quarto render Data_Insight\n\n"
            "Use stable paths under Data_Insight/Assets/** as the 'template interface'."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--run-tag",
        default=os.environ.get("RUN_TAG"),
        help="Input filename prefix (YYYYMMDD). If omitted, tries to infer from existing outputs.",
    )
    parser.add_argument(
        "--symlink",
        action="store_true",
        help="Symlink assets instead of copying when syncing figure assets.",
    )
    parser.add_argument("--skip-sync", action="store_true", help="Skip scripts/sync_data_insight_assets.py.")
    parser.add_argument("--skip-landing", action="store_true", help="Skip scripts/make_landing_figures.py.")
    parser.add_argument("--skip-render", action="store_true", help="Skip quarto render Data_Insight.")
    parser.add_argument(
        "--render-no-clean",
        action="store_true",
        help="Pass --no-clean to quarto render (preserves Data_Insight/docs contents like .git).",
    )
    parser.add_argument(
        "--render-clean",
        action="store_true",
        help="Pass --clean to quarto render (deletes and recreates the output dir; use with care).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print commands without executing.",
    )
    args = parser.parse_args()
    if args.render_clean and args.render_no_clean:
        raise SystemExit("--render-clean and --render-no-clean are mutually exclusive.")

    repo_root = Path(__file__).resolve().parent.parent
    venv_python = repo_root / ".venv" / "bin" / "python"
    python_exec = str(venv_python) if venv_python.exists() else sys.executable
    env = os.environ.copy()

    run_tag = args.run_tag or env.get("RUN_TAG")
    if not run_tag and (args.skip_sync or args.dry_run):
        inferred = _infer_latest_run_tag(output_dir=repo_root / "Output" / "Data_Insight" / "report_figures")
        inferred = inferred or _infer_latest_run_tag(output_dir=repo_root / "Output" / "Data_Insight")
        run_tag = inferred
    if run_tag:
        env["RUN_TAG"] = run_tag

    if not args.skip_sync:
        sync_cmd = [python_exec, "scripts/sync_data_insight_assets.py"]
        if args.symlink:
            sync_cmd.append("--symlink")
        result = _run(sync_cmd, cwd=repo_root, env=env, dry_run=args.dry_run, capture_stdout=True)
        if result.stdout:
            print(result.stdout, end="" if result.stdout.endswith("\n") else "\n")

        if "RUN_TAG" not in env:
            match = _SYNC_REPORT_RE.search(result.stdout or "")
            if match:
                env["RUN_TAG"] = match.group("tag")

    if not args.skip_landing:
        if "RUN_TAG" not in env:
            raise SystemExit(
                "RUN_TAG is required to build landing figures; pass --run-tag or run sync step to auto-detect."
            )
        _run(
            [
                python_exec,
                "scripts/make_landing_figures.py",
                "--run-tag",
                env["RUN_TAG"],
            ],
            cwd=repo_root,
            env=env,
            dry_run=args.dry_run,
        )

    if not args.skip_render:
        quarto_cmd = ["quarto", "render", "Data_Insight"]
        output_git = repo_root / "Data_Insight" / "docs" / ".git"
        if args.render_clean:
            quarto_cmd.append("--clean")
        elif args.render_no_clean or output_git.exists():
            quarto_cmd.append("--no-clean")
        _run(quarto_cmd, cwd=repo_root, env=env, dry_run=args.dry_run)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
