#!/usr/bin/env python3
"""
Build cleaned/deduplicated input parquets used by the report/site pipelines.

Motivation
- Overton policy meta tag files can contain duplicate rows for the same
  (policy_document_id, tag) pair (e.g., UK repeated dozens of times for a doc).
  This creates join(row multiplicity) inflation when aggregating citation logs.
- The local OpenAlex "matched works" parquet can contain multiple rows per work,
  sometimes with conflicting first-author country codes. Joining it directly can
  also inflate counts.

This script creates:
1) Clean Overton policy meta parquets (distinct doc-tag pairs)
2) A unique-per-work OpenAlex matched parquet (one row per oaid_w) with a
   deterministic first-author-country waterfall:
   - standardized country mode by row frequency;
   - otherwise, a single unambiguous raw ISO2 country code;
   - otherwise, unresolved.

Run:
  uv run python scripts/build_dedup_inputs.py
  uv run python scripts/build_dedup_inputs.py --force
"""

from __future__ import annotations

import argparse
from pathlib import Path

import duckdb


def _copy_parquet(con: duckdb.DuckDBPyConnection, *, query: str, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # DuckDB COPY expects POSIX paths in SQL strings.
    con.execute(f"COPY ({query}) TO '{str(out_path)}' (FORMAT PARQUET);")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--force", action="store_true", help="Rebuild outputs even if they already exist.")
    args = ap.parse_args()

    # ---- Overton meta (dedup) ----
    country_in = Path("Data/overton_policy_meta/policy_source_country.parquet")
    type_in = Path("Data/overton_policy_meta/policy_source_type.parquet")
    if not country_in.exists():
        raise SystemExit(f"Missing input: {country_in}")
    if not type_in.exists():
        raise SystemExit(f"Missing input: {type_in}")

    country_out = Path("Data/overton_policy_meta/policy_source_country_clean.parquet")
    type_out = Path("Data/overton_policy_meta/policy_source_type_clean.parquet")

    # ---- OpenAlex matched works (unique) ----
    matched_in = Path("Data/matched_openalex_with_oa_country.parquet")
    matched_out = Path("Data/matched_openalex_with_oa_country_unique.parquet")
    if not matched_in.exists():
        raise SystemExit(f"Missing input: {matched_in}")

    con = duckdb.connect()

    if args.force or not country_out.exists():
        print(f"[build] {country_out}")
        _copy_parquet(
            con,
            query=f"""
            SELECT DISTINCT
              CAST(policy_document_id AS VARCHAR) AS policy_document_id,
              trim(CAST(policy_source_country AS VARCHAR)) AS policy_source_country
            FROM read_parquet('{str(country_in)}')
            WHERE policy_document_id IS NOT NULL
              AND policy_source_country IS NOT NULL
              AND trim(CAST(policy_source_country AS VARCHAR)) <> ''
            """,
            out_path=country_out,
        )

    if args.force or not type_out.exists():
        print(f"[build] {type_out}")
        _copy_parquet(
            con,
            query=f"""
            SELECT DISTINCT
              CAST(policy_document_id AS VARCHAR) AS policy_document_id,
              trim(CAST(policy_source_type AS VARCHAR)) AS policy_source_type
            FROM read_parquet('{str(type_in)}')
            WHERE policy_document_id IS NOT NULL
              AND policy_source_type IS NOT NULL
              AND trim(CAST(policy_source_type AS VARCHAR)) <> ''
            """,
            out_path=type_out,
        )

    if args.force or not matched_out.exists():
        print(f"[build] {matched_out}")
        # Deterministic first-author-country waterfall. Prefer the standardized
        # country mode. Only when that is unavailable, accept a raw ISO2 code
        # if the work has exactly one distinct raw code. Ambiguous raw codes
        # remain unresolved rather than changing the country estimand.
        _copy_parquet(
            con,
            query=f"""
            WITH base AS (
              SELECT
                CAST(oaid_w AS VARCHAR) AS oaid_w,
                CAST(doi AS VARCHAR) AS doi,
                CAST(title AS VARCHAR) AS title,
                CAST(abstract AS VARCHAR) AS abstract,
                CAST(pubyear AS BIGINT) AS pubyear,
                CAST(is_oa AS VARCHAR) AS is_oa,
                trim(CAST(first_author_country AS VARCHAR)) AS first_author_country,
                CAST(first_author_continent AS VARCHAR) AS first_author_continent,
                upper(trim(CAST(first_author_country_raw AS VARCHAR))) AS first_author_country_raw
              FROM read_parquet('{str(matched_in)}')
              WHERE oaid_w IS NOT NULL
            ),
            country_counts AS (
              SELECT oaid_w, first_author_country, COUNT(*)::BIGINT AS n
              FROM base
              WHERE first_author_country IS NOT NULL AND first_author_country <> ''
              GROUP BY 1, 2
            ),
            country_mode AS (
              SELECT oaid_w, first_author_country AS first_author_country_mode
              FROM (
                SELECT
                  oaid_w,
                  first_author_country,
                  n,
                  ROW_NUMBER() OVER (PARTITION BY oaid_w ORDER BY n DESC, first_author_country ASC) AS rn
                FROM country_counts
              )
              WHERE rn = 1
            ),
            raw_country_counts AS (
              SELECT oaid_w, first_author_country_raw, COUNT(*)::BIGINT AS n
              FROM base
              WHERE first_author_country_raw IS NOT NULL
                AND first_author_country_raw <> ''
                AND regexp_full_match(first_author_country_raw, '^[A-Z]{{2}}$')
              GROUP BY 1, 2
            ),
            raw_country_single AS (
              SELECT oaid_w, MAX(first_author_country_raw) AS first_author_country_raw_single
              FROM raw_country_counts
              GROUP BY 1
              HAVING COUNT(*) = 1
            ),
            picked_meta AS (
              SELECT
                m.oaid_w,
                m.first_author_country_mode AS first_author_country,
                ANY_VALUE(b.first_author_continent) AS first_author_continent,
                ANY_VALUE(b.first_author_country_raw) AS first_author_country_raw
              FROM country_mode m
              JOIN base b
                ON b.oaid_w = m.oaid_w AND b.first_author_country = m.first_author_country_mode
              GROUP BY 1, 2
            ),
            agg AS (
              SELECT
                oaid_w,
                ANY_VALUE(doi) AS doi,
                ANY_VALUE(title) AS title,
                ANY_VALUE(abstract) AS abstract,
                MAX(pubyear) AS pubyear,
                CASE WHEN SUM(CASE WHEN is_oa = 'Y' THEN 1 ELSE 0 END) > 0 THEN 'Y' ELSE 'N' END AS is_oa
              FROM base
              GROUP BY 1
            )
            SELECT
              a.oaid_w,
              a.doi,
              a.title,
              a.abstract,
              a.pubyear,
              a.is_oa,
              COALESCE(pm.first_author_country, rs.first_author_country_raw_single) AS first_author_country,
              pm.first_author_continent,
              COALESCE(pm.first_author_country_raw, rs.first_author_country_raw_single) AS first_author_country_raw,
              CASE
                WHEN pm.first_author_country IS NOT NULL THEN 'standardized_mode'
                WHEN rs.first_author_country_raw_single IS NOT NULL THEN 'raw_single_fallback'
                ELSE 'unresolved'
              END AS first_author_country_assignment_stage
            FROM agg a
            LEFT JOIN picked_meta pm USING (oaid_w)
            LEFT JOIN raw_country_single rs USING (oaid_w)
            """,
            out_path=matched_out,
        )

    con.close()
    print("[ok] built dedup inputs")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
