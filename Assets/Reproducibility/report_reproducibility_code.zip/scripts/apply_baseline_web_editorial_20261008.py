#!/usr/bin/env python3
"""Apply approved issue-68 editorial decisions to the 2025 web supplements.

The publisher's eight chapters and this site's four-chapter manuscript have
different numbering. Keep the PDF mapping and provide a separate issue map.
No data, figures, print deliverables or latest-analysis pages are rewritten.
Run with: uv run --with openpyxl python scripts/apply_baseline_web_editorial_20261008.py
"""
from pathlib import Path
import openpyxl

ROOT = Path(__file__).resolve().parents[1]
SI = ROOT / 'Data_Insight/SI'
BOOK = ROOT / 'output/데이터인사이트68호_인쇄본_교정지시표.xlsx'


def replace(path, old, new):
    text = path.read_text()
    if new in text:
        return
    if old not in text:
        raise AssertionError(f'Missing editorial target: {path.name}: {old[:60]}')
    assert text.count(old) == 1, f'Ambiguous editorial target: {path.name}'
    path.write_text(text.replace(old, new))


def main():
    workbook = openpyxl.load_workbook(BOOK, read_only=True, data_only=True)
    corrections = {row[0]: row for row in list(workbook['교정지시표'].values)[1:] if isinstance(row[0], int)}
    assert len(corrections) == 152
    workbook.close()

    ko_old = '**2025 기준판 안내.** 이 페이지의 정의·수치·연결 그림은 2025 보고서 기준이다. 새 결과와 이번 집계 규칙은 [2026년 10월 온라인 업데이트](update_202603.qmd)에서 확인한다.'
    ko_new = '**2025 기준판 · 제68호 교정 반영.** 이 페이지는 2025 데이터의 설명에 해당하는 확정 교정 사항을 반영했다. 교정 반영일은 2026년 10월 8일이며, 연결된 PDF는 편집 전 원고다. 새 데이터의 결과와 집계 규칙은 [2026년 10월 온라인 업데이트](update_202603.qmd)에서 별도로 확인한다.'
    en_old = '**2025 baseline edition.** The definitions, values and linked figures on this page refer to the 2025 report. See the [October 2026 online update](update_202603_en.qmd) for the new results and their own aggregation rules.'
    en_new = '**2025 baseline · issue 68 editorial corrections.** This page describes the 2025 analysis with editorial corrections incorporated on 8 October 2026. The linked PDF is the manuscript prepared before publication editing. Results from newer data and their calculation rules are reported separately in the [October 2026 online update](update_202603_en.qmd).'
    for name in ['index', 'methods', 'appendix', 'interactive', 'next_questions', 'reproducibility']:
        replace(SI / f'{name}.qmd', ko_old, ko_new)
        replace(SI / f'{name}_en.qmd', en_old, en_new)

    index = SI / 'index.qmd'
    for old, number, anchor in [
        ('정책 출처별 학술논문 인용 총 건수와 인용이 있는 정책문헌당 평균', 133, 'bg-hubs'),
        ('한국 연구를 인용한 정책 출처와 한국 정책문헌이 인용한 연구 국가', 134, 'bg-korea'),
        ('인용된 논문당 DOI 연결 인용 건수와 최근 고유 논문 비중', 136, 'bg-two-speed'),
        ('NKIS 참고문헌을 연결해 추가할 분석', 139, 'bg-nkis'),
    ]:
        replace(index, f'### {old} {{#{anchor}}}', f'### {corrections[number][6]} {{#{anchor}}}')
    replace(index, '54.9%와 55.2%는 분모와 집계 단위가 다르므로 별도로 제시한다.',
            '54.9%와 55.2%는 집계 대상과 산출 기준이 다르므로 두 인용 방향을 나눠 해석해야 한다.')
    replace(index, '**연구 국가**은', '**연구 국가**는')
    replace(index, '선행연구는 논문이 정책문헌에 인용된 횟수가 학술 인용 수의 단순한 복사본이 아니라고 설명한다. 정책문헌에 인용되는 논문은 전체 연구의 일부이고, 분야와 문헌 유형에 따라 선택되는 구성이 다르며, 논문 단위의 학술 인용 수와 정책문헌에 인용된 횟수도 같은 순위를 만들지 않을 수 있다.',
            '선행연구는 정책문헌이 전체 연구의 일부를 선택적으로 인용하며, 그 구성이 분야와 문헌 유형에 따라 다름을 보여 준다. 학술 인용 수와 정책문헌에서 인용된 횟수도 같은 순위를 만들지 않을 수 있다.')
    # Approved title changes are mapped by subject, never by PDF page number.
    targets = [
        (132, '1장', '#bg-scholarly-policy'),
        (133, '2장', '#bg-hubs'),
        (134, '3장', 'interactive.qmd#si-fig-11'),
        (135, '4장', 'interactive.qmd#si-fig-8'),
        (136, '5장', '#bg-two-speed'),
        (137, '6장', 'next_questions.qmd#baseline-indicators'),
        (138, '7장', 'methods.qmd#method-guardrails'),
        (139, '8장', '#bg-nkis'),
        (140, '부록 A', 'interactive.qmd#si-fig-1'),
        (141, '부록 B', 'interactive.qmd#si-fig-5'),
        (142, '부록 C', 'interactive.qmd#si-fig-9'),
        (143, '부록 D', 'next_questions.qmd#baseline-indicators'),
        (144, '부록 E', 'methods.qmd#method-scope'),
    ]
    rows = '\n'.join(f'| {label} | {corrections[number][6]} | [관련 보조자료]({url}) |' for number, label, url in targets)
    heading = '## 보고서 원고(PDF) ↔ 확장 자료 연결 {#report-extended-map}'
    title_map = f'''## 제68호 장 제목과 웹 보조자료 연결 {{#issue68-web-map}}

제68호 인쇄본 교정에서 확정한 장 제목을 기준으로 관련 보조자료를 찾을 수 있다. 연결된 편집 전 PDF는 장·그림 번호가 다르므로, PDF를 읽을 때는 아래의 별도 연결표를 참고한다.

| 구성 | 확정 장 제목 | 웹에서 더 볼 것 |
|---|---|---|
{rows}

'''
    if '## 제68호 장 제목과 웹 보조자료 연결' not in index.read_text():
        replace(index, heading, title_map + heading)
    replace(index, '| [2025 기준 원고](../Report/Report_final.pdf) | 원고 발행일과 내용 기준일이 2025년 12월 31일인 편집 전 보고서 원고 |',
            '| [2025 기준 원고](../Report/Report_final.pdf) | 원고 발행일과 내용 기준일이 2025년 12월 31일인 편집 전 보고서 원고 |\n| [제68호 교정을 반영한 웹 보조자료](#issue68-web-map) | 기존 데이터의 설명·용어 교정과 확정 장 제목별 연결 |')

    methods = SI / 'methods.qmd'
    replace(methods, '분모가 다른 지표끼리는 직접 비교하지 않는다.', '집계 대상과 산출 기준이 다른 지표끼리는 직접 비교하지 않는다.')
    replace(methods, '- 분석 단위: Overton 정책문헌을 중복 제거한 고유 정책문헌',
            '- 정책문헌 단위: 중복을 제거한 고유 정책문헌\n- 인용 단위: 정책문헌이 DOI로 연결된 학술논문을 인용한 관계')
    replace(methods, '먼저 이번 분석이 어디까지를 포함하는지 분명히 해 둘 필요가 있다.',
            '분석 모집단은 해당 스냅샷에서 관측되고 DOI로 연결된 학술논문 인용이다. 모든 정책문헌이나 모든 정책 근거를 포괄하지 않는다.')
    replace(methods, '- 정책 출처 비교는 하위 분류를 최상위 범주에 통합하지만, 출처 유형 태그는 서로 중복될 수 있다.',
            '- ' + corrections[112][6])

    appendix = SI / 'appendix.qmd'
    replace(appendix, '- 97.6%와 마찬가지로, 이 값도 Overton 기준 시점 데이터의 **DOI-연결 관측 범위**에 한정된다.',
            '- 97.6%와 마찬가지로, 이 값도 제공 덤프(2025.02)의 **DOI-연결 관측 범위**에 한정된다.')
    replace(appendix, '이 섹션은 본문 지표의 분모, 계산식, 제한 사항을 정리한다.\n같은 수치라도 분모가 다르면 결론이 달라질 수 있으므로, 지표 정의와 결측 조건을 먼저 확인해야 한다.',
            '이 절은 본문 지표의 집계 대상, 계산식, 해석상의 한계를 정리한다.\n같은 수치라도 산출 기준이 다르면 의미가 달라지므로, 분석 모집단과 지표 정의·결측 조건을 먼저 확인해야 한다.')
    replace(appendix, '**“48.1%가 2회 이상 반복 인용된다”는 무엇을 뜻하나?**',
            '**“인용된 고유 논문의 48.1%가 서로 다른 정책문헌 2편 이상에서 인용됐다”는 무엇을 뜻하나?**')
    replace(appendix, '서로 다른 고유 정책문헌에서 몇 번 인용되었는지', '서로 다른 고유 정책문헌 몇 편에서 인용되었는지')
    replace(appendix, '- 기준: 2개 이상의 서로 다른 정책문헌에서 인용된 논문을 “2회 이상 반복 인용”으로 정의',
            '- 기준: 서로 다른 정책문헌 2편 이상에서 인용된 논문. 같은 문헌 안의 반복 언급은 세지 않는다.')
    replace(appendix, 'Overton 2025.02×OpenAlex 2025.06 결합 데이터에서 인용된 고유 논문 6,532,365편 중 3,143,234편(48.1%)이 2회 이상 반복 인용에 해당한다.',
            'Overton 2025.02×OpenAlex 2025.06 결합 데이터에서 인용된 고유 논문 6,532,365편 중 3,143,234편(48.1%)이 서로 다른 정책문헌 2편 이상에서 인용됐다.')
    replace(appendix, '정책문헌 수집·정리의 시차(수집 지연)와 발행 직후 인용 기록이 완전히 누적되지 않는 효과가 함께 작동했을 가능성이 크다.\n따라서 최근 연도 수치에는 수집·색인 지연이 포함될 수 있다.',
            '단일 스냅샷의 최근 연도 관측치에는 수집·색인 지연이 포함될 수 있다.\n같은 정의로 자료를 다시 집계해 관측치가 얼마나 달라지는지 확인하고, 정책 출처·문서 구성의 변화도 함께 점검해야 한다.')

    plots = SI / 'interactive.qmd'
    for old, new in [
        ('**연구 국가**은', '**연구 국가**는'),
        ('2.4절 전체 자료의 배경 관측 가운데 토픽의 시간 구성', '3.2절 토픽별 시간 구성·부록 A1–A3'),
        ('2.2절 정책 출처별 차이는 한국 결과를 읽는 배경이다', '3.1절 정책 출처 비교·부록 B'),
        ('2.3절 한국 연구는 어디에서 인용되고, 한국 정책문헌은 어떤 연구를 인용하는가', '2장 한국의 두 인용 방향·부록 C'),
        ('### 그림 3. 토픽별 인용수와 고유 논문수. 점 크기는 오픈액세스 비중', '### 그림 3. 토픽별 정책문헌 인용 건수와 인용된 고유 논문 수. 점 크기는 오픈액세스 비중'),
    ]:
        replace(plots, old, new)

    questions = SI / 'next_questions.qmd'
    replace(questions, '## 이번 분기 반복 점검 질문(4개)',
            f'## {corrections[137][6]} {{#baseline-indicators}}\n\n아래 네 가지 지표는 2025 기준값이다. 새 자료와 비교할 때는 수집 범위·연구 국가 부여 규칙·집계 기준의 변경을 함께 확인한다.')
    institution_note = '''\n\n### 함께 점검할 한국 정책문헌의 기관 구성

2025 기준판에서 한국 정책문헌의 DOI 연결 인용 32,935건 중 KDI·KIEP가 93.5%를 차지했다. 인용이 있는 문헌당 평균도 두 기관은 15.8건, 그 밖의 기관은 2.7건이었다. 따라서 국가별 비중과 함께 기관별 인용 비중·문헌 수·문헌당 평균을 확인한다.

이 수치를 모든 한국 정책문헌의 특성으로 확대하지 않는다. 기관·출처 유형 구성의 세부 결과는 [부록 C14](appendix.qmd#appendix-c14-korea-source-composition)에서, 새 데이터의 기관 구성은 [2026년 10월 업데이트](update_202603.qmd)에서 별도로 확인한다.
'''
    if '### 함께 점검할 한국 정책문헌의 기관 구성' not in questions.read_text():
        questions.write_text(questions.read_text() + institution_note)
    en_index = SI / 'index_en.qmd'
    replace(en_index, '## Summary pages',
            'The [approved issue 68 chapter titles and supplement map](index.qmd#issue68-web-map) are available in Korean. Their numbering differs from the linked manuscript before publication editing.\n\n## Summary pages')
    print('Applied baseline editorial corrections and approved 13-title navigation map; new-data results retained separately.')


if __name__ == '__main__':
    main()
