#!/usr/bin/env python3
"""Build the official DOCX/PDF report outputs from Report_final.md."""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT_DIR = ROOT / "Data_Insight" / "Report"
SOURCE = REPORT_DIR / "Report_final.md"
DOCX = REPORT_DIR / "Report_final.docx"
PDF = REPORT_DIR / "Report_final.pdf"
HTML = REPORT_DIR / ".tmp_Report_final.html"
CSS = REPORT_DIR / "report_print.css"


def _run(command: list[str]) -> None:
    subprocess.run(command, cwd=ROOT, check=True)


def main() -> int:
    resource_path = f"{ROOT}:{REPORT_DIR}"
    _run(
        [
            "pandoc",
            str(SOURCE),
            "-o",
            str(DOCX),
            f"--resource-path={resource_path}",
        ]
    )
    _run(["uv", "run", "python", "scripts/format_report_docx.py", str(DOCX)])

    _run(
        [
            "pandoc",
            str(SOURCE),
            "-o",
            str(HTML),
            "--standalone",
            "--embed-resources",
            f"--resource-path={resource_path}",
            f"--css={CSS}",
        ]
    )
    try:
        _run(
            [
                "google-chrome",
                "--headless",
                "--disable-gpu",
                "--no-sandbox",
                f"--print-to-pdf={PDF}",
                "--no-pdf-header-footer",
                HTML.as_uri(),
            ]
        )
    finally:
        HTML.unlink(missing_ok=True)

    site_pdf = ROOT / "Data_Insight" / "docs" / "Report" / "Report_final.pdf"
    if site_pdf.parent.exists():
        shutil.copy2(PDF, site_pdf)

    print(f"Built: {DOCX}")
    print(f"Built: {PDF}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
