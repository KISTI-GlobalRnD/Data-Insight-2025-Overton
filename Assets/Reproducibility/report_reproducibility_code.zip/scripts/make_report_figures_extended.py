#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# When executed as a script (`python scripts/...py`), `scripts/` is on `sys.path`.
# When imported as a module (`import scripts.make_report_figures_extended`), it isn't.
# Ensure our local `viz/` package is importable in both cases.
_SCRIPTS_DIR = Path(__file__).resolve().parent
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))

from viz.report.fig01_pubyear_trend import figure_1_pubyear_trend
from viz.report.fig02_domain_top10 import figure_2_domain_top10
from viz.report.fig03_topic_scatter import figure_3_topic_scatter
from viz.report.fig04_topic_intensity_vs_recency import figure_4_topic_intensity_vs_recency
from viz.report.fig05_country_citations import figure_5_country_citations
from viz.report.fig06_country_domain_heatmap import figure_6_country_domain_heatmap
from viz.report.fig07_source_type_citations import figure_7_source_type_citations
from viz.report.fig08_source_type_density import figure_8_source_type_density
from viz.report.fig09_source_type_domain_heatmap import figure_9_source_type_domain_heatmap
from viz.report.fig10_policy_to_research_heatmap import figure_10_policy_to_research_heatmap
from viz.report.fig11_self_share_selected import figure_11_self_share_selected
from viz.report.fig12_korea_flows import figure_12_korea_flows
from viz.report.fig13_country_domain_demand_supply_scatter import (
    figure_13_country_domain_demand_supply_scatter,
)
from viz.report.fig14_policy_research_flow_network import figure_14_policy_research_flow_network
from viz.report.si_citation_distribution_ccdf import figure_si_citation_distribution_ccdf
from viz.report.si_country_domain_demand_supply_delta_heatmap import (
    figure_si_country_domain_demand_supply_delta_heatmap,
)
from viz.report.si_density_robustness_policy_source_country import (
    figure_si_density_robustness_policy_source_country,
)
from viz.report.si_density_robustness_policy_source_type import (
    figure_si_density_robustness_policy_source_type,
)
from viz.report.si_korea_peer_group_by_policy_docs import figure_si_korea_peer_group_by_policy_docs
from viz.report.si_policy_research_flow_network_backbone_sensitivity import (
    figure_si_policy_research_flow_network_backbone_sensitivity,
)
from viz.report.si_repeat_citation_sensitivity import figure_si_repeat_citation_sensitivity


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Generate report-specific figures into Output/Data_Insight/report_figures "
            "(Figure 1–14 + SI robustness figures)."
        )
    )
    parser.add_argument(
        "--run-tag",
        default=os.environ.get("RUN_TAG", "20251026"),
        help="Input/output filename prefix (default: env RUN_TAG or 20251026).",
    )
    parser.add_argument(
        "--in-dir",
        type=Path,
        default=Path("Output/Data_Insight"),
        help="Directory containing input CSVs (default: Output/Data_Insight).",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("Output/Data_Insight/report_figures"),
        help="Directory to write report figure PNG/CSVs (default: Output/Data_Insight/report_figures).",
    )
    parser.add_argument(
        "--network-node-count",
        type=int,
        default=int(os.environ.get("NETWORK_NODE_COUNT", "50")),
        help="Figure 14 network: number of top nodes to include (default: env NETWORK_NODE_COUNT or 50).",
    )
    parser.add_argument(
        "--network-layout-seed",
        type=int,
        default=int(os.environ.get("NETWORK_LAYOUT_SEED", "2026")),
        help="Figure 14 network: random seed for layout algorithms (default: env NETWORK_LAYOUT_SEED or 2026).",
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    # Main report figures
    figure_1_pubyear_trend(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_2_domain_top10(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_3_topic_scatter(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_4_topic_intensity_vs_recency(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_5_country_citations(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_6_country_domain_heatmap(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_7_source_type_citations(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_8_source_type_density(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_9_source_type_domain_heatmap(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_10_policy_to_research_heatmap(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_11_self_share_selected(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_12_korea_flows(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_13_country_domain_demand_supply_scatter(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_14_policy_research_flow_network(
        run_tag=args.run_tag,
        in_dir=args.in_dir,
        out_dir=args.out_dir,
        node_count=args.network_node_count,
        layout_seed=args.network_layout_seed,
    )

    # SI / Extended Report robustness figures
    figure_si_citation_distribution_ccdf(run_tag=args.run_tag, out_dir=args.out_dir)
    figure_si_density_robustness_policy_source_country(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_si_density_robustness_policy_source_type(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_si_repeat_citation_sensitivity(run_tag=args.run_tag, out_dir=args.out_dir)
    figure_si_korea_peer_group_by_policy_docs(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_si_country_domain_demand_supply_delta_heatmap(run_tag=args.run_tag, in_dir=args.in_dir, out_dir=args.out_dir)
    figure_si_policy_research_flow_network_backbone_sensitivity(
        run_tag=args.run_tag,
        in_dir=args.in_dir,
        out_dir=args.out_dir,
        node_count=args.network_node_count,
        layout_seed=args.network_layout_seed,
    )

    print(f"Wrote report figures to: {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
